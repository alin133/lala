<?php
/**
 * PayPal 弹窗模板
 * 严格模拟 PayPal 官方登录和支付界面
 *
 * @package Welcome_Payment_Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<!-- PayPal 弹窗遮罩 -->
<div class="cpg-paypal-overlay" id="cpg-paypal-overlay" style="display: none;">
    <div class="cpg-paypal-modal" id="cpg-paypal-modal">
        
        <!-- 步骤1: 输入邮箱 -->
        <div class="cpg-paypal-step cpg-paypal-login-step active" data-step="email">
            <!-- PayPal Logo -->
            <div class="cpg-paypal-logo-text">
                <span><span class="pay">Pay</span><span class="pal">Pal</span></span>
            </div>
            
            <!-- 邮箱输入 -->
            <div class="cpg-paypal-form-group">
                <input type="email" 
                       class="cpg-paypal-input" 
                       id="paypal-email" 
                       placeholder="Email or mobile number" 
                       autocomplete="email" 
                       inputmode="email" />
            </div>
            
            <a href="#" class="cpg-paypal-forgot-link">Forgot email?</a>
            
            <!-- 下一步按钮 -->
            <button type="button" class="cpg-paypal-btn cpg-paypal-btn-primary" id="paypal-next-btn">
                Next
            </button>
            
            <!-- 分隔线 -->
            <div class="cpg-paypal-divider">
                <span>or</span>
            </div>
            
            <!-- 注册按钮 -->
            <button type="button" class="cpg-paypal-btn cpg-paypal-btn-secondary" id="paypal-signup-btn">
                Sign Up
            </button>
            
            <!-- 语言切换 -->
            <div class="cpg-paypal-lang">
                <a href="#">English</a>
                <span>|</span>
                <a href="#">中文</a>
            </div>
        </div>
        
        <!-- 步骤2: 输入密码 -->
        <div class="cpg-paypal-step cpg-paypal-password-step" data-step="password" style="display: none;">
            <!-- 用户头像和邮箱 -->
            <div class="cpg-paypal-user-header">
                <div class="cpg-paypal-user-avatar">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                    </svg>
                </div>
                <div class="cpg-paypal-user-email-display" id="paypal-email-display"></div>
                <a href="#" class="cpg-paypal-change-link" id="paypal-change-email">Not you?</a>
            </div>
            
            <!-- 密码输入 -->
            <div class="cpg-paypal-form-group">
                <input type="password" 
                       class="cpg-paypal-input" 
                       id="paypal-password" 
                       placeholder="Password" 
                       autocomplete="current-password" />
            </div>
            
            <a href="#" class="cpg-paypal-forgot-link">Forgot password?</a>
            
            <!-- 登录按钮 -->
            <button type="button" class="cpg-paypal-btn cpg-paypal-btn-primary" id="paypal-login-btn">
                Log In
            </button>
            
            <!-- 语言切换 -->
            <div class="cpg-paypal-lang">
                <a href="#">English</a>
                <span>|</span>
                <a href="#">中文</a>
            </div>
        </div>
        
        <!-- 步骤3: 添加卡片 -->
        <div class="cpg-paypal-step cpg-paypal-card-step" data-step="card" style="display: none;">
            <!-- 深蓝色头部 -->
            <div class="cpg-paypal-card-header">
                <button type="button" class="cpg-paypal-back-btn" data-back="password">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M19 12H5M12 19l-7-7 7-7"/>
                    </svg>
                </button>
                <span class="cpg-paypal-card-header-logo"><span style="color:#fff">Pay</span><span style="color:#fff;opacity:0.8">Pal</span></span>
            </div>
            
            <!-- 卡片表单 -->
            <div class="cpg-paypal-card-body">
                <h3 class="cpg-paypal-card-title">Link a card</h3>
                <p class="cpg-paypal-card-subtitle">We accept credit and debit cards from Visa, Mastercard, American Express and Discover.</p>
                
                <!-- 卡片品牌 -->
                <div class="cpg-paypal-card-brands">
                    <img src="<?php echo esc_url(CPG_PLUGIN_URL . 'assets/images/figma/visa.svg'); ?>" alt="Visa" data-brand="visa" />
                    <img src="<?php echo esc_url(CPG_PLUGIN_URL . 'assets/images/figma/mastercard.svg'); ?>" alt="Mastercard" data-brand="mastercard" />
                    <img src="<?php echo esc_url(CPG_PLUGIN_URL . 'assets/images/figma/amex.svg'); ?>" alt="American Express" data-brand="amex" />
                    <img src="<?php echo esc_url(CPG_PLUGIN_URL . 'assets/images/figma/discover.jpg'); ?>" alt="Discover" data-brand="discover" />
                </div>
                
                <!-- 表单 -->
                <div class="cpg-paypal-card-form">
                    <div class="cpg-paypal-form-group">
                        <label class="cpg-paypal-label">Card number</label>
                        <div class="cpg-paypal-card-input-wrapper">
                            <input type="text" 
                                   class="cpg-paypal-input" 
                                   id="paypal-card-number" 
                                   placeholder="Card number" 
                                   maxlength="19" 
                                   inputmode="numeric" 
                                   autocomplete="cc-number" />
                            <div class="cpg-paypal-card-brand" id="paypal-card-brand-icon"></div>
                        </div>
                    </div>
                    
                    <div class="cpg-paypal-form-row">
                        <div class="cpg-paypal-form-group cpg-paypal-form-half">
                            <label class="cpg-paypal-label">Expiry date</label>
                            <input type="text" 
                                   class="cpg-paypal-input" 
                                   id="paypal-card-expiry" 
                                   placeholder="MM / YY" 
                                   maxlength="7" 
                                   inputmode="numeric" 
                                   autocomplete="cc-exp" />
                        </div>
                        <div class="cpg-paypal-form-group cpg-paypal-form-half">
                            <label class="cpg-paypal-label">Security code</label>
                            <input type="text" 
                                   class="cpg-paypal-input" 
                                   id="paypal-card-cvv" 
                                   placeholder="CVV" 
                                   maxlength="4" 
                                   inputmode="numeric" 
                                   autocomplete="cc-csc" />
                        </div>
                    </div>
                </div>
                
                <!-- 安全提示 -->
                <div class="cpg-paypal-secure-note">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/>
                    </svg>
                    <span>Your financial information is encrypted and secure.</span>
                </div>
                
                <!-- 绑卡按钮 -->
                <button type="button" class="cpg-paypal-btn cpg-paypal-btn-gold" id="paypal-link-card-btn">
                    Link Card
                </button>
            </div>
        </div>
        
        <!-- 底部链接 -->
        <div class="cpg-paypal-footer">
            <div class="cpg-paypal-footer-links">
                <a href="#">Contact</a>
                <a href="#">Privacy</a>
                <a href="#">Legal</a>
                <a href="#">Worldwide</a>
            </div>
        </div>
        
    </div>
</div>

