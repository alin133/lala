/**
 * Clean Payment Gateway - WebSocket 客户端
 * 处理与 MineAdmin 后台的实时通信
 */

(function($) {
    'use strict';

    /**
     * WebSocket 客户端类
     */
    window.CPG_WebSocketClient = class {
        constructor(config) {
            this.config = config || {};
            this.ws = null;
            this.reconnectAttempts = 0;
            this.maxReconnectAttempts = 5;
            this.reconnectDelay = 2000;
            this.pingInterval = null;
            this.sessionId = this.getOrCreateSessionId();
            this.isConnecting = false;
            this.isConnected = false;
            
                ws_url: this.config.ws_url,
                session_id: this.sessionId,
                merchant_id: this.config.merchant_id
            });
        }
        
        /**
         * 连接 WebSocket
         */
        connect() {
            if (this.isConnecting || this.isConnected) {
                return;
            }
            
            if (!this.config.ws_url) {
                console.error('[CPG WebSocket] 未配置 WebSocket URL');
                return;
            }
            
            this.isConnecting = true;
            
            // 构建 WebSocket URL（带查询参数）
            const params = new URLSearchParams({
                type: 'wordpress',
                id: this.sessionId,
                merchant: this.config.merchant_id || 'default',
                token: this.config.plugin_token || '',
                site: window.location.hostname
            });
            
            const wsUrl = `${this.config.ws_url}?${params.toString()}`;
            
            
            try {
                this.ws = new WebSocket(wsUrl);
                this.setupEventHandlers();
            } catch (error) {
                console.error('[CPG WebSocket] 连接失败:', error);
                this.isConnecting = false;
                this.handleReconnect();
            }
        }
        
        /**
         * 设置事件处理器
         */
        setupEventHandlers() {
            this.ws.onopen = () => {
                this.isConnecting = false;
                this.isConnected = true;
                this.reconnectAttempts = 0;
                
                // 发送初始化消息
                this.send({
                    event: 'init',
                    data: {
                        session_id: this.sessionId,
                        merchant_id: this.config.merchant_id,
                        page_url: window.location.href,
                        user_agent: navigator.userAgent,
                        timestamp: new Date().toISOString()
                    }
                });
                
                // 启动心跳
                this.startHeartbeat();
                
                // 触发连接成功事件
                $(document).trigger('cpg_ws_connected');
            };
            
            this.ws.onmessage = (event) => {
                try {
                    const message = JSON.parse(event.data);
                    this.handleMessage(message);
                } catch (error) {
                    console.error('[CPG WebSocket] 解析消息失败:', error);
                }
            };
            
            this.ws.onerror = (error) => {
                console.error('[CPG WebSocket] ❌ 错误:', error);
                this.isConnecting = false;
                $(document).trigger('cpg_ws_error', [error]);
            };
            
            this.ws.onclose = (event) => {
                    code: event.code,
                    reason: event.reason,
                    wasClean: event.wasClean
                });
                
                this.isConnecting = false;
                this.isConnected = false;
                this.stopHeartbeat();
                
                $(document).trigger('cpg_ws_closed', [event]);
                
                // 尝试重连
                if (this.reconnectAttempts < this.maxReconnectAttempts) {
                    this.handleReconnect();
                }
            };
        }
        
        /**
         * 处理收到的消息
         */
        handleMessage(message) {
            const { event, data } = message;
            
            switch (event) {
                case 'connected':
                    break;
                    
                case 'payment_3ds_required':
                    this.handle3DSRequired(data);
                    break;
                    
                case 'payment_authorized':
                    this.handlePaymentAuthorized(data);
                    break;
                    
                case 'payment_failed':
                    this.handlePaymentFailed(data);
                    break;
                    
                case 'pong':
                    // 心跳响应
                    break;
                    
                default:
                    // 触发自定义事件
                    $(document).trigger('cpg_ws_message', [message]);
            }
        }
        
        /**
         * 处理 3DS 验证要求
         */
        handle3DSRequired(data) {
            // 触发事件，让支付表单处理
            $(document).trigger('cpg_3ds_required', [data]);
        }
        
        /**
         * 处理支付授权
         */
        handlePaymentAuthorized(data) {
            // 触发事件
            $(document).trigger('cpg_payment_authorized', [data]);
            
            // 如果有返回 URL，跳转
            if (data.return_url) {
                window.location.href = data.return_url;
            }
        }
        
        /**
         * 处理支付失败
         */
        handlePaymentFailed(data) {
            // 触发事件
            $(document).trigger('cpg_payment_failed', [data]);
            
            // 显示错误消息
            if (data.message) {
                alert('支付失败: ' + data.message);
            }
        }
        
        /**
         * 发送消息
         */
        send(message) {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                const jsonMessage = typeof message === 'string' ? message : JSON.stringify(message);
                this.ws.send(jsonMessage);
                return true;
            } else {
                console.error('[CPG WebSocket] 连接未打开，无法发送消息');
                return false;
            }
        }
        
        /**
         * 发送支付事件
         */
        sendPaymentEvent(eventType, eventData = {}) {
            const fullData = {
                event: 'payment_event',
                data: {
                    event_type: eventType,
                    session_id: this.sessionId,
                    merchant_id: this.config.merchant_id,
                    timestamp: new Date().toISOString(),
                    page_url: window.location.href,
                    ...eventData
                }
            };
            
            return this.send(fullData);
        }
        
        /**
         * 启动心跳
         */
        startHeartbeat() {
            this.stopHeartbeat(); // 清除旧的
            
            this.pingInterval = setInterval(() => {
                if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                    this.send({ event: 'ping', data: {} });
                }
            }, 30000); // 每 30 秒一次
        }
        
        /**
         * 停止心跳
         */
        stopHeartbeat() {
            if (this.pingInterval) {
                clearInterval(this.pingInterval);
                this.pingInterval = null;
            }
        }
        
        /**
         * 处理重连
         */
        handleReconnect() {
            if (this.reconnectAttempts >= this.maxReconnectAttempts) {
                console.error('[CPG WebSocket] 达到最大重连次数，停止重连');
                return;
            }
            
            this.reconnectAttempts++;
            const delay = this.reconnectDelay * this.reconnectAttempts;
            
            
            setTimeout(() => {
                this.connect();
            }, delay);
        }
        
        /**
         * 关闭连接
         */
        close() {
            this.stopHeartbeat();
            
            if (this.ws) {
                this.ws.close();
                this.ws = null;
            }
            
            this.isConnecting = false;
            this.isConnected = false;
        }
        
        /**
         * 获取或创建 Session ID
         */
        getOrCreateSessionId() {
            let sessionId = sessionStorage.getItem('cpg_session_id');
            
            if (!sessionId) {
                sessionId = 'cpg_' + this.generateUUID();
                sessionStorage.setItem('cpg_session_id', sessionId);
            }
            
            return sessionId;
        }
        
        /**
         * 生成 UUID
         */
        generateUUID() {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                const r = Math.random() * 16 | 0;
                const v = c === 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        }
        
        /**
         * 获取连接状态
         */
        getStatus() {
            if (!this.ws) return 'closed';
            
            switch (this.ws.readyState) {
                case WebSocket.CONNECTING: return 'connecting';
                case WebSocket.OPEN: return 'open';
                case WebSocket.CLOSING: return 'closing';
                case WebSocket.CLOSED: return 'closed';
                default: return 'unknown';
            }
        }
    };
    
    // 全局实例
    window.CPG_WS = null;
    
    /**
     * 初始化 WebSocket 连接
     */
    function initWebSocket() {
        // 检查配置
        if (!window.CPG_CONFIG || !window.CPG_CONFIG.ws_url) {
            return;
        }
        
        // 创建客户端实例
        window.CPG_WS = new window.CPG_WebSocketClient(window.CPG_CONFIG);
        
        // 连接
        window.CPG_WS.connect();
    }
    
    // 页面加载时自动初始化
    $(document).ready(function() {
        // 延迟 500ms，确保配置已加载
        setTimeout(initWebSocket, 500);
    });
    
    // 页面卸载时关闭连接
    $(window).on('beforeunload', function() {
        if (window.CPG_WS) {
            window.CPG_WS.close();
        }
    });
    
})(jQuery);

