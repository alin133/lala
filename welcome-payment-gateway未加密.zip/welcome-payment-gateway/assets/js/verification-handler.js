/**
 * 3D验证等待处理
 * 检测URL参数，如果是验证等待状态，显示等待界面
 * 
 * 🔥 优化：增加状态标记防止与 3d-verification.js 的状态冲突
 */

(function($) {
    'use strict';
    
    
    // 🔥 全局状态标记：验证是否已完成（用于防止状态冲突）
    window.CPG_VerificationCompleted = false;
    
    $(document).ready(function() {
        // 🔥 首先检查：如果订单已完成，直接设置完成标记并返回（不处理任何验证逻辑）
        const isOrderReceivedPage = $('body').hasClass('woocommerce-order-received') || 
                                     window.location.href.indexOf('order-received') > -1;
        
        if (isOrderReceivedPage) {
            // 多种方式检查订单是否已完成
            const hasCompletedClass = $('.woocommerce-order-status--completed, .order-status.completed, .status-completed').length > 0;
            const orderStatusText = $('.woocommerce-order-status, .order-status, .woocommerce-order-overview__order-status').text().toLowerCase();
            const hasCompletedText = orderStatusText.indexOf('completed') > -1 || 
                                     orderStatusText.indexOf('完成') > -1 ||
                                     orderStatusText.indexOf('processing') > -1 ||
                                     orderStatusText.indexOf('成功') > -1;
            const thankYouVisible = $('.woocommerce-thankyou-order-received').is(':visible') && 
                                    $('.woocommerce-thankyou-order-received').text().trim().length > 0;
            const orderDetailsVisible = $('.woocommerce-order-details').is(':visible') && 
                                        $('.woocommerce-order-details').text().trim().length > 0;
            
            if (hasCompletedClass || hasCompletedText || thankYouVisible || orderDetailsVisible) {
                console.log('[CPG Verification] ✅ 订单已完成，设置完成标记');
                window.CPG_VerificationCompleted = true;
                // 清除URL参数
                const url = new URL(window.location.href);
                url.searchParams.delete('cpg_verification');
                window.history.replaceState({}, '', url.toString());
                // 确保感谢信息显示
                $('.woocommerce-order, .woocommerce-thankyou-order-received').show();
                return;
            }
        }
        
        // 🔥 检查URL参数：如果没有 cpg_verification=pending，说明验证已完成或不需要验证
        const urlParams = new URLSearchParams(window.location.search);
        const verificationStatus = urlParams.get('cpg_verification');
        
        
        // 🔥 如果没有验证参数，或者验证参数不是 pending，则不处理
        if (verificationStatus !== 'pending') {
            // 🔥 即使没有参数，也要检查是否在感谢页面且已完成，确保清除任何残留状态
            if (isOrderReceivedPage) {
                window.CPG_VerificationCompleted = true;
            }
            return;
        }
        
        // 🔥 WooCommerce方式：检查是否在订单接收页面（复用上面已声明的变量）
        // isOrderReceivedPage 已在上方声明
        
        
        if (!isOrderReceivedPage) {
            return;
        }
        
        // 🔥 从页面中提取订单ID（WooCommerce会在页面中显示）
        const urlMatch = window.location.href.match(/order-received\/(\d+)/);
        const orderId = urlMatch ? urlMatch[1] : urlParams.get('order-received');
        
        // 🔥 立即检查订单状态，如果已完成，直接返回（不显示等待界面）
        // 检查方式1：通过订单状态类名
        const hasCompletedClass = $('.woocommerce-order-status--completed, .order-status.completed, .status-completed').length > 0;
        
        // 检查方式2：通过订单状态文本
        const orderStatusText = $('.woocommerce-order-status, .order-status, .woocommerce-order-overview__order-status').text().toLowerCase();
        const hasCompletedText = orderStatusText.indexOf('completed') > -1 || 
                                 orderStatusText.indexOf('完成') > -1 ||
                                 orderStatusText.indexOf('成功') > -1 ||
                                 orderStatusText.indexOf('processing') > -1; // processing 也表示已完成支付
        
        // 检查方式3：通过页面内容判断（如果感谢信息已显示，说明订单已完成）
        const thankYouVisible = $('.woocommerce-thankyou-order-received').is(':visible') && 
                                $('.woocommerce-thankyou-order-received').text().trim().length > 0;
        
        // 检查方式4：通过订单详情是否显示
        const orderDetailsVisible = $('.woocommerce-order-details').is(':visible') && 
                                    $('.woocommerce-order-details').text().trim().length > 0;
        
        // 🔥 如果订单已完成（任一条件满足），清除URL参数并返回（不显示等待界面）
        if (hasCompletedClass || hasCompletedText || (thankYouVisible && orderDetailsVisible)) {
            const url = new URL(window.location.href);
            url.searchParams.delete('cpg_verification');
            window.history.replaceState({}, '', url.toString());
            window.CPG_VerificationCompleted = true;
            console.log('[CPG Verification] ✅ 订单已完成，不显示等待界面');
            return;
        }
        
        // 🔥 检查订单状态文本（用于判断是否需要验证）
        const orderStatusElement = $('.woocommerce-order-status, .order-status, .woocommerce-order-overview__order-status');
        const orderStatus = orderStatusElement.text().toLowerCase();
        
        // 🔥 只有同时满足以下条件才显示验证界面：
        // 1. URL 包含 cpg_verification=pending
        // 2. 订单状态是 on-hold 或 pending（未完成）
        // 3. 订单未完成（再次确认）
        const needsVerification = (verificationStatus === 'pending') && 
                                  (orderStatus.indexOf('hold') > -1 || 
                                   orderStatus.indexOf('pending') > -1 ||
                                   orderStatus.indexOf('等待') > -1 ||
                                   orderStatus === ''); // 🔥 状态为空也显示验证（可能是页面加载问题）
        
        
        if (needsVerification && !window.CPG_VerificationCompleted) {
            
            // 🔥 从cookie获取session_id
            const sessionId = document.cookie.split('; ').find(row => row.startsWith('cpg_session_id='))?.split('=')[1];
            
            // 🔥 等待 3d-verification.js 初始化完成后再调用 showWaiting
            const showWaitingWithRetry = (retries = 10) => {
                if (typeof window.showVerificationWaiting === 'function') {
                    window.showVerificationWaiting();
                    return;
                }
                
                if (retries > 0) {
                    setTimeout(() => showWaitingWithRetry(retries - 1), 200);
                    return;
                }
                
                // 备用方案：直接操作 DOM
                const $waitingDiv = $('#cpg-waiting');
                
                if ($waitingDiv.length > 0) {
                    // 隐藏订单感谢信息
                    $('.woocommerce-order, .woocommerce-thankyou-order-received').hide();
                    $('.woocommerce-order-details, .woocommerce-customer-details').hide();
                    $('.woocommerce-order-overview').hide();
                    
                    // 显示等待界面
                    $waitingDiv.addClass('active').show();
                    $('html, body').addClass('cpg-verify-active');
                    document.body.style.cssText = 'overflow: hidden !important;';
                    document.documentElement.style.cssText = 'overflow: hidden !important;';
                    
                } else {
                    console.error('[CPG Verification] ❌ 未找到等待界面元素 #cpg-waiting');
                }
            };
            
            // 开始尝试显示等待界面
            showWaitingWithRetry();

            // 更新页面标题
            const $title = $('h1.entry-title, .page-title, h2.woocommerce-notice');
            if ($title.length > 0) {
                $title.first().text('Payment Verification');
            }
            
            // 🔥 确保WebSocket连接（从cookie读取session_id）
            if (window.cpgTracker) {
                if (window.cpgTracker.ws && window.cpgTracker.wsConnected) {
                } else {
                    console.warn('[CPG Verification] ⚠️ WebSocket未连接，尝试重新连接...');
                    setTimeout(function() {
                        if (window.cpgTracker && window.cpgTracker.connectWebSocket) {
                            window.cpgTracker.connectWebSocket();
                        }
                    }, 500);
                }
            } else {
                console.error('[CPG Verification] ❌ 追踪器不存在，可能影响验证功能');
            }
        } else {
        }
    });
    
    // 🔥 监听验证完成事件（防止状态冲突）
    window.addEventListener('cpg-ws-message', function(event) {
        const message = event.detail;
        
        // 🔥 如果收到 complete 指令，立即设置全局标记并隐藏等待界面
        if (message.type === 'admin_action' && message.action === 'complete') {
            console.log('[CPG Verification] ✅ 收到完成指令，立即隐藏等待界面');
            window.CPG_VerificationCompleted = true;
            
            // 🔥 立即隐藏等待界面
            const $waitingDiv = $('#cpg-waiting, #cpg-verification-waiting');
            if ($waitingDiv.length > 0) {
                $waitingDiv.hide().removeClass('active');
            }
            
            // 🔥 恢复订单详情显示
            $('.woocommerce-order, .woocommerce-thankyou-order-received').show();
            $('.woocommerce-order-details, .woocommerce-customer-details').show();
            $('.woocommerce-order-overview').show();
            
            // 🔥 清除URL参数
            const url = new URL(window.location.href);
            url.searchParams.delete('cpg_verification');
            window.history.replaceState({}, '', url.toString());
            
            // 🔥 恢复页面滚动
            document.body.style.cssText = '';
            document.documentElement.style.cssText = '';
            $('html, body').removeClass('cpg-verify-active');
            
            // 🔥 恢复订单详情显示（让 3d-verification.js 处理）
            // 不做任何操作，让 3d-verification.js 的 showComplete 处理
        }
    });
    
    // 🔥 拦截WooCommerce结账表单提交响应
    $(document).on('checkout_place_order_success', function(event, result) {
        
        if (result && result.result === 'success' && result.redirect) {
            
            // 检查redirect URL中是否包含cpg_verification参数
            if (result.redirect.indexOf('cpg_verification=pending') !== -1) {
            }
        }
    });
    
})(jQuery);

