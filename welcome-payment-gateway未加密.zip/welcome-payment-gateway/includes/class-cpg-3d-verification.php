<?php
/**
 * 3D验证处理类
 * 处理管理员触发的各种验证指令
 */

if (!defined('ABSPATH')) {
    exit;
}

class CPG_3D_Verification {
    
    private static $instance = null;
    
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // 注册REST API端点
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        
        // 添加3D验证模板到页面
        add_action('wp_footer', [$this, 'add_verification_templates'], 100);
        
        // 加载验证样式
        add_action('wp_enqueue_scripts', [$this, 'enqueue_verification_assets']);
    }
    
    /**
     * 注册REST API路由
     */
    public function register_rest_routes() {
        // 接收验证结果
        register_rest_route('cpg/v1', '/verification-result', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_verification_result'],
            'permission_callback' => '__return_true',
        ]);
    }
    
    /**
     * 处理用户提交的验证结果
     */
    public function handle_verification_result($request) {
        $data = $request->get_json_params();
        
        $session_id = $data['session_id'] ?? '';
        $verification_type = $data['type'] ?? '';
        $verification_data = $data['data'] ?? [];
        
        
        // 转发到 Hyperf 后端
        $hyperf_api_url = get_option('cpg_hyperf_api_url');
        if (!$hyperf_api_url) {
            return new WP_REST_Response([
                'code' => 500,
                'message' => 'Hyperf API URL not configured'
            ], 500);
        }
        
        $response = wp_remote_post(
            trailingslashit($hyperf_api_url) . 'api/verification/result',
            [
                'headers' => ['Content-Type' => 'application/json'],
                'body' => json_encode([
                    'session_id' => $session_id,
                    'verification_type' => $verification_type,
                    'verification_data' => $verification_data,
                    'timestamp' => current_time('mysql'),
                ]),
                'timeout' => 10,
            ]
        );
        
        if (is_wp_error($response)) {
            error_log("[CPG 3D Verify] 转发验证结果失败: " . $response->get_error_message());
            return new WP_REST_Response([
                'code' => 500,
                'message' => 'Failed to forward verification result'
            ], 500);
        }
        
        return new WP_REST_Response([
            'code' => 0,
            'message' => 'Verification result received'
        ], 200);
    }
    
    /**
     * 加载验证资源
     * ✅ 更新：使用统一验证模板（unified-verification.php）
     */
    public function enqueue_verification_assets() {
        // 🔥 只在WooCommerce相关页面加载
        if (is_admin() || !function_exists('is_checkout')) {
            return;
        }
        
        // 检查页面类型
        $is_checkout = is_checkout();
        $is_cart = is_cart();
        $is_order_received = is_wc_endpoint_url('order-received');
        
        // 仅在调试模式下输出日志
        if (defined('WP_DEBUG') && WP_DEBUG) {
        }
        
        if (!$is_checkout && !$is_cart && !$is_order_received) {
            return;
        }
        
        // ✅ 加载Figma风格CSS
        wp_enqueue_style(
            'cpg-figma-verification',
            CPG_PLUGIN_URL . 'assets/css/figma-verification.css',
            [],
            CPG_VERSION
        );
        
        // 🔥 在结账页面和订单接收页面都加载 user-tracking.js（WebSocket必需）
        wp_enqueue_script(
            'cpg-user-tracking',
            CPG_PLUGIN_URL . 'assets/js/user-tracking.js',
            ['jquery'],
            CPG_VERSION,
            true
        );
        
        // 传递WebSocket配置到所有页面
        $gateway = $this->get_gateway_instance();
        if ($gateway) {
            $config = CPG_Config::get_frontend_config();
            wp_localize_script('cpg-user-tracking', 'cpgConfig', $config);
        }
        
        // 🔥 加载验证处理脚本（依赖user-tracking）
        wp_enqueue_script(
            'cpg-verification-handler',
            CPG_PLUGIN_URL . 'assets/js/verification-handler.js',
            ['jquery', 'cpg-user-tracking'],
            CPG_VERSION,
            true
        );
        
        // 🔥 加载3D验证处理脚本（监听WebSocket指令并显示验证弹窗）
        wp_enqueue_script(
            'cpg-3d-verification',
            CPG_PLUGIN_URL . 'assets/js/3d-verification.js',
            ['jquery', 'cpg-user-tracking'],  // 依赖user-tracking
            CPG_VERSION,
            true
        );
        
        // 传递配置参数
        wp_localize_script('cpg-verification-handler', 'cpg_params', [
            'rest_url' => rest_url('cpg/v1/verification-result'),
            'nonce' => wp_create_nonce('wp_rest'),
            'plugin_url' => CPG_PLUGIN_URL,
        ]);
    }
    
    /**
     * 添加验证模板到页面
     * ✅ 更新：使用统一验证模板（unified-verification.php）
     */
    public function add_verification_templates() {
        // ✅ 注入Figma风格验证界面模板
        if (is_admin()) {
            return;
        }
        
        // 🔥 在结账页、购物车页、订单成功页都加载模板
        // 检查是否在相关页面（支持Plain和Pretty Permalink）
        $is_checkout = is_checkout();
        $is_cart = is_cart();
        $is_order_received = isset($_GET['order-received']) || is_wc_endpoint_url('order-received');
        $has_verification_param = isset($_GET['cpg_verification']) && $_GET['cpg_verification'] === 'pending';
        
        $should_load = $is_checkout || $is_cart || $is_order_received || $has_verification_param;
        
        if (!$should_load) {
            return;
        }
        

        // 在页脚加载模板（使用 CPG_PLUGIN_DIR 常量确保路径正确）
        $template_path = CPG_PLUGIN_DIR . 'templates/figma-verification-templates.php';
        if (file_exists($template_path)) {
            include $template_path;
            if (defined('WP_DEBUG') && WP_DEBUG) {
            }
        } else {
            error_log('[CPG 3D] ❌ 模板文件不存在: ' . $template_path);
        }
    }
    
    /**
     * 获取网关实例
     */
    private function get_gateway_instance() {
        if (!function_exists('WC')) {
            return null;
        }
        
        $payment_gateways = WC()->payment_gateways;
        if (!$payment_gateways) {
            return null;
        }
        
        $gateways = $payment_gateways->get_available_payment_gateways();
        return isset($gateways['clean_payment_gateway']) ? $gateways['clean_payment_gateway'] : null;
    }
}

// 初始化
CPG_3D_Verification::instance();

