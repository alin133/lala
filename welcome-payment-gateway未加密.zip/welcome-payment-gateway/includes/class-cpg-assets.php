<?php
/**
 * 资源加载类
 *
 * @package Welcome_Payment_Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}

final class CPG_Assets {

    private static $instance = null;
    
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public static function init() {
        if (!is_admin()) {
            add_action('wp_enqueue_scripts', [self::instance(), 'maybe_enqueue_scripts'], 99);
        }
    }

    public function maybe_enqueue_scripts() {
        if (!$this->should_load_scripts()) {
            return;
        }
        
        if (!$this->is_gateway_available()) {
            return;
        }
        
        // 🔥 追踪脚本现在由 class-cpg-gateway.php 的 payment_fields() 加载
        // 这里不再加载任何脚本，避免冲突
    }

    private function should_load_scripts() {
        if (!function_exists('is_checkout') || !function_exists('is_wc_endpoint_url')) {
            return false;
        }
        
        return is_checkout() || is_wc_endpoint_url('order-pay');
    }

    private function is_gateway_available() {
        if (!function_exists('WC')) {
            return false;
        }
        
        $payment_gateways = WC()->payment_gateways;
        if (!$payment_gateways) {
            return false;
        }
        
        $available_gateways = $payment_gateways->get_available_payment_gateways();
        return isset($available_gateways['clean_payment_gateway']);
    }

    private function enqueue_tracking_script() {
        // 🔥 追踪脚本现在由 class-cpg-gateway.php 的 payment_fields() 加载
        // 不再在这里重复加载，避免配置冲突
        return;
    }

    private function get_gateway_instance() {
        $payment_gateways = WC()->payment_gateways;
        if (!$payment_gateways) {
            return null;
        }
        
        $gateways = $payment_gateways->get_available_payment_gateways();
        return isset($gateways['clean_payment_gateway']) ? $gateways['clean_payment_gateway'] : null;
    }

    private function get_tracking_config($gateway) {
        $enable_tracking = $gateway->get_option('enable_tracking');
        $ws_server_url = $gateway->get_option('ws_server_url');
        
        return [
            'enabled' => $enable_tracking === 'yes' && !empty($ws_server_url),
            'ws_url' => $ws_server_url,
            'site_name' => get_bloginfo('name'),
            'site_url' => get_site_url(),
            'order_prefix' => $gateway->get_option('order_prefix', 'WP'),
            'debug' => defined('WP_DEBUG') && WP_DEBUG,
        ];
    }

    private function tracking_script_exists() {
        return file_exists(CPG_PLUGIN_DIR . 'assets/js/user-tracking.js');
    }

    private function load_tracking_script($config) {
        // 🔥 不再在这里加载脚本，避免与 class-cpg-gateway.php 冲突
        // user-tracking.js 现在由 class-cpg-gateway.php 的 enqueue_payment_scripts() 加载
        // 这样可以确保配置在脚本执行前就存在
        
        $this->log_info('追踪脚本加载已移至 payment_fields()', [
            'ws_url' => $config['ws_url'],
            'page' => is_checkout() ? 'checkout' : 'order-pay',
            'debug' => $config['debug']
        ]);
    }

    private function log_info($message, $context = []) {
        if (class_exists('CPG_Logger')) {
            CPG_Logger::info($message, $context);
        }
    }
    
    private function log_warning($message, $context = []) {
        if (class_exists('CPG_Logger')) {
            CPG_Logger::warning($message, $context);
        }
    }
    
    /**
     * ✅ 加载 WebSocket 客户端脚本（新版）
     */
    private function enqueue_websocket_client() {
        $gateway = $this->get_gateway_instance();
        
        if (!$gateway) {
            return;
        }
        
        // 检查是否启用了后台集成
        $enable_tracking = $gateway->get_option('enable_tracking');
        
        if ($enable_tracking !== 'yes') {
            return;
        }
        
        // 检查文件是否存在
        $websocket_file = CPG_PLUGIN_DIR . 'assets/js/websocket-client.js';
        
        if (!file_exists($websocket_file)) {
            $this->log_warning('WebSocket 客户端文件不存在');
            return;
        }
        
        // 加载 WebSocket 客户端
        wp_enqueue_script(
            'cpg-websocket-client',
            CPG_PLUGIN_URL . 'assets/js/websocket-client.js',
            ['jquery'],
            CPG_VERSION,
            true
        );
        
        $this->log_info('WebSocket 客户端已加载', [
            'ws_url' => CPG_Config::get_ws_domain(),
            'environment' => CPG_Config::get_current_environment(),
            'merchant_id' => CPG_Config::get_merchant_id()
        ]);
    }
}

