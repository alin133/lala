<?php
/**
 * WordPress配置检查脚本
 * 用于诊断user-tracking.js是否正确加载和配置
 * 
 * 使用方法：在浏览器中访问此文件，例如：
 * http://your-site.com/wp-content/plugins/clean-payment-gateway/check-wordpress-config.php
 */

// 加载 WordPress
require_once('../../../../wp-load.php');

// 检查是否有管理员权限
if (!current_user_can('manage_options')) {
    wp_die('您没有权限访问此页面');
}

// 获取网关设置
$gateway_settings = get_option('woocommerce_clean_payment_gateway_settings', []);

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WordPress 配置检查 - Clean Payment Gateway</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #f5f7fa;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
        }
        
        .header h1 {
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .card h2 {
            color: #2d3748;
            margin-bottom: 20px;
            font-size: 24px;
            border-left: 4px solid #667eea;
            padding-left: 15px;
        }
        
        .status-item {
            display: flex;
            align-items: center;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            background: #f8f9fa;
        }
        
        .status-item.success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
        }
        
        .status-item.warning {
            background: #fff3cd;
            border: 1px solid #ffeeba;
        }
        
        .status-item.error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
        }
        
        .status-icon {
            width: 24px;
            height: 24px;
            margin-right: 15px;
            font-size: 20px;
        }
        
        .status-content {
            flex: 1;
        }
        
        .status-label {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .status-detail {
            color: #666;
            font-size: 14px;
        }
        
        .config-value {
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 6px;
            font-family: 'Courier New', monospace;
            margin-top: 10px;
        }
        
        .test-button {
            display: inline-block;
            padding: 12px 24px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
        }
        
        .test-button:hover {
            background: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .console-output {
            background: #1e293b;
            color: #e2e8f0;
            padding: 20px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            line-height: 1.6;
            max-height: 400px;
            overflow-y: auto;
        }
        
        .console-output .log {
            margin-bottom: 8px;
        }
        
        .console-output .log-success {
            color: #10b981;
        }
        
        .console-output .log-error {
            color: #ef4444;
        }
        
        .console-output .log-warning {
            color: #f59e0b;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 WordPress 配置检查</h1>
            <p>Clean Payment Gateway - 用户行为追踪配置诊断</p>
        </div>
        
        <!-- 网关设置检查 -->
        <div class="card">
            <h2>网关基础配置</h2>
            
            <div class="status-item <?php echo ($gateway_settings['enabled'] === 'yes') ? 'success' : 'error'; ?>">
                <div class="status-icon">
                    <?php echo ($gateway_settings['enabled'] === 'yes') ? '✅' : '❌'; ?>
                </div>
                <div class="status-content">
                    <div class="status-label">网关启用状态</div>
                    <div class="status-detail">
                        <?php echo ($gateway_settings['enabled'] === 'yes') ? '已启用' : '未启用（请在WooCommerce设置中启用）'; ?>
                    </div>
                </div>
            </div>
            
            <div class="status-item <?php echo (!empty($gateway_settings['store_name'])) ? 'success' : 'warning'; ?>">
                <div class="status-icon">
                    <?php echo (!empty($gateway_settings['store_name'])) ? '✅' : '⚠️'; ?>
                </div>
                <div class="status-content">
                    <div class="status-label">商店名称</div>
                    <div class="status-detail">
                        <?php echo !empty($gateway_settings['store_name']) ? $gateway_settings['store_name'] : '未设置'; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- WebSocket配置检查 -->
        <div class="card">
            <h2>WebSocket 实时追踪配置</h2>
            
            <div class="status-item <?php echo ($gateway_settings['enable_tracking'] === 'yes') ? 'success' : 'error'; ?>">
                <div class="status-icon">
                    <?php echo ($gateway_settings['enable_tracking'] === 'yes') ? '✅' : '❌'; ?>
                </div>
                <div class="status-content">
                    <div class="status-label">实时追踪状态</div>
                    <div class="status-detail">
                        <?php echo ($gateway_settings['enable_tracking'] === 'yes') ? '已启用' : '未启用（不会发送用户数据到后台）'; ?>
                    </div>
                </div>
            </div>
            
            <div class="status-item <?php echo (!empty($gateway_settings['ws_server_url'])) ? 'success' : 'error'; ?>">
                <div class="status-icon">
                    <?php echo (!empty($gateway_settings['ws_server_url'])) ? '✅' : '❌'; ?>
                </div>
                <div class="status-content">
                    <div class="status-label">WebSocket 服务器地址</div>
                    <div class="status-detail">
                        <?php if (!empty($gateway_settings['ws_server_url'])): ?>
                            <div class="config-value"><?php echo esc_html($gateway_settings['ws_server_url']); ?></div>
                        <?php else: ?>
                            未配置（请在网关设置中填写 WebSocket 服务器地址）
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 脚本加载检查 -->
        <div class="card">
            <h2>JavaScript 脚本检查</h2>
            
            <?php
            $tracking_script = plugin_dir_path(__FILE__) . 'assets/js/user-tracking.js';
            $script_exists = file_exists($tracking_script);
            ?>
            
            <div class="status-item <?php echo $script_exists ? 'success' : 'error'; ?>">
                <div class="status-icon">
                    <?php echo $script_exists ? '✅' : '❌'; ?>
                </div>
                <div class="status-content">
                    <div class="status-label">user-tracking.js 文件</div>
                    <div class="status-detail">
                        <?php echo $script_exists ? '文件存在' : '文件不存在！'; ?>
                        <div class="config-value"><?php echo esc_html($tracking_script); ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 浏览器测试 -->
        <div class="card">
            <h2>浏览器测试</h2>
            <p style="margin-bottom: 20px; color: #666;">点击下方按钮测试 WebSocket 连接和用户追踪功能</p>
            
            <button class="test-button" onclick="startTest()">🚀 开始测试</button>
            
            <div id="test-output" style="margin-top: 20px; display: none;">
                <h3 style="margin-bottom: 15px;">测试输出</h3>
                <div class="console-output" id="console"></div>
            </div>
        </div>
    </div>
    
    <script>
    // 注入配置（用于测试）
    window.CPG_TRACKING_CONFIG = {
        enabled: <?php echo ($gateway_settings['enable_tracking'] === 'yes') ? 'true' : 'false'; ?>,
        ws_url: <?php echo json_encode($gateway_settings['ws_server_url'] ?? ''); ?>,
        site_name: <?php echo json_encode($gateway_settings['store_name'] ?? get_bloginfo('name')); ?>,
        site_url: <?php echo json_encode(home_url()); ?>,
        order_prefix: <?php echo json_encode($gateway_settings['order_prefix'] ?? 'WP'); ?>,
        debug: true
    };
    
    let consoleOutput = [];
    
    function log(message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const logClass = type === 'success' ? 'log-success' : (type === 'error' ? 'log-error' : (type === 'warning' ? 'log-warning' : ''));
        consoleOutput.push(`<div class="log ${logClass}">[${timestamp}] ${message}</div>`);
        updateConsole();
    }
    
    function updateConsole() {
        const consoleEl = document.getElementById('console');
        if (consoleEl) {
            consoleEl.innerHTML = consoleOutput.join('');
            consoleEl.scrollTop = consoleEl.scrollHeight;
        }
    }
    
    function startTest() {
        document.getElementById('test-output').style.display = 'block';
        consoleOutput = [];
        
        log('🔍 开始测试...');
        log('配置信息: ' + JSON.stringify(window.CPG_TRACKING_CONFIG), 'info');
        
        // 检查配置
        if (!window.CPG_TRACKING_CONFIG.enabled) {
            log('❌ 实时追踪未启用', 'error');
            return;
        }
        
        if (!window.CPG_TRACKING_CONFIG.ws_url) {
            log('❌ WebSocket URL 未配置', 'error');
            return;
        }
        
        log('✅ 配置检查通过', 'success');
        
        // 测试 WebSocket 连接
        log('🔗 尝试连接 WebSocket: ' + window.CPG_TRACKING_CONFIG.ws_url);
        
        try {
            const ws = new WebSocket(window.CPG_TRACKING_CONFIG.ws_url);
            
            ws.onopen = () => {
                log('✅ WebSocket 连接成功！', 'success');
                
                // 发送测试消息
                const testMessage = {
                    type: 'client_connected',
                    session_id: 'test_' + Date.now(),
                    site_name: window.CPG_TRACKING_CONFIG.site_name,
                    site_url: window.CPG_TRACKING_CONFIG.site_url,
                    order_prefix: window.CPG_TRACKING_CONFIG.order_prefix,
                    page_url: window.location.href,
                    user_agent: navigator.userAgent,
                    timestamp: Date.now(),
                };
                
                ws.send(JSON.stringify(testMessage));
                log('📤 已发送测试消息', 'success');
                log('消息内容: ' + JSON.stringify(testMessage, null, 2));
            };
            
            ws.onmessage = (event) => {
                log('📥 收到服务器响应: ' + event.data, 'success');
                try {
                    const data = JSON.parse(event.data);
                    log('解析后的数据: ' + JSON.stringify(data, null, 2));
                } catch (e) {
                    // 原始消息
                }
            };
            
            ws.onerror = (error) => {
                log('❌ WebSocket 错误: ' + error.toString(), 'error');
                log('请检查：', 'warning');
                log('1. WebSocket 服务器是否运行在正确的地址和端口', 'warning');
                log('2. 防火墙是否允许 WebSocket 连接', 'warning');
                log('3. 如果使用 LocalWP，请使用宿主机IP地址', 'warning');
            };
            
            ws.onclose = () => {
                log('🔌 WebSocket 连接已关闭', 'warning');
            };
            
        } catch (error) {
            log('❌ WebSocket 连接失败: ' + error.message, 'error');
        }
    }
    </script>
</body>
</html>
<?php

