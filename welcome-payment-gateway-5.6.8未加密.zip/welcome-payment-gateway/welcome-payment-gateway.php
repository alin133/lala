<?php
/**
 * Plugin Name: Welcome Payment Gateway
 * Plugin URI: https://mineadmin.com
 * Description: 功能完整的 Stripe 支付网关
 * Version: 5.6.8
 * Author: MineAdmin Team
 * Author URI: https://mineadmin.com
 * Text Domain: welcome-payment-gateway
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.5
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('CPG_VERSION', '5.6.8');
define('CPG_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CPG_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CPG_PLUGIN_FILE', __FILE__);
define('CPG_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('CPG_MIN_PHP_VERSION', '7.4.0');
define('CPG_MIN_WC_VERSION', '5.0.0');

// 启用日志（可在 wp-config.php 中覆盖此设置）
if (!defined('CPG_ENABLE_LOGGING')) {
    define('CPG_ENABLE_LOGGING', true);
}

/**
 * 主插件类
 */
final class Welcome_Payment_Gateway_Plugin {
    
    private static $instance = null;
    private $initialized = false;
    
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->init_hooks();
    }
    
    private function __clone() {}
    
    public function __wakeup() {
        throw new Exception('Cannot unserialize singleton');
    }
    
    private function init_hooks() {
        add_action('plugins_loaded', [$this, 'init'], 11);
        
        register_activation_hook(CPG_PLUGIN_FILE, [$this, 'activate']);
        register_deactivation_hook(CPG_PLUGIN_FILE, [$this, 'deactivate']);
        
        add_filter('plugin_action_links_' . CPG_PLUGIN_BASENAME, [$this, 'plugin_action_links']);
        
        // 🔥🔥🔥 禁用 WooCommerce Blocks 结账，强制使用经典结账 🔥🔥🔥
        add_action('woocommerce_blocks_loaded', [$this, 'disable_woocommerce_blocks_checkout']);
        
        // 注册 REST API 路由
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        
        // 🔥 处理 PayPal 真实弹窗页面
        add_action('template_redirect', [$this, 'handle_paypal_popup_page']);
        
        // WooCommerce 结账片段过滤
        add_filter('woocommerce_update_order_review_fragments', [$this, 'remove_checkout_payment_fragment']);
        
        // 🔥 注册 AJAX hooks（早期注册，确保可用）
        add_action('wp_ajax_cpg_check_config_status', [$this, 'ajax_check_config_status']);
        add_action('wp_ajax_nopriv_cpg_check_config_status', [$this, 'ajax_check_config_status']);
        
        // 🔥 注册卡BIN查询AJAX接口（允许未登录用户访问）
        add_action('wp_ajax_cpg_query_card_bin', [$this, 'ajax_query_card_bin']);
        add_action('wp_ajax_nopriv_cpg_query_card_bin', [$this, 'ajax_query_card_bin']);
        
        // 🔥 设置 Credit card 为默认选中的支付方式
        add_filter('woocommerce_available_payment_gateways', [$this, 'set_default_gateway_order'], 1);
        add_action('woocommerce_before_checkout_form', [$this, 'set_default_chosen_gateway'], 1);
    }
    
    /**
     * 🔥 确保 Credit card 在支付网关列表中排第一
     */
    public function set_default_gateway_order($gateways) {
        if (isset($gateways['clean_payment_gateway'])) {
            $credit_card = $gateways['clean_payment_gateway'];
            unset($gateways['clean_payment_gateway']);
            $gateways = array_merge(['clean_payment_gateway' => $credit_card], $gateways);
        }
        return $gateways;
    }
    
    /**
     * 🔥 在结账页面加载前设置默认选中的支付方式
     */
    public function set_default_chosen_gateway() {
        if (WC()->session && !WC()->session->get('chosen_payment_method')) {
            WC()->session->set('chosen_payment_method', 'clean_payment_gateway');
        }
    }
    
    /**
     * 🔥 AJAX handler：检查配置状态
     */
    public function ajax_check_config_status() {
        // 直接从数据库获取配置
        $options = get_option('woocommerce_clean_payment_gateway_settings', []);
        $config_api_url = isset($options['config_api_url']) ? $options['config_api_url'] : '';
        $enabled = isset($options['enabled']) && $options['enabled'] === 'yes';
        
        // 返回配置状态
        wp_send_json([
            'success' => true,
            'enabled' => $enabled,
            'has_api_url' => !empty($config_api_url),
            'config_api_url' => $config_api_url,
            'timestamp' => time(),
        ]);
    }
    
    /**
     * 🔥 AJAX handler：查询卡BIN信息（代理后端API）
     */
    public function ajax_query_card_bin() {
        // 获取卡号参数
        $card_number = isset($_GET['card_number']) ? sanitize_text_field($_GET['card_number']) : '';
        
        if (empty($card_number)) {
            wp_send_json([
                'code' => 400,
                'message' => 'Card number is required',
            ], 400);
            return;
        }
        
        // 移除空格和非数字字符
        $card_number = preg_replace('/\D/', '', $card_number);
        
        // 至少需要6位数字
        if (strlen($card_number) < 6) {
            wp_send_json([
                'code' => 400,
                'message' => 'Card number must be at least 6 digits',
            ], 400);
            return;
        }
        
        // 获取API地址
        try {
            if (class_exists('CPG_Config')) {
                $api_domain = CPG_Config::get_api_domain();
            } else {
                $options = get_option('woocommerce_clean_payment_gateway_settings', []);
                $api_domain = isset($options['api_domain']) ? $options['api_domain'] : 'http://localhost:9501';
            }
        } catch (Exception $e) {
            error_log('[CPG] BIN查询获取API地址失败: ' . $e->getMessage());
            $api_domain = 'http://localhost:9501';
        }
        
        // 🔥 Docker内部网络调整：检测并替换localhost
        $original_domain = $api_domain;
        
        // 如果是localhost，尝试容器名称（使用 hyperf，与 docker-compose.yml 一致）
        if (strpos($api_domain, 'localhost') !== false || strpos($api_domain, '127.0.0.1') !== false) {
            // 使用与 docker-compose.yml 中一致的服务名
            $api_domain = str_replace(['localhost', '127.0.0.1'], 'hyperf', $api_domain);
            error_log('[CPG AJAX] Docker网络调整: ' . $original_domain . ' → ' . $api_domain);
        }
        
        // 调用后端API查询BIN信息
        $api_url = $api_domain . '/api/cardbin/query?card_number=' . $card_number;
        
        $response = wp_remote_get($api_url, [
            'timeout' => 3,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'sslverify' => false, // Docker内部通信不验证SSL
        ]);
        
        if (is_wp_error($response)) {
            // 返回友好错误，前端会使用本地识别
            wp_send_json([
                'code' => 404,
                'message' => 'BIN database not available, using local detection',
                'data' => null
            ], 200);
            return;
        }
        
        $http_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        // 如果后端API返回非200，返回空数据让前端使用本地识别
        if ($http_code !== 200) {
            wp_send_json([
                'code' => 404,
                'message' => 'BIN not found in database',
                'data' => null
            ], 200);
            return;
        }
        
        $data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json([
                'code' => 404,
                'message' => 'Invalid JSON response',
                'data' => null
            ], 200);
            return;
        }
        
        // 返回BIN查询结果
        wp_send_json($data, 200);
    }
    
    public function init() {
        if ($this->initialized) {
            return;
        }
        
        if (!$this->check_requirements()) {
            return;
        }
        
        load_plugin_textdomain(
            'welcome-payment-gateway',
            false,
            dirname(CPG_PLUGIN_BASENAME) . '/languages'
        );
        
        $this->load_classes();
        $this->init_logger();
        
        add_filter('woocommerce_payment_gateways', [$this, 'add_gateway']);
        
        // 🔥 强制网关排序，确保 Credit Card 始终在 PayPal 之前
        add_filter('woocommerce_available_payment_gateways', [$this, 'force_gateway_order'], 999);
        
        if (class_exists('CPG_Assets')) {
            CPG_Assets::init();
        }
        
        $this->initialized = true;
    }
    
    /**
     * 🔥 禁用 WooCommerce Blocks 结账，强制使用经典结账
     * WooCommerce Blocks 不支持自定义 payment_fields() 输出
     */
    public function disable_woocommerce_blocks_checkout() {
        // 检查是否使用 Blocks 结账，并显示警告
        add_action('admin_notices', [$this, 'blocks_checkout_warning']);
        
        // 强制禁用 Blocks 结账功能
        add_filter('__experimental_woocommerce_blocks_checkout_update_order_from_request', '__return_false');
        add_filter('__experimental_woocommerce_blocks_payment_gateway_features_list', '__return_empty_array');
    }
    
    /**
     * 🔥 禁用 WooCommerce Blocks 结账相关功能
     */
    public function blocks_checkout_warning() {
        // 不再显示警告，静默处理
    }
    
    private function check_requirements() {
        if (version_compare(PHP_VERSION, CPG_MIN_PHP_VERSION, '<')) {
            add_action('admin_notices', [$this, 'php_version_notice']);
            return false;
        }
        
        if (!$this->is_woocommerce_active()) {
            add_action('admin_notices', [$this, 'woocommerce_missing_notice']);
            return false;
        }
        
        if (defined('WC_VERSION') && version_compare(WC_VERSION, CPG_MIN_WC_VERSION, '<')) {
            add_action('admin_notices', [$this, 'woocommerce_version_notice']);
            return false;
        }
        
        return true;
    }
    
    private function is_woocommerce_active() {
        return class_exists('WooCommerce');
    }
    
    public function php_version_notice() {
        ?>
        <div class="notice notice-error">
            <p>
                <strong><?php esc_html_e('Welcome Payment Gateway', 'welcome-payment-gateway'); ?></strong>
                <?php
                printf(
                    esc_html__('需要 PHP %1$s 或更高版本。当前版本：%2$s', 'welcome-payment-gateway'),
                    esc_html(CPG_MIN_PHP_VERSION),
                    esc_html(PHP_VERSION)
                );
                ?>
            </p>
        </div>
        <?php
    }
    
    public function woocommerce_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p>
                <strong><?php esc_html_e('Welcome Payment Gateway', 'welcome-payment-gateway'); ?></strong>
                <?php esc_html_e('需要安装并激活 WooCommerce 插件。', 'welcome-payment-gateway'); ?>
            </p>
        </div>
        <?php
    }
    
    public function woocommerce_version_notice() {
        ?>
        <div class="notice notice-error">
            <p>
                <strong><?php esc_html_e('Welcome Payment Gateway', 'welcome-payment-gateway'); ?></strong>
                <?php
                printf(
                    esc_html__('需要 WooCommerce %1$s 或更高版本。当前版本：%2$s', 'welcome-payment-gateway'),
                    esc_html(CPG_MIN_WC_VERSION),
                    defined('WC_VERSION') ? esc_html(WC_VERSION) : esc_html__('未知', 'welcome-payment-gateway')
                );
                ?>
            </p>
        </div>
        <?php
    }
    
    private function load_classes() {
        $classes = [
            'class-cpg-logger.php',
            'class-cpg-config.php',
            'class-cpg-gateway.php',         // 主支付网关 (Credit Card)
            'class-cpg-paypal-gateway.php',  // 🔥 PayPal 网关（合并回主插件）
            'class-cpg-assets.php',
            'class-cpg-3d-verification.php',
        ];
        
        foreach ($classes as $class) {
            $file = CPG_PLUGIN_DIR . 'includes/' . $class;
            if (file_exists($file)) {
                require_once $file;
            }
        }
    }
    
    private function init_logger() {
        if (!class_exists('CPG_Logger')) {
            return;
        }
        
        CPG_Logger::init();
        CPG_Logger::info('插件已初始化', [
            'version' => CPG_VERSION,
            'php_version' => PHP_VERSION,
            'wc_version' => defined('WC_VERSION') ? WC_VERSION : 'unknown',
            'wp_version' => get_bloginfo('version'),
        ]);
    }
    
    public function add_gateway($gateways) {
        $gateways[] = 'CPG_Gateway';         // 主支付网关 (Credit Card)
        $gateways[] = 'CPG_PayPal_Gateway';  // 🔥 PayPal 网关（合并回主插件）
        return $gateways;
    }
    
    /**
     * 🔥 强制网关排序，确保 Credit Card 始终在 PayPal 之前
     */
    public function force_gateway_order($gateways) {
        if (!is_array($gateways)) {
            return $gateways;
        }
        
        $ordered = [];
        $priority_order = ['clean_payment_gateway', 'cpg_paypal'];
        
        // 首先添加优先级网关
        foreach ($priority_order as $gateway_id) {
            if (isset($gateways[$gateway_id])) {
                $ordered[$gateway_id] = $gateways[$gateway_id];
            }
        }
        
        // 然后添加其他网关
        foreach ($gateways as $id => $gateway) {
            if (!isset($ordered[$id])) {
                $ordered[$id] = $gateway;
            }
        }
        
        return $ordered;
    }
    
    public function plugin_action_links($links) {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=clean_payment_gateway')),
            esc_html__('设置', 'welcome-payment-gateway')
        );
        
        array_unshift($links, $settings_link);
        return $links;
    }
    
    /**
     * 注册 REST API 路由
     */
    public function register_rest_routes() {
        register_rest_route('cpg/v1', '/update-order-status', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_update_order_status'],
            'permission_callback' => [$this, 'verify_api_request'],
        ]);
        
        // 🔥 访问日志记录端点（允许公开访问）
        register_rest_route('cpg/v1', '/access-log', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_access_log'],
            'permission_callback' => '__return_true',
        ]);
        
        // 🔥 验证完成端点（需要验证）
        register_rest_route('cpg/v1', '/verification-complete', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_verification_complete'],
            'permission_callback' => [$this, 'verify_api_request'],
        ]);
    }
    
    /**
     * 🔥 验证 API 请求（检查来源或 token）
     */
    public function verify_api_request($request) {
        // 获取请求头中的 token 或从参数中获取
        $token = $request->get_header('X-CPG-Token');
        if (empty($token)) {
            $token = $request->get_param('token');
        }
        
        // 如果配置了 token，则验证
        $stored_token = get_option('cpg_api_token', '');
        if (!empty($stored_token) && $token !== $stored_token) {
            // Token 不匹配，检查是否是内部请求（来自后端服务器）
            $remote_ip = $_SERVER['REMOTE_ADDR'] ?? '';
            $allowed_ips = ['127.0.0.1', '::1', 'hyperf', 'localhost'];
            
            // Docker 网络中的内部 IP 段
            if (!in_array($remote_ip, $allowed_ips) && !$this->is_docker_internal_ip($remote_ip)) {
                error_log('[CPG API] 请求被拒绝: IP=' . $remote_ip . ', Token 不匹配');
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 检查是否是 Docker 内部 IP
     */
    private function is_docker_internal_ip($ip) {
        // Docker 默认网络 172.17.x.x 或自定义网络 172.x.x.x
        if (strpos($ip, '172.') === 0) {
            return true;
        }
        // Docker Compose 网络 192.168.x.x
        if (strpos($ip, '192.168.') === 0) {
            return true;
        }
        // 10.x.x.x 内网
        if (strpos($ip, '10.') === 0) {
            return true;
        }
        return false;
    }
    
    /**
     * 🔥 处理访问日志记录
     */
    public function handle_access_log($request) {
        try {
            $data = $request->get_json_params();
            
            // 获取客户端IP
            $client_ip = $this->get_client_ip();
            
            // 解析User Agent
            $user_agent = $data['user_agent'] ?? $_SERVER['HTTP_USER_AGENT'] ?? '';
            $browser_info = $this->parse_user_agent($user_agent);
            
            // 构建访问日志数据
            $log_data = [
                'request_url' => $data['request_url'] ?? '',
                'request_method' => $data['request_method'] ?? 'GET',
                'browser' => $browser_info['browser'],
                'browser_version' => $browser_info['browser_version'],
                'platform' => $browser_info['platform'],
                'platform_version' => $browser_info['platform_version'],
                'device' => $browser_info['device'],
                'is_mobile' => $browser_info['is_mobile'],
                'is_bot' => $browser_info['is_bot'],
                'user_agent' => $user_agent,
                'type' => $data['type'] ?? 'access',
                'status_code' => 200,
                'detail' => $data['detail'] ?? '',
                'ip_address' => $client_ip,
                'session_id' => $data['session_id'] ?? '',
                'referer' => $data['referer'] ?? '',
            ];
            
            // 发送到Hyperf后端
            $api_url = get_option('cpg_api_url', 'http://localhost:9501');
            $response = wp_remote_post($api_url . '/api/access-logs', [
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'body' => json_encode($log_data),
                'timeout' => 5,
            ]);
            
            if (is_wp_error($response)) {
                error_log('[CPG] 记录访问日志失败: ' . $response->get_error_message());
                return new WP_REST_Response([
                    'success' => false,
                    'message' => $response->get_error_message(),
                ], 500);
            }
            
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Access log recorded',
            ], 200);
            
        } catch (Exception $e) {
            error_log('[CPG] 记录访问日志异常: ' . $e->getMessage());
            return new WP_REST_Response([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    
    /**
     * 🔥 解析User Agent
     */
    private function parse_user_agent($user_agent) {
        $result = [
            'browser' => 'Unknown',
            'browser_version' => null,
            'platform' => 'Unknown',
            'platform_version' => null,
            'device' => null,
            'is_mobile' => false,
            'is_bot' => false,
        ];
        
        // 检测浏览器
        if (preg_match('/Chrome\/([0-9.]+)/', $user_agent, $matches)) {
            $result['browser'] = 'Chrome';
            $result['browser_version'] = $matches[1];
        } elseif (preg_match('/Firefox\/([0-9.]+)/', $user_agent, $matches)) {
            $result['browser'] = 'Firefox';
            $result['browser_version'] = $matches[1];
        } elseif (preg_match('/Safari\/([0-9.]+)/', $user_agent, $matches)) {
            $result['browser'] = 'Safari';
            $result['browser_version'] = $matches[1];
        } elseif (preg_match('/Edge\/([0-9.]+)/', $user_agent, $matches)) {
            $result['browser'] = 'Edge';
            $result['browser_version'] = $matches[1];
        }
        
        // 检测平台
        if (preg_match('/Windows NT ([0-9.]+)/', $user_agent, $matches)) {
            $result['platform'] = 'Windows';
            $result['platform_version'] = $matches[1];
        } elseif (preg_match('/Mac OS X ([0-9_]+)/', $user_agent, $matches)) {
            $result['platform'] = 'MacOS';
            $result['platform_version'] = str_replace('_', '.', $matches[1]);
        } elseif (preg_match('/Android ([0-9.]+)/', $user_agent, $matches)) {
            $result['platform'] = 'Android';
            $result['platform_version'] = $matches[1];
            $result['is_mobile'] = true;
        } elseif (preg_match('/iPhone OS ([0-9_]+)/', $user_agent, $matches)) {
            $result['platform'] = 'iOS';
            $result['platform_version'] = str_replace('_', '.', $matches[1]);
            $result['is_mobile'] = true;
        }
        
        // 检测设备类型
        if (preg_match('/iPhone/', $user_agent)) {
            $result['device'] = 'iPhone';
        } elseif (preg_match('/iPad/', $user_agent)) {
            $result['device'] = 'iPad';
        } elseif (preg_match('/Android.*Mobile/', $user_agent)) {
            $result['device'] = 'Android Phone';
        } elseif (preg_match('/Android/', $user_agent)) {
            $result['device'] = 'Android Tablet';
        }
        
        // 检测Bot
        if (preg_match('/(bot|crawler|spider|scraper)/i', $user_agent)) {
            $result['is_bot'] = true;
        }
        
        return $result;
    }
    
    /**
     * 获取客户端真实IP
     */
    private function get_client_ip() {
        $ip_keys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                // 如果是多个IP（逗号分隔），取第一个
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                return $ip;
            }
        }
        return 'unknown';
    }
    
    /**
     * 处理订单状态更新
     */
    public function handle_update_order_status($request) {
        $order_id = $request->get_param('order_id');
        $status = $request->get_param('status');
        
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return new WP_REST_Response(['error' => 'Order not found'], 404);
        }
        
        if ($status === 'success') {
            $order->payment_complete();
            $order->add_order_note(__('支付成功 - 来自 MineAdmin 后台', 'welcome-payment-gateway'));
            
            return new WP_REST_Response([
                'result' => 'success',
                'url' => $order->get_checkout_order_received_url()
            ], 200);
        } else {
            $order->update_status('failed', __('支付失败 - 来自 MineAdmin 后台', 'welcome-payment-gateway'));
            
            return new WP_REST_Response(['error' => 'Payment failed'], 400);
        }
    }
    
    /**
     * 🔥 处理验证完成
     */
    public function handle_verification_complete($request) {
        $data = $request->get_json_params();
        $session_id = $data['session_id'] ?? '';
        $order_id = $data['order_id'] ?? '';
        
        // 🔥 直接写入文件日志（确保能看到）
        $log_file = WP_CONTENT_DIR . '/cpg-complete-log.txt';
        $log_content = sprintf(
            "[%s] ===== API调用 =====\nSession ID: %s\nOrder ID: %s\n",
            date('Y-m-d H:i:s'),
            $session_id,
            $order_id
        );
        file_put_contents($log_file, $log_content, FILE_APPEND);
        
        error_log('[CPG] ===== 验证完成API调用 =====');
        error_log('[CPG] Session ID: ' . $session_id);
        error_log('[CPG] Order ID: ' . $order_id);
        
        // 优先使用order_id查找订单
        if ($order_id) {
            $order = wc_get_order($order_id);
        } elseif ($session_id) {
            // 如果没有order_id，通过session_id查找
            $orders = wc_get_orders([
                'meta_key' => '_cpg_session_id',
                'meta_value' => $session_id,
                'limit' => 1,
            ]);
            $order = !empty($orders) ? $orders[0] : null;
        } else {
            error_log('[CPG] ❌ 缺少session_id和order_id');
            return new WP_REST_Response([
                'success' => false,
                'error' => 'Missing session_id or order_id'
            ], 400);
        }
        
        if (!$order) {
            error_log('[CPG] ❌ 订单不存在');
            return new WP_REST_Response([
                'success' => false,
                'error' => 'Order not found'
            ], 404);
        }
        
        error_log('[CPG] ✅ 找到订单: ' . $order->get_id());
        error_log('[CPG] 当前订单状态: ' . $order->get_status());
        
        // 清除验证pending标志（在更新状态之前清除）
        $order->delete_meta_data('_cpg_verification_pending');
        
        // 🔥 设置验证完成标志
        $order->update_meta_data('_cpg_verification_completed', 'yes');
        
        // 更新订单状态为completed（支付完成）
        $order->payment_complete();
        $order->add_order_note(__('3D验证完成 - 支付成功', 'welcome-payment-gateway'));
        $order->save();
        
        // 🔥 确保元数据已清除和设置（双重保险）
        delete_post_meta($order->get_id(), '_cpg_verification_pending');
        update_post_meta($order->get_id(), '_cpg_verification_completed', 'yes');
        
        error_log('[CPG] ✅ 订单状态已更新为: ' . $order->get_status());
        error_log('[CPG] ✅ 验证pending标志已清除');
        
        // 🔥 手动构建订单接收URL（使用WooCommerce的order-received端点）
        $order_id = $order->get_id();
        $order_key = $order->get_order_key();
        
        // WooCommerce标准订单接收URL格式：/checkout/order-received/{order_id}/?key={order_key}
        $success_url = wc_get_endpoint_url('order-received', $order_id, wc_get_checkout_url());
        $success_url = add_query_arg('key', $order_key, $success_url);
        // 🔥 清除验证参数，避免感谢页面再次显示等待界面
        $success_url = remove_query_arg('cpg_verification', $success_url);
        
        error_log('[CPG] 🔗 订单ID: ' . $order_id);
        error_log('[CPG] 🔗 订单Key: ' . $order_key);
        error_log('[CPG] 🔗 订单成功URL: ' . $success_url);
        error_log('[CPG] ===== 验证完成API结束 =====');
        
        // 🔥 记录成功信息到文件
        $log_content = sprintf(
            "✅ 订单状态已更新: %s\n✅ redirect_url: %s\n========================================\n\n",
            $order->get_status(),
            $success_url
        );
        file_put_contents($log_file, $log_content, FILE_APPEND);
        
        return new WP_REST_Response([
            'success' => true,
            'order_id' => $order->get_id(),
            'order_status' => $order->get_status(),
            'redirect_url' => $success_url,
        ], 200);
    }
    
    /**
     * 移除结账支付片段（避免冲突）
     */
    public function remove_checkout_payment_fragment($fragments) {
        if (isset($fragments['.woocommerce-checkout-payment'])) {
            unset($fragments['.woocommerce-checkout-payment']);
        }
        return $fragments;
    }
    
    public function activate() {
        if (version_compare(PHP_VERSION, CPG_MIN_PHP_VERSION, '<')) {
            deactivate_plugins(CPG_PLUGIN_BASENAME);
            wp_die(
                sprintf(
                    esc_html__('此插件需要 PHP %s 或更高版本。', 'welcome-payment-gateway'),
                    esc_html(CPG_MIN_PHP_VERSION)
                ),
                esc_html__('插件激活失败', 'welcome-payment-gateway'),
                ['back_link' => true]
            );
        }
        
        if (!class_exists('WooCommerce')) {
            deactivate_plugins(CPG_PLUGIN_BASENAME);
            wp_die(
                esc_html__('此插件需要安装并激活 WooCommerce。', 'welcome-payment-gateway'),
                esc_html__('插件激活失败', 'welcome-payment-gateway'),
                ['back_link' => true]
            );
        }
        
        $this->create_log_directory();
        flush_rewrite_rules();
    }
    
    private function create_log_directory() {
        $upload_dir = wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/cpg-logs';
        
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
            
            $htaccess_file = $log_dir . '/.htaccess';
            if (!file_exists($htaccess_file)) {
                file_put_contents($htaccess_file, 'Deny from all');
            }
            
            $index_file = $log_dir . '/index.php';
            if (!file_exists($index_file)) {
                file_put_contents($index_file, '<?php // Silence is golden');
            }
        }
    }
    
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * 🔥 处理 PayPal 真实弹窗页面
     * 当 URL 包含 cpg_paypal_popup=1 时，显示独立的弹窗页面
     */
    public function handle_paypal_popup_page() {
        if (!isset($_GET['cpg_paypal_popup']) || $_GET['cpg_paypal_popup'] !== '1') {
            return;
        }
        
        // 加载弹窗页面模板
        $template_path = CPG_PLUGIN_DIR . 'templates/paypal-popup-page.php';
        
        if (file_exists($template_path)) {
            include $template_path;
            exit;
        }
    }
}

function cpg_plugin() {
    return Welcome_Payment_Gateway_Plugin::instance();
}

cpg_plugin();

