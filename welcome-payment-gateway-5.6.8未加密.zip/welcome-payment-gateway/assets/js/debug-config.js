/**
 * 调试配置
 * 控制是否输出调试日志
 * 
 * 使用方法：
 * 1. 生产环境：设置 CPG_DEBUG = false（或删除此文件）
 * 2. 开发环境：设置 CPG_DEBUG = true
 */

(function() {
    'use strict';
    
    // 🔥 调试开关（生产环境设为 false 可关闭所有 console.log）
    window.CPG_DEBUG = window.CPG_DEBUG !== undefined ? window.CPG_DEBUG : true;
    
    // 🔥 创建安全的日志函数（如果关闭调试，console.log 不会执行）
    window.CPG_Log = {
        log: function() {
            if (window.CPG_DEBUG) {
                console.log.apply(console, arguments);
            }
        },
        warn: function() {
            // 警告始终显示（重要信息）
            console.warn.apply(console, arguments);
        },
        error: function() {
            // 错误始终显示（重要信息）
            console.error.apply(console, arguments);
        },
        info: function() {
            if (window.CPG_DEBUG) {
                console.info.apply(console, arguments);
            }
        }
    };
    
    // 🔥 如果关闭调试，重写 console.log（可选，更彻底）
    if (!window.CPG_DEBUG) {
        var originalLog = console.log;
        console.log = function() {
            // 静默忽略所有 console.log
        };
        console.log.toString = function() {
            return originalLog.toString();
        };
    }
})();

