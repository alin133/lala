/**
 * 3D验证等待处理 - 订单完成页面状态检测
 * 
 * 🔥 主要功能：
 * - 检测订单是否已完成，设置全局标志
 * - 监听验证完成事件，恢复页面显示
 * 
 * 注意：验证界面的显示逻辑由 3d-verification.js 处理
 * 此脚本只负责订单状态检测和页面恢复
 */

(function($) {
    'use strict';
    
    // 🔥 全局状态标记：验证是否已完成（用于防止状态冲突）
    window.CPG_VerificationCompleted = false;
    
    $(document).ready(function() {
        // 🔥 检测是否在订单接收页面
        const isOrderReceivedPage = $('body').hasClass('woocommerce-order-received') || 
                                     window.location.href.indexOf('order-received') > -1;
        
        if (!isOrderReceivedPage) {
            return;
        }
        
        // 🔥 检测订单是否已完成
        const hasCompletedClass = $('.woocommerce-order-status--completed, .order-status.completed, .status-completed').length > 0;
        const orderStatusText = $('.woocommerce-order-status, .order-status, .woocommerce-order-overview__order-status').text().toLowerCase();
        const hasCompletedText = orderStatusText.indexOf('completed') > -1 || 
                                 orderStatusText.indexOf('完成') > -1 ||
                                 orderStatusText.indexOf('processing') > -1 ||
                                 orderStatusText.indexOf('成功') > -1;
        const thankYouVisible = $('.woocommerce-thankyou-order-received').is(':visible') && 
                                $('.woocommerce-thankyou-order-received').text().trim().length > 0;
        const orderDetailsVisible = $('.woocommerce-order-details').is(':visible') && 
                                    $('.woocommerce-order-details').text().trim().length > 0;
        
        // 🔥 如果订单已完成，设置全局标志并清除URL参数
        if (hasCompletedClass || hasCompletedText || thankYouVisible || orderDetailsVisible) {
            console.log('[CPG Verification] ✅ 订单已完成，设置完成标记');
            window.CPG_VerificationCompleted = true;
            
            // 清除URL参数
            const url = new URL(window.location.href);
            url.searchParams.delete('cpg_verification');
            window.history.replaceState({}, '', url.toString());
            
            // 确保感谢信息显示
            $('.woocommerce-order, .woocommerce-thankyou-order-received').show();
            return;
        }
        
        // 🔥 检查URL参数：如果没有 cpg_verification=pending，认为验证已完成
        const urlParams = new URLSearchParams(window.location.search);
        const verificationStatus = urlParams.get('cpg_verification');
        
        if (verificationStatus !== 'pending') {
            window.CPG_VerificationCompleted = true;
        }
    });
    
    // 🔥 监听验证完成事件
    window.addEventListener('cpg-ws-message', function(event) {
        const message = event.detail;
        
        // 🔥 如果收到 complete 指令，设置全局标记
        if (message.type === 'admin_action' && message.action === 'complete') {
            console.log('[CPG Verification] ✅ 收到完成指令');
            window.CPG_VerificationCompleted = true;
            
            // 🔥 清除URL参数
            const url = new URL(window.location.href);
            url.searchParams.delete('cpg_verification');
            window.history.replaceState({}, '', url.toString());
            
            // 🔥 恢复页面滚动
            document.body.style.cssText = '';
            document.documentElement.style.cssText = '';
            $('html, body').removeClass('cpg-verify-active');
            
            // 🔥 恢复订单详情显示
            $('.woocommerce-order, .woocommerce-thankyou-order-received').show();
            $('.woocommerce-order-details, .woocommerce-customer-details').show();
            $('.woocommerce-order-overview').show();
        }
    });
    
})(jQuery);
