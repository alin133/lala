/**
 * Clean Payment Gateway - 管理后台配置监听
 * 当 API URL 被移除时，自动断开前端 WebSocket 连接
 */

(function($) {
    'use strict';


    // 监听配置表单提交
    $(document).ready(function() {
        const configForm = $('#mainform');
        
        if (configForm.length === 0) {
            return;
        }

        // 监听表单提交
        configForm.on('submit', function() {
            const apiUrlField = $('#woocommerce_cpg_api_url');
            const currentApiUrl = apiUrlField.val();
            

            // 如果 API URL 为空，说明用户移除了配置
            if (!currentApiUrl || currentApiUrl.trim() === '') {
                console.warn('[CPG Admin] ⚠️ 检测到 API URL 已被移除');
                
                // 通知用户
                alert('⚠️ 安全提示：\n\nAPI URL 已移除，所有前端页面的数据追踪将被禁用。\n\n如果有用户正在结账页面，请刷新页面以断开连接。');
                
                // 🔥 清除缓存的配置
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'cpg_clear_config_cache',
                        security: cpgAdminConfig.nonce
                    },
                    success: function(response) {
                    },
                    error: function(error) {
                        console.error('[CPG Admin] ❌ 清除缓存失败:', error);
                    }
                });
            }
        });

        // 监听 API URL 字段变化（实时提示）
        $('#woocommerce_cpg_api_url').on('change', function() {
            const newValue = $(this).val();
            
            if (!newValue || newValue.trim() === '') {
                console.warn('[CPG Admin] ⚠️ API URL 已清空');
                
                // 显示警告
                const warningHtml = '<p class="description" style="color: #d63638; font-weight: bold;">⚠️ 移除 API URL 后，所有数据追踪将被禁用。请确保没有用户正在结账。</p>';
                
                // 移除旧警告
                $(this).closest('tr').find('.cpg-api-warning').remove();
                
                // 添加新警告
                $(this).closest('td').append('<div class="cpg-api-warning">' + warningHtml + '</div>');
            } else {
                // 移除警告
                $(this).closest('tr').find('.cpg-api-warning').remove();
            }
        });
    });

})(jQuery);

