<?php
/**
 * Welcome Payment Gateway - 配置管理类
 * ✅ 新版：通过 API 自动获取配置
 *
 * @package Welcome_Payment_Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}

class CPG_Config {
    
    /**
     * ✅ 缓存配置（避免频繁请求 API）
     */
    private static $cached_config = null;
    private static $cache_expiry = 3600; // 1 hour
    
    /**
     * ✅ 从 MineAdmin 后台获取完整配置
     * 🔥 新增：如果未配置 API URL，自动使用智能默认值（开箱即用）
     */
    public static function fetch_config_from_api($force_refresh = false) {
        // 检查缓存
        if (!$force_refresh && self::$cached_config !== null) {
            return self::$cached_config;
        }
        
        // 从 WordPress 选项获取缓存
        $cached = get_option('cpg_api_config_cache');
        $cache_time = get_option('cpg_api_config_cache_time');
        
        if (!$force_refresh && $cached && $cache_time && (time() - $cache_time) < self::$cache_expiry) {
            // 🔥 修复缓存的配置：确保 WebSocket URL 正确
            if (isset($cached['ws_url'])) {
                $cached['ws_url'] = preg_replace('#/[a-zA-Z0-9]{6}/websocket/\d+#', '/ws', $cached['ws_url']);
            }
            if (isset($cached['websocket']['url'])) {
                $cached['websocket']['url'] = preg_replace('#/[a-zA-Z0-9]{6}/websocket/\d+#', '/ws', $cached['websocket']['url']);
            }
            if (isset($cached['websocket']['path'])) {
                $cached['websocket']['path'] = '/ws';
            }
            self::$cached_config = $cached;
            return $cached;
        }
        
        // 🔥 获取 MineAdmin 基础地址（可选配置）
        $gateway = new CPG_Gateway();
        $base_url = $gateway->get_option('config_api_url');
        
        // 🔥 新逻辑：如果 API URL 为空，使用智能默认配置（开箱即用）
        if (empty($base_url)) {
            self::$cached_config = self::get_smart_default_config();
            return self::$cached_config;
        }
        
        // 🔥 自动获取当前 WordPress 站点域名
        $current_domain = self::get_current_domain();
        
        // 🔥 自动构建完整的配置 API URL
        $config_url = self::build_config_url($base_url, $current_domain);
        
        
        // 请求 API
        $response = wp_remote_get($config_url, [
            'timeout' => 10,
            'headers' => [
                'Accept' => 'application/json',
            ],
        ]);
        
        if (is_wp_error($response)) {
            error_log('[CPG Config] API 请求失败: ' . $response->get_error_message());
            return self::get_fallback_config();
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!$data || $data['code'] !== 200) {
            error_log('[CPG Config] API 返回错误: ' . ($data['message'] ?? 'Unknown error'));
            return self::get_fallback_config();
        }
        
        $config = $data['data'];
        
        // 缓存配置
        update_option('cpg_api_config_cache', $config);
        update_option('cpg_api_config_cache_time', time());
        self::$cached_config = $config;
        
        return $config;
    }
    
    /**
     * 🔥 智能默认配置（开箱即用）
     * 自动检测 Docker 环境和网络配置
     */
    private static function get_smart_default_config() {
        // 🔥 检测是否在 Docker 容器内
        $is_docker = file_exists('/.dockerenv') || getenv('DOCKER_ENV') === 'true';
        
        // 🔥 使用固定的 merchant_id（与管理后台一致）
        // 管理后台默认使用 'default'，这里也统一使用 'default'
        $merchant_id = 'default';
        
        // 🔥 智能选择后端地址
        if ($is_docker) {
            // Docker 环境：使用容器名称（与 docker-compose.yml 中的服务名一致）
            $api_host = 'hyperf';
            $api_protocol = 'http';
            $ws_protocol = 'ws';
        } else {
            // 非 Docker 环境：根据当前站点 URL 判断
            $site_url = get_site_url();
            $is_local = (strpos($site_url, 'localhost') !== false || strpos($site_url, '127.0.0.1') !== false);
            
            if ($is_local) {
                // 本地开发环境
                $api_host = 'localhost';
                $api_protocol = 'http';
                $ws_protocol = 'ws';
            } else {
                // 生产环境：使用当前域名
                $parsed = parse_url($site_url);
                $api_host = $parsed['host'];
                $api_protocol = $parsed['scheme'];
                $ws_protocol = ($api_protocol === 'https') ? 'wss' : 'ws';
            }
        }
        
        // 🔥 构建完整配置
        // 注意：WebSocket URL 不包含端口号，因为通过 Nginx 代理（80/443端口）
        $ws_url = ($ws_protocol === 'wss') 
            ? "{$ws_protocol}://{$api_host}/ws"  // HTTPS 使用 443 端口（默认）
            : "{$ws_protocol}://{$api_host}:9502/ws";  // HTTP 使用 9502 端口（直接连接）
        
        $config = [
            'enabled' => true,
            'api_url' => "{$api_protocol}://{$api_host}:9501",
            'ws_url' => $ws_url,
            'websocket' => [
                'url' => $ws_url,
                'port' => ($ws_protocol === 'wss') ? 443 : 9502,
                'path' => '/ws',
                'protocol' => $ws_protocol,
            ],
            'plugin_token' => '',
            'merchant_id' => $merchant_id,
            'threeds_redirect_url' => "{$api_protocol}://{$api_host}:9501/stripe",
            'api_endpoints' => [
                'base_url' => "{$api_protocol}://{$api_host}:9501",
                'create_payment' => "{$api_protocol}://{$api_host}:9501/api/payment/create",
                'verify_payment' => "{$api_protocol}://{$api_host}:9501/api/payment/verify",
                'refund' => "{$api_protocol}://{$api_host}:9501/api/payment/refund",
            ],
            'ssl_enabled' => ($api_protocol === 'https'),
            'auto_configured' => true, // 标记为自动配置
            'environment' => $is_docker ? 'docker' : 'standalone',
        ];
        
        
        return $config;
    }
    
    /**
     * ✅ 获取备用配置（API 不可用时）
     * ⚠️ 只在 API 请求失败时使用
     */
    private static function get_fallback_config() {
        error_log('[CPG Config] ⚠️ API 请求失败，使用智能默认配置作为备用');
        return self::get_smart_default_config();
    }
    
    /**
     * ✅ 获取网关配置选项
     */
    public static function get_gateway_option($key, $default = '') {
        $options = get_option('woocommerce_clean_payment_gateway_settings', []);
        return isset($options[$key]) ? $options[$key] : $default;
    }
    
    /**
     * ✅ 获取 API 域名
     */
    public static function get_api_domain() {
        $config = self::fetch_config_from_api();
        // 从 api_endpoints.base_url 或旧的 api_url 字段获取
        return $config['api_endpoints']['base_url'] ?? $config['api_url'] ?? 'http://localhost:9501';
    }
    
    /**
     * ✅ 获取 WebSocket 域名
     */
    public static function get_ws_domain() {
        $config = self::fetch_config_from_api();
        // 从 websocket.url 或旧的 ws_url 字段获取
        $ws_url = $config['websocket']['url'] ?? $config['ws_url'] ?? 'ws://localhost:9502/ws';
        // 🔥 确保 URL 不包含入口路径（移除任何 /QWeL4v 或类似的路径）
        $ws_url = preg_replace('#/[a-zA-Z0-9]{6}/websocket/\d+#', '/ws', $ws_url);
        return $ws_url;
    }
    
    /**
     * ✅ 获取 3DS 验证域名
     * 🔥 从 API 配置中获取，或自动构建
     */
    public static function get_3ds_domain() {
        $config = self::fetch_config_from_api();
        
        // 优先使用 API 返回的 3DS URL
        if (!empty($config['threeds_redirect_url'])) {
            return $config['threeds_redirect_url'];
        }
        
        // 如果没有，根据当前域名自动构建
        $current_domain = self::get_current_domain();
        $is_localhost = (strpos($current_domain, 'localhost') !== false || strpos($current_domain, '127.0.0.1') !== false);
        $protocol = $is_localhost ? 'http' : 'https';
        
        return "{$protocol}://{$current_domain}/stripe";
    }
    
    /**
     * ✅ 获取插件 Token
     */
    public static function get_plugin_token() {
        $config = self::fetch_config_from_api();
        return $config['plugin_token'] ?? '';
    }
    
    /**
     * ✅ 获取商户 ID
     */
    public static function get_merchant_id() {
        $config = self::fetch_config_from_api();
        // 🔥 统一使用 'default'，与管理后台一致
        return $config['merchant_id'] ?? 'default';
    }
    
    /**
     * ✅ 获取所有 API 端点
     */
    public static function get_api_endpoints() {
        $config = self::fetch_config_from_api();
        return $config['api_endpoints'] ?? [
            'base_url' => 'http://localhost:9501',
            'create_payment' => 'http://localhost:9501/api/payment/create',
            'verify_payment' => 'http://localhost:9501/api/payment/verify',
            'refund' => 'http://localhost:9501/api/payment/refund',
        ];
    }
    
    
    /**
     * 🔥 自动获取当前 WordPress 站点域名
     * 
     * @return string 当前域名（例如：localhost:8080 或 myshop.com）
     */
    private static function get_current_domain() {
        // 获取当前站点 URL
        $site_url = get_site_url();
        
        // 解析 URL，提取域名和端口
        $parsed = parse_url($site_url);
        $domain = $parsed['host'];
        
        // 如果有非标准端口，添加端口号
        if (isset($parsed['port']) && $parsed['port'] != 80 && $parsed['port'] != 443) {
            $domain .= ':' . $parsed['port'];
        }
        
        return $domain;
    }

    /**
     * 🔥 从入口地址提取基础地址
     * 
     * @param string $entry_url 入口地址（例如：http://localhost:9501/stripe）
     * @return string 基础地址（例如：http://localhost:9501）
     */
    private static function extract_base_url($entry_url) {
        // 🔥 如果没有协议，自动添加 http://
        if (!preg_match('/^https?:\/\//', $entry_url)) {
            $entry_url = 'http://' . $entry_url;
        }
        
        // 解析 URL
        $parsed = parse_url($entry_url);
        
        // 🔥 如果缺少 scheme，默认使用 http
        $scheme = isset($parsed['scheme']) ? $parsed['scheme'] : 'http';
        $host = isset($parsed['host']) ? $parsed['host'] : '';
        
        // 🔥 如果解析失败，直接返回原 URL
        if (empty($host)) {
            error_log('[CPG Config] ⚠️ URL 解析失败，返回原 URL: ' . $entry_url);
            return $entry_url;
        }
        
        // 🔥 智能处理 Docker 环境
        $is_docker = file_exists('/.dockerenv') || getenv('DOCKER_ENV') === 'true';
        
        if ($is_docker && ($host === 'localhost' || $host === '127.0.0.1')) {
            // 在 Docker 容器内部，将 localhost/127.0.0.1 替换为容器名称
            $host = 'hyperf';
        }
        
        // 构建基础地址（不包含路径）
        $base_url = $scheme . '://' . $host;
        
        // 如果有端口，添加端口
        if (isset($parsed['port'])) {
            $base_url .= ':' . $parsed['port'];
        }
        
        
        return $base_url;
    }

    /**
     * 🔥 构建完整的配置 API URL
     * 
     * @param string $entry_url 入口地址（例如：http://localhost:9501/stripe）
     * @param string $domain 当前 WordPress 域名
     * @return string 完整的配置 API URL
     */
    private static function build_config_url($entry_url, $domain) {
        // 提取基础地址
        $base_url = self::extract_base_url($entry_url);
        
        // 🔥 自动构建：基础地址 + API 路径 + 域名参数
        return $base_url . '/api/plugin/config?domain=' . urlencode($domain);
    }
    
    /**
     * ✅ 获取完整的前端配置（注入到 JavaScript）
     * 🔥 确保格式与 WebSocket 客户端期望的一致
     */
    public static function get_frontend_config() {
        // 获取完整配置（包括智能默认配置）
        $full_config = self::fetch_config_from_api();
        $api_endpoints = $full_config['api_endpoints'] ?? self::get_api_endpoints();
        
        // 🔥 构建前端配置
        $frontend_config = [
            // 基础配置
            'api_url' => $full_config['api_url'] ?? self::get_api_domain(),
            'ws_url' => $full_config['ws_url'] ?? self::get_ws_domain(), // 🔥 WebSocket 客户端期望这个字段
            'threeds_url' => $full_config['threeds_redirect_url'] ?? self::get_3ds_domain(), // 🔥 3D 验证入口 URL
            'plugin_token' => $full_config['plugin_token'] ?? self::get_plugin_token(),
            'merchant_id' => $full_config['merchant_id'] ?? self::get_merchant_id(),
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cpg_payment_nonce'),
            'plugin_url' => CPG_PLUGIN_URL, // 🔥 插件目录URL
            
            // 🔥 所有 API 端点
            'api_endpoints' => $api_endpoints,
            
            // 🔥 WordPress 相关信息
            'site_url' => get_site_url(),
            'site_name' => get_bloginfo('name'),
            
            // 🔥 user-tracking.js 需要的字段
            'enabled' => $full_config['enabled'] ?? true, // 使用配置中的启用状态
            'order_prefix' => 'WP', // 订单前缀
            
            // 🔥 高级选项
            'show_close_button' => self::get_gateway_option('show_close_button', 'no') === 'yes',
            'fbq_tracking' => self::get_gateway_option('fbq_tracking', 'no') === 'yes',
            
            // 🔥 调试信息（生产环境会隐藏）
            'debug' => defined('WP_DEBUG') && WP_DEBUG,
            'environment' => $full_config['environment'] ?? self::get_current_environment(),
            'auto_configured' => $full_config['auto_configured'] ?? false, // 标记是否自动配置
        ];
        
        // 🔥 如果是自动配置，记录日志
        if (!empty($full_config['auto_configured'])) {
        }
        
        return $frontend_config;
    }
    
    /**
     * ✅ 获取当前环境
     */
    public static function get_current_environment() {
        // 根据站点 URL 判断环境
        $site_url = get_site_url();
        
        if (strpos($site_url, 'localhost') !== false || strpos($site_url, '127.0.0.1') !== false) {
            return 'local';
        }
        
        if (defined('WP_ENVIRONMENT_TYPE')) {
            return WP_ENVIRONMENT_TYPE;
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            return 'development';
        }
        
        return 'production';
    }
    
    /**
     * ✅ 刷新配置（手动触发）
     */
    public static function refresh_config() {
        delete_option('cpg_api_config_cache');
        delete_option('cpg_api_config_cache_time');
        self::$cached_config = null;
        
        return self::fetch_config_from_api(true);
    }
    
    /**
     * ✅ 验证配置是否完整
     */
    public static function validate_config() {
        $config = self::fetch_config_from_api();
        $errors = [];
        
        if (empty($config['api_url'])) {
            $errors[] = 'API 域名未配置';
        }
        
        if (empty($config['ws_url'])) {
            $errors[] = 'WebSocket 域名未配置';
        }
        
        if (empty($config['plugin_token'])) {
            $errors[] = '插件 Token 未生成';
        }
        
        return $errors;
    }
}

