<?php
/**
 * 资源加载类
 * 
 * 注意：脚本加载逻辑已移至：
 * - class-cpg-gateway.php (payment_fields, enqueue_payment_scripts)
 * - class-cpg-3d-verification.php (enqueue_verification_assets)
 * 
 * 此类保留用于向后兼容，可能在未来版本移除。
 *
 * @package Welcome_Payment_Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}

final class CPG_Assets {

    private static $instance = null;
    
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * 初始化（保留用于向后兼容）
     */
    public static function init() {
        // 脚本加载已移至 class-cpg-gateway.php 和 class-cpg-3d-verification.php
        // 此处不再执行任何操作
    }
}

