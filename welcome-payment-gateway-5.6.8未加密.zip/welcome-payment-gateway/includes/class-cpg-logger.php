<?php
/**
 * 调试日志类
 *
 * @package Welcome_Payment_Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}

class CPG_Logger {
    
    private static $log_file = null;
    private static $enabled = null;
    private static $log_level = 'info'; // debug, info, warning, error
    private static $max_log_files = 7; // 保留最近7天的日志
    
    public static function init() {
        $upload_dir = wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/cpg-logs';
        
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
            file_put_contents($log_dir . '/.htaccess', 'Deny from all');
            file_put_contents($log_dir . '/index.php', '<?php // Silence is golden');
        }
        
        self::$log_file = $log_dir . '/cpg-' . date('Y-m-d') . '.log';
        
        // 支持独立的日志开关，不依赖 WP_DEBUG
        if (defined('CPG_ENABLE_LOGGING')) {
            self::$enabled = CPG_ENABLE_LOGGING;
        } else {
            // 默认在生产环境关闭详细日志
            self::$enabled = defined('WP_DEBUG') && WP_DEBUG;
        }
        
        // 日志级别控制
        if (defined('CPG_LOG_LEVEL')) {
            self::$log_level = CPG_LOG_LEVEL;
        }
        
        // 清理旧日志文件
        self::cleanup_old_logs($log_dir);
    }
    
    /**
     * 清理超过保留天数的旧日志
     */
    private static function cleanup_old_logs($log_dir) {
        $files = glob($log_dir . '/cpg-*.log');
        if (count($files) > self::$max_log_files) {
            // 按修改时间排序
            usort($files, function($a, $b) {
                return filemtime($a) - filemtime($b);
            });
            // 删除最旧的文件
            $to_delete = array_slice($files, 0, count($files) - self::$max_log_files);
            foreach ($to_delete as $file) {
                @unlink($file);
            }
        }
    }
    
    public static function debug($message, $context = []) {
        self::log('DEBUG', $message, $context);
    }
    
    public static function info($message, $context = []) {
        self::log('INFO', $message, $context);
    }
    
    public static function warning($message, $context = []) {
        self::log('WARNING', $message, $context);
    }
    
    public static function error($message, $context = []) {
        self::log('ERROR', $message, $context);
    }
    
    public static function websocket($message, $data = []) {
        self::log('WEBSOCKET', $message, $data);
    }
    
    private static function log($level, $message, $context = []) {
        if (self::$enabled === null) {
            self::init();
        }
        
        if (!self::$enabled) {
            return;
        }
        
        // 日志级别过滤
        $levels = ['debug' => 0, 'info' => 1, 'warning' => 2, 'error' => 3, 'websocket' => 1];
        $current_level = $levels[strtolower(self::$log_level)] ?? 1;
        $log_level = $levels[strtolower($level)] ?? 1;
        
        if ($log_level < $current_level) {
            return; // 低于当前日志级别，不记录
        }
        
        $timestamp = current_time('Y-m-d H:i:s');
        $context_str = !empty($context) ? ' | ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
        
        $log_entry = sprintf(
            "[%s] [%s] %s%s\n",
            $timestamp,
            $level,
            $message,
            $context_str
        );
        
        if (self::$log_file) {
            error_log($log_entry, 3, self::$log_file);
        }
        
        // ERROR 级别同时写入 WordPress 错误日志
        if ($level === 'ERROR') {
            error_log('[CPG] ' . $message);
        }
    }
    
    /**
     * 获取日志目录路径
     */
    public static function get_log_dir() {
        $upload_dir = wp_upload_dir();
        return $upload_dir['basedir'] . '/cpg-logs';
    }
    
    /**
     * 获取最新日志内容（用于调试界面）
     */
    public static function get_recent_logs($lines = 100) {
        if (self::$log_file === null) {
            self::init();
        }
        
        if (!file_exists(self::$log_file)) {
            return [];
        }
        
        $file = file(self::$log_file);
        return array_slice($file, -$lines);
    }
}

