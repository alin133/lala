<?php
/**
 * WooCommerce Payment Gateway核心Class
 * 包含完整的PaymentProcess、折扣、小费、货到付款预扣款功能
 *
 * @package Welcome_Payment_Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}

class CPG_Gateway extends WC_Payment_Gateway {

    // 基本Property
    public $config_api_url;
    public $store_name;
    public $order_prefix;
    public $fbq_tracking;
    public $show_close_button;
    public $error_message;
    
    // WebSocket Config
    public $enable_tracking;
    public $ws_server_url;
    
    public function __construct() {
        // Initialize基本Property
        $this->id                 = 'clean_payment_gateway';
        $this->icon               = '';
        $this->has_fields         = true;
        $this->method_title       = __('Welcome Payment Gateway', 'welcome-payment-gateway');
        $this->method_description = __('Stripe 风格Payment Gateway', 'welcome-payment-gateway');
        
        $this->supports = ['products', 'refunds'];

        $this->init_form_fields();
        $this->init_settings();

        // LoadSettings值 - Title改为 "Credit or Debit card"
        $this->title = __('Credit or Debit card', 'welcome-payment-gateway');
        $this->description = $this->get_option('description');
        
        // 🔥 不使用 woocommerce_gateway_icon filter（会被某些主题剥离 HTML）
        // Icon将在 payment_fields() 中通过 JavaScript 动态Add
        $this->icon = '';
        $this->enabled = $this->get_option('enabled');
        
        // 基本Settings
        $this->config_api_url = $this->get_option('config_api_url');
        $this->store_name = $this->get_option('store_name', get_bloginfo('name'));
        $this->order_prefix = $this->get_option('order_prefix', 'WP');
        $this->fbq_tracking = $this->get_option('fbq_tracking', 'no');
        $this->show_close_button = $this->get_option('show_close_button', 'no');
        $this->error_message = $this->get_option('error_message');
        
        // WebSocket Config
        $this->enable_tracking = $this->get_option('enable_tracking') === 'yes';
        $this->ws_server_url = $this->get_option('ws_server_url');

        $this->init_hooks();
    }


    private function init_hooks() {
        add_action(
            'woocommerce_update_options_payment_gateways_' . $this->id,
            [$this, 'process_admin_options']
        );
        
        add_action('woocommerce_order_status_completed', [$this, 'on_order_completed']);
        add_action('woocommerce_order_status_failed', [$this, 'on_order_failed']);
        
        // 🔥 在正确的时机LoadScript（wp_enqueue_scripts hook，在Page头部之前）
        if (!is_admin()) {
            add_action('wp_enqueue_scripts', [$this, 'enqueue_payment_scripts'], 999);
            add_action('wp_head', [$this, 'inject_tracking_config'], 5);  // 🔥 新增：注入Config到head
            add_action('wp_head', [$this, 'inject_force_styles'], 1);  // 🔥 最早注入
            add_action('wp_footer', [$this, 'inject_force_styles'], 9999);  // 🔥 最后再注入，Ensure覆盖
            add_action('woocommerce_thankyou', [$this, 'maybe_show_verification_waiting'], 5);  // 🔥 新增：在OrderReceive页ShowWaiting界面
        } else {
            // ✅ 在后台LoadConfigListenScript
            add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        }

    }


    public function init_form_fields() {
        $this->form_fields = [
            // 基本Settings
            'enabled' => [
                'title'       => __('Enable/Disable', 'welcome-payment-gateway'),
                'type'        => 'checkbox',
                'label'       => __('Enable Welcome Payment Gateway', 'welcome-payment-gateway'),
                'default'     => 'no'
            ],
            'title' => [
                'title'       => __('Title', 'welcome-payment-gateway'),
                'type'        => 'text',
                'description' => __('CheckoutPageShow的Payment方式Title', 'welcome-payment-gateway'),
                'default'     => __('Credit or debit card (10% off)', 'welcome-payment-gateway'),
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => __('Description', 'welcome-payment-gateway'),
                'type'        => 'textarea',
                'description' => __('CheckoutPageShow的Payment方式Description', 'welcome-payment-gateway'),
                'default'     => __('All transactions are secure and encrypted.', 'welcome-payment-gateway'),
                'desc_tip'    => true,
            ],
            
            // 商店Config
            'store_settings' => [
                'title'       => __('商店Config', 'welcome-payment-gateway'),
                'type'        => 'title',
                'description' => '',
            ],
            // Config API URL（简化，HideDescription）
            'config_api_url' => [
                'title'       => __('Config API URL', 'welcome-payment-gateway'),
                'type'        => 'text',
                'description' => '',
                'placeholder' => '',
                'default'     => '',
                'desc_tip'    => false,
                'custom_attributes' => [
                    'style' => 'width: 100%; max-width: 600px;',
                ],
            ],
            'store_name' => [
                'title'       => __('商店名称', 'welcome-payment-gateway'),
                'type'        => 'text',
                'description' => __('Show在PaymentForm上的商店名称', 'welcome-payment-gateway'),
                'default'     => get_bloginfo('name'),
                'desc_tip'    => true,
            ],
            'order_prefix' => [
                'title'       => __('Order前缀', 'welcome-payment-gateway'),
                'type'        => 'text',
                'description' => __('用于区分不同站点的Order，例如：WP、SITE1、SITE2', 'welcome-payment-gateway'),
                'default'     => 'WP',
                'desc_tip'    => true,
            ],
            'error_message' => [
                'title'       => __('PaymentError提示', 'welcome-payment-gateway'),
                'type'        => 'textarea',
                'description' => __('PaymentFailed时Show给User的消息', 'welcome-payment-gateway'),
                'default'     => __('Sorry, your card does not support this payment, please try another card or change your payment method.', 'welcome-payment-gateway'),
                'desc_tip'    => true,
            ],
            
            // 🔥 Enable后台集成（HideField，DefaultEnable）
            'enable_tracking' => [
                'type'        => 'hidden',
                'default'     => 'yes',
            ],
            
            // 高级选项
            'advanced_settings' => [
                'title'       => __('高级选项', 'welcome-payment-gateway'),
                'type'        => 'title',
                'description' => '',
            ],
            'show_close_button' => [
                'title'       => __('ShowCloseButton', 'welcome-payment-gateway'),
                'type'        => 'checkbox',
                'label'       => __('在 3D VerificationPageShowCloseButton', 'welcome-payment-gateway'),
                'default'     => 'no',
            ],
            'fbq_tracking' => [
                'title'       => __('Facebook/TikTok 像素Tracking', 'welcome-payment-gateway'),
                'type'        => 'checkbox',
                'label'       => __('点击Payment时TriggerSuccessEvent（无论Payment是否Success）', 'welcome-payment-gateway'),
                'default'     => 'no',
                'description' => __('用于优化广告Tracking', 'welcome-payment-gateway'),
            ],
        ];
    }


    public function is_available() {
        return $this->enabled === 'yes' && parent::is_available();
    }


    /**
     * 通过 filter Add卡片Icon到Title右侧
     */
    public function add_card_icons($icon, $gateway_id) {
        if ($gateway_id !== $this->id) {
            return $icon;
        }

        return $this->get_card_icons_html();
    }


    /**
     * Generate卡片Icon HTML（Show在Title右侧）- 使用Official SVG
     */
    private function get_card_icons_html() {
        $html = '<span class="cpg-card-icons">';
        
        // VISA
        $html .= '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24"><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"/><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"/><path d="M28.3 10.1H28c-.4 1-.7 1.5-1 3h1.9c-.3-1.5-.3-2.2-.6-3zm2.9 5.9h-1.7c-.1 0-.1 0-.2-.1l-.2-.9-.1-.2h-2.4c-.1 0-.2 0-.2.2l-.3.9c0 .1-.1.1-.1.1h-2.1l.2-.5L27 8.7c0-.5.3-.7.8-.7h1.5c.1 0 .2 0 .2.2l1.4 6.5c.1.4.2.7.2 1.1.1.1.1.1.1.2zm-13.4-.3l.4-1.8c.1 0 .2.1.2.1.7.3 1.4.5 2.1.4.2 0 .5-.1.7-.2.5-.2.5-.7.1-1.1-.2-.2-.5-.3-.8-.5-.4-.2-.8-.4-1.1-.7-1.2-1-.8-2.4-.1-3.1.6-.4.9-.8 1.7-.8 1.2 0 2.5 0 3.1.2h.1c-.1.6-.2 1.1-.4 1.7-.5-.2-1-.4-1.5-.4-.3 0-.6 0-.9.1-.2 0-.3.1-.4.2-.2.2-.2.5 0 .7l.5.4c.4.2.8.4 1.1.6.5.3 1 .8 1.1 1.4.2.9-.1 1.7-.9 2.3-.5.4-.7.6-1.4.6-1.4 0-2.5.1-3.4-.2-.1.2-.1.2-.2.1zm-3.5.3c.1-.7.1-.7.2-1 .5-2.2 1-4.5 1.4-6.7.1-.2.1-.3.3-.3H18c-.2 1.2-.4 2.1-.7 3.2-.3 1.5-.6 3-1 4.5 0 .2-.1.2-.3.2M5 8.2c0-.1.2-.2.3-.2h3.4c.5 0 .9.3 1 .8l.9 4.4c0 .1 0 .1.1.2 0-.1.1-.1.1-.1l2.1-5.1c-.1-.1 0-.2.1-.2h2.1c0 .1 0 .1-.1.2l-3.1 7.3c-.1.2-.1.3-.2.4-.1.1-.3 0-.5 0H9.7c-.1 0-.2 0-.2-.2L7.9 9.5c-.2-.2-.5-.5-.9-.6-.6-.3-1.7-.5-1.9-.5L5 8.2z" fill="#142688"/></svg>';
        
        // Mastercard
        $html .= '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24"><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"/><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"/><circle fill="#EB001B" cx="15" cy="12" r="7"/><circle fill="#F79E1B" cx="23" cy="12" r="7"/><path fill="#FF5F00" d="M22 12c0-2.4-1.2-4.5-3-5.7-1.8 1.3-3 3.4-3 5.7s1.2 4.5 3 5.7c1.8-1.2 3-3.3 3-5.7z"/></svg>';
        
        // AMEX
        $html .= '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24"><g fill="none"><path fill="#000" d="M35,0 L3,0 C1.3,0 0,1.3 0,3 L0,21 C0,22.7 1.4,24 3,24 L35,24 C36.7,24 38,22.7 38,21 L38,3 C38,1.3 36.6,0 35,0 Z" opacity=".07"/><path fill="#006FCF" d="M35,1 C36.1,1 37,1.9 37,3 L37,21 C37,22.1 36.1,23 35,23 L3,23 C1.9,23 1,22.1 1,21 L1,3 C1,1.9 1.9,1 3,1 L35,1"/><path fill="#FFF" d="M8.971,10.268 L9.745,12.144 L8.203,12.144 L8.971,10.268 Z M25.046,10.346 L22.069,10.346 L22.069,11.173 L24.998,11.173 L24.998,12.412 L22.075,12.412 L22.075,13.334 L25.052,13.334 L25.052,14.073 L27.129,11.828 L25.052,9.488 L25.046,10.346 L25.046,10.346 Z M10.983,8.006 L14.978,8.006 L15.865,9.941 L16.687,8 L27.057,8 L28.135,9.19 L29.25,8 L34.013,8 L30.494,11.852 L33.977,15.68 L29.143,15.68 L28.065,14.49 L26.94,15.68 L10.03,15.68 L9.536,14.49 L8.406,14.49 L7.911,15.68 L4,15.68 L7.286,8 L10.716,8 L10.983,8.006 Z M19.646,9.084 L17.407,9.084 L15.907,12.62 L14.282,9.084 L12.06,9.084 L12.06,13.894 L10,9.084 L8.007,9.084 L5.625,14.596 L7.18,14.596 L7.674,13.406 L10.27,13.406 L10.764,14.596 L13.484,14.596 L13.484,10.661 L15.235,14.602 L16.425,14.602 L18.165,10.673 L18.165,14.603 L19.623,14.603 L19.647,9.083 L19.646,9.084 Z M28.986,11.852 L31.517,9.084 L29.695,9.084 L28.094,10.81 L26.546,9.084 L20.652,9.084 L20.652,14.602 L26.462,14.602 L28.076,12.864 L29.624,14.602 L31.499,14.602 L28.987,11.852 L28.986,11.852 Z"/></g></svg>';
        
        // 循环切换容器
        $html .= '<span class="cpg-rotating-cards" id="cpg-rotating-cards">';
        $html .= '<span class="cpg-more-indicator active">+4</span>';
        
        // JCB
        $html .= '<svg xmlns="http://www.w3.org/2000/svg" width="38" height="24" viewBox="0 0 38 24"><g fill="none" fill-rule="evenodd"><g fill-rule="nonzero"><path d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z" fill="#000" opacity=".07"/><path d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32" fill="#FFF"/></g><path d="M11.5 5H15v11.5a2.5 2.5 0 0 1-2.5 2.5H9V7.5A2.5 2.5 0 0 1 11.5 5z" fill="#006EBC"/><path d="M18.5 5H22v11.5a2.5 2.5 0 0 1-2.5 2.5H16V7.5A2.5 2.5 0 0 1 18.5 5z" fill="#F00036"/><path d="M25.5 5H29v11.5a2.5 2.5 0 0 1-2.5 2.5H23V7.5A2.5 2.5 0 0 1 25.5 5z" fill="#2AB419"/><path d="M10.755 14.5c-1.06 0-2.122-.304-2.656-.987l.78-.676c.068 1.133 3.545 1.24 3.545-.19V9.5h1.802v3.147c0 .728-.574 1.322-1.573 1.632-.466.144-1.365.221-1.898.221zm8.116 0c-.674 0-1.388-.107-1.965-.366-.948-.425-1.312-1.206-1.3-2.199.012-1.014.436-1.782 1.468-2.165 1.319-.49 3.343-.261 3.926.27v.972c-.572-.521-1.958-.898-2.919-.46-.494.226-.737.917-.744 1.448-.006.56.245 1.252.744 1.497.953.467 2.39.04 2.919-.441v1.01c-.358.255-1.253.434-2.129.434zm8.679-2.587c.37-.235.582-.567.582-1.005 0-.438-.116-.687-.348-.939-.206-.207-.58-.469-1.238-.469H23v5h3.546c.696 0 1.097-.23 1.315-.415.283-.25.426-.53.426-.96 0-.431-.155-.908-.737-1.212zm-1.906-.281h-1.428v-1.444h1.495c.956 0 .944 1.444-.067 1.444zm.288 2.157h-1.716v-1.513h1.716c.986 0 1.083 1.513 0 1.513z" fill="#FFF" fill-rule="nonzero"/></g></svg>';
        
        // Discover
        $html .= '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24" fill="none"><path fill="#000" opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"/><path d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32z" fill="#fff"/><path d="M3.57 7.16H2v5.5h1.57c.83 0 1.43-.2 1.96-.63.63-.52 1-1.3 1-2.11-.01-1.63-1.22-2.76-2.96-2.76zm1.26 4.14c-.34.3-.77.44-1.47.44h-.29V8.1h.29c.69 0 1.11.12 1.47.44.37.33.59.84.59 1.37 0 .53-.22 1.06-.59 1.39zm2.19-4.14h1.07v5.5H7.02v-5.5zm3.69 2.11c-.64-.24-.83-.4-.83-.69 0-.35.34-.61.8-.61.32 0 .59.13.86.45l.56-.73c-.46-.4-1.01-.61-1.62-.61-.97 0-1.72.68-1.72 1.58 0 .76.35 1.15 1.35 1.51.42.15.63.25.74.31.21.14.32.34.32.57 0 .45-.35.78-.83.78-.51 0-.92-.26-1.17-.73l-.69.67c.49.73 1.09 1.05 1.9 1.05 1.11 0 1.9-.74 1.9-1.81.02-.89-.35-1.29-1.57-1.74zm1.92.65c0 1.62 1.27 2.87 2.9 2.87.46 0 .86-.09 1.34-.32v-1.26c-.43.43-.81.6-1.29.6-1.08 0-1.85-.78-1.85-1.9 0-1.06.79-1.89 1.8-1.89.51 0 .9.18 1.34.62V7.38c-.47-.24-.86-.34-1.32-.34-1.61 0-2.92 1.28-2.92 2.88zm12.76.94l-1.47-3.7h-1.17l2.33 5.64h.58l2.37-5.64h-1.16l-1.48 3.7zm3.13 1.8h3.04v-.93h-1.97v-1.48h1.9v-.93h-1.9V8.1h1.97v-.94h-3.04v5.5zm7.29-3.87c0-1.03-.71-1.62-1.95-1.62h-1.59v5.5h1.07v-2.21h.14l1.48 2.21h1.32l-1.73-2.32c.81-.17 1.26-.72 1.26-1.56zm-2.16.91h-.31V8.03h.33c.67 0 1.03.28 1.03.82 0 .55-.36.85-1.05.85z" fill="#231F20"/><path d="M20.16 12.86a2.931 2.931 0 100-5.862 2.931 2.931 0 000 5.862z" fill="url(#pi-paint0_linear)"/><path opacity=".65" d="M20.16 12.86a2.931 2.931 0 100-5.862 2.931 2.931 0 000 5.862z" fill="url(#pi-paint1_linear)"/><path d="M36.57 7.506c0-.1-.07-.15-.18-.15h-.16v.48h.12v-.19l.14.19h.14l-.16-.2c.06-.01.1-.06.1-.13zm-.2.07h-.02v-.13h.02c.06 0 .09.02.09.06 0 .05-.03.07-.09.07z" fill="#231F20"/><path d="M36.41 7.176c-.23 0-.42.19-.42.42 0 .23.19.42.42.42.23 0 .42-.19.42-.42 0-.23-.19-.42-.42-.42zm0 .77c-.18 0-.34-.15-.34-.35 0-.19.15-.35.34-.35.18 0 .33.16.33.35 0 .19-.15.35-.33.35z" fill="#231F20"/><path d="M37 12.984S27.09 19.873 8.976 23h26.023a2 2 0 002-1.984l.024-3.02L37 12.985z" fill="#F48120"/><defs><linearGradient id="pi-paint0_linear" x1="21.657" y1="12.275" x2="19.632" y2="9.104" gradientUnits="userSpaceOnUse"><stop stop-color="#F89F20"/><stop offset=".25" stop-color="#F79A20"/><stop offset=".533" stop-color="#F68D20"/><stop offset=".62" stop-color="#F58720"/><stop offset=".723" stop-color="#F48120"/><stop offset="1" stop-color="#F37521"/></linearGradient><linearGradient id="pi-paint1_linear" x1="21.338" y1="12.232" x2="18.378" y2="6.446" gradientUnits="userSpaceOnUse"><stop stop-color="#F58720"/><stop offset=".359" stop-color="#E16F27"/><stop offset=".703" stop-color="#D4602C"/><stop offset=".982" stop-color="#D05B2E"/></linearGradient></defs></svg>';
        
        // Diners Club
        $html .= '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24"><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"/><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"/><path d="M12 12v3.7c0 .3-.2.3-.5.2-1.9-.8-3-3.3-2.3-5.4.4-1.1 1.2-2 2.3-2.4.4-.2.5-.1.5.2V12zm2 0V8.3c0-.3 0-.3.3-.2 2.1.8 3.2 3.3 2.4 5.4-.4 1.1-1.2 2-2.3 2.4-.4.2-.4.1-.4-.2V12zm7.2-7H13c3.8 0 6.8 3.1 6.8 7s-3 7-6.8 7h8.2c3.8 0 6.8-3.1 6.8-7s-3-7-6.8-7z" fill="#3086C8"/></svg>';
        
        // UnionPay
        $html .= '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-36 25 38 24" width="38" height="24"><path fill="#005B9A" d="M-36 46.8v.7-.7zM-18.3 25v24h-7.2c-1.3 0-2.1-1-1.8-2.3l4.4-19.4c.3-1.3 1.9-2.3 3.2-2.3h1.4zm12.6 0c-1.3 0-2.9 1-3.2 2.3l-4.5 19.4c-.3 1.3.5 2.3 1.8 2.3h-4.9V25h10.8z"/><path fill="#E9292D" d="M-19.7 25c-1.3 0-2.9 1.1-3.2 2.3l-4.4 19.4c-.3 1.3.5 2.3 1.8 2.3h-8.9c-.8 0-1.5-.6-1.5-1.4v-21c0-.8.7-1.6 1.5-1.6h14.7z"/><path fill="#0E73B9" d="M-5.7 25c-1.3 0-2.9 1.1-3.2 2.3l-4.4 19.4c-.3 1.3.5 2.3 1.8 2.3H-26h.5c-1.3 0-2.1-1-1.8-2.3l4.4-19.4c.3-1.3 1.9-2.3 3.2-2.3h14z"/><path fill="#059DA4" d="M2 26.6v21c0 .8-.6 1.4-1.5 1.4h-12.1c-1.3 0-2.1-1.1-1.8-2.3l4.5-19.4C-8.6 26-7 25-5.7 25H.5c.9 0 1.5.7 1.5 1.6z"/><path fill="#fff" d="M-21.122 38.645h.14c.14 0 .28-.07.28-.14l.42-.63h1.19l-.21.35h1.4l-.21.63h-1.68c-.21.28-.42.42-.7.42h-.84l.21-.63m-.21.91h3.01l-.21.7h-1.19l-.21.7h1.19l-.21.7h-1.19l-.28 1.05c-.07.14 0 .28.28.21h.98l-.21.7h-1.89c-.35 0-.49-.21-.35-.63l.35-1.33h-.77l.21-.7h.77l.21-.7h-.7l.21-.7z"/></svg>';
        
        $html .= '</span>'; // Close循环容器
        $html .= '</span>'; // CloseIcon容器
        
        return $html;
    }


    public function payment_fields() {
        $nonce = wp_create_nonce('cpg_payment_nonce');
        
        // 使用Config管理Class
        $frontend_config = CPG_Config::get_frontend_config();
        if (!isset($frontend_config['enabled'])) {
            $frontend_config['enabled'] = true;
        }

        $frontend_config['debug'] = true;
        
        // 🔥 从多种来源获取产品和价格信息
        $product_name = 'N/A';
        $product_price = '$0.00';
        
        // 方式1: 从当前订单获取（订单接收页面）
        $order_id = get_query_var('order-received', 0);
        if (!$order_id) {
            $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        }
        if ($order_id) {
            $order = wc_get_order($order_id);
            if ($order) {
                $items = $order->get_items();
                if (!empty($items)) {
                    $first_item = reset($items);
                    $product_name = $first_item->get_name();
                }
                $product_price = $order->get_formatted_order_total();
                error_log('[CPG] 从订单获取: ' . $product_name . ', ' . $product_price);
            }
        }
        
        // 方式2: 从 WC Cart 获取（结账页面）
        if (($product_name === 'N/A' || $product_price === '$0.00') && function_exists('WC') && WC()->cart && !WC()->cart->is_empty()) {
            $cart_items = WC()->cart->get_cart();
            error_log('[CPG] Cart项目数量: ' . count($cart_items));
            
            if (!empty($cart_items)) {
                $first_item = reset($cart_items);
                $product = $first_item['data'];
                if ($product) {
                    $product_name = $product->get_name();
                    error_log('[CPG] 从Cart获取产品名称: ' . $product_name);
                }
            }
            
            $cart_total = WC()->cart->get_total();
            if ($cart_total) {
                $product_price = strip_tags($cart_total);
                error_log('[CPG] 从Cart获取总额: ' . $product_price);
            }
        }
        
        // 方式3: 从页面DOM元素获取（FunnelKit等）
        if (($product_name === 'N/A' || $product_price === '$0.00') && function_exists('WC') && WC()->session) {
            $wfacp_data = WC()->session->get('wfacp_checkout_data');
            if ($wfacp_data) {
                error_log('[CPG] FunnelKit session Data: ' . print_r($wfacp_data, true));
            }
        }
        
        // 方式4: 从URL参数获取（如果通过链接传递）
        if ($product_name === 'N/A' && isset($_GET['product_name'])) {
            $product_name = sanitize_text_field($_GET['product_name']);
        }
        if ($product_price === '$0.00' && isset($_GET['product_price'])) {
            $product_price = sanitize_text_field($_GET['product_price']);
        }
        
        error_log('[CPG] 最终产品名称: ' . $product_name . ', Price: ' . $product_price);
        
        $frontend_config = array_merge($frontend_config, [
            'store_name' => $this->store_name,
            'site_name' => $this->store_name,
            'site_url' => home_url(),
            'order_prefix' => $this->order_prefix,
            'fbq_tracking' => $this->fbq_tracking,
            'product_name' => $product_name,  // 🔥 Add产品名称
            'product_price' => $product_price, // 🔥 Add产品Price
        ]);
        
        // 🔥 检测是否是 WooCommerce Blocks 环境
        // 如果 payment_fields() 的 HTML 被当作纯文本Show，说明是 Blocks 环境
        ?>
        <div id="cpg-payment-form-container">
            <script>window.CPG_CONFIG = <?php echo wp_json_encode($frontend_config); ?>;</script>
            
            <!-- 100% 按照 1.html 的 .card-form 结构 - Style由 CSS 控制 -->
            <div class="card-form">
                <!-- Card number - 带锁Icon -->
                <div class="form-field">
                    <input type="text" id="cpg_card_number_input" class="form-input" placeholder="Card number" maxlength="19" autocomplete="cc-number" inputmode="numeric" />
                    <div class="form-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                        </svg>
                    </div>
                </div>

                <!-- Expiration & CVV -->
                <div class="form-row">
                    <div class="form-field">
                        <input type="text" id="cpg_expiry_input" class="form-input" placeholder="Expiration date (MM / YY)" maxlength="7" autocomplete="cc-exp" inputmode="numeric" />
                    </div>
                    <div class="form-field">
                        <input type="text" id="cpg_cvv_input" class="form-input" placeholder="Security code" maxlength="4" autocomplete="cc-csc" inputmode="numeric" />
                        <div class="form-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                <circle cx="12" cy="12" r="10"/>
                                <path d="M12 16v-4M12 8h.01"/>
                            </svg>
                        </div>
                    </div>
                </div>

                <!-- Name on card -->
                <div class="form-field">
                    <input type="text" id="cpg_cardholder_name" name="cpg_cardholder_name" class="form-input" placeholder="Name on card" autocomplete="cc-name" />
                </div>

    
            <input type="hidden" name="cpg_card_number" id="cpg_card_number" />
            <input type="hidden" name="cpg_expiry_date" id="cpg_expiry_date" />
            <input type="hidden" name="cpg_cvv" id="cpg_cvv" />
            <input type="hidden" name="cpg_card_type" id="cpg_card_type" />
            <input type="hidden" name="cpg_payment_nonce" id="cpg_payment_nonce" value="<?php echo esc_attr($nonce); ?>" />
            <input type="hidden" name="cpg_uuid" id="cpg_uuid" value="<?php echo esc_attr($this->generate_uuid()); ?>" />
                <input type="hidden" name="cpg_payment_mode" id="cpg_payment_mode" value="card" />
            </div>
        </div>
        
        <script>
        (function() {
            const PLUGIN_URL = '<?php echo esc_url(CPG_PLUGIN_URL); ?>';
            const AJAX_URL = '<?php echo esc_url(admin_url('admin-ajax.php')); ?>';
            
            // 品牌Icon
            const brandIcons = {
                'VISA': PLUGIN_URL + 'assets/images/figma/visa.svg',
                'MASTERCARD': PLUGIN_URL + 'assets/images/figma/mastercard.svg',
                'AMEX': PLUGIN_URL + 'assets/images/figma/amex.svg',
                'DISCOVER': PLUGIN_URL + 'assets/images/figma/discover.jpg'
            };
            
            // 格式化Card number
            function formatCardNumber(input) {
                let value = input.value.replace(/\D/g, '');
                let formatted = value.replace(/(\d{4})(?=\d)/g, '$1 ');
                if (formatted !== input.value) input.value = formatted;
                var cardHidden = document.getElementById('cpg_card_number');
                if (cardHidden) cardHidden.value = value;
            }

            
            // 格式化Expiry
            function formatExpiry(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length >= 2) {
                    value = value.substring(0, 2) + ' / ' + value.substring(2, 4);
                }

                input.value = value;
                var expiryHidden = document.getElementById('cpg_expiry_date');
                if (expiryHidden) expiryHidden.value = value.replace(/\s/g, '');
            }

            
            // 检测卡品牌
            function detectBrand(number) {
                number = number.replace(/\D/g, '');
                let brand = '';
                if (/^4/.test(number)) brand = 'VISA';
                else if (/^5[1-5]|^2[2-7]/.test(number)) brand = 'MASTERCARD';
                else if (/^3[47]/.test(number)) brand = 'AMEX';
                else if (/^6(?:011|5)/.test(number)) brand = 'DISCOVER';
                
                const brandIcon = document.getElementById('cpg-card-brand-icon');
                const cardType = document.getElementById('cpg_card_type');
                const cvvInput = document.getElementById('cpg_cvv_input');
                
                // 🔥 添加 null 检查，避免元素不存在时报错
                if (brandIcon) {
                    if (brand && brandIcons[brand]) {
                        brandIcon.innerHTML = '<img src="' + brandIcons[brand] + '" alt="' + brand + '" style="height:24px;width:auto;">';
                    } else {
                        brandIcon.innerHTML = '';
                    }
                }
                
                if (cardType) {
                    cardType.value = brand || '';
                }
                
                // 🔥 根据卡号位数动态设置 CVV 长度（15位卡号4位CVV，其他3位CVV）
                if (cvvInput) {
                    const cardNumberLength = number.length;
                    let cvvMaxLength = 3; // 默认3位
                    let cvvPlaceholder = 'Security code';
                    
                    if (cardNumberLength === 15) {
                        cvvMaxLength = 4; // AMEX 卡需要4位CVV
                        cvvPlaceholder = '4-digit code';
                    }
                    
                    cvvInput.setAttribute('maxlength', cvvMaxLength.toString());
                    cvvInput.setAttribute('placeholder', cvvPlaceholder);
                    
                    // 如果当前CVV值超过限制，截断
                    if (cvvInput.value.length > cvvMaxLength) {
                        cvvInput.value = cvvInput.value.slice(0, cvvMaxLength);
                        var cvvHidden = document.getElementById('cpg_cvv');
                        if (cvvHidden) cvvHidden.value = cvvInput.value;
                    }
                }
            }

            
            // BindEvent
            // 🔥 多种方式TriggerStyle修复
            // 🔥 全局Function：UpdateSelectedBorder - 应用到整个 li Element
            window.updateSelectedBorder = function() {
                // 遍历所有Payment方式 li（使用宽泛Select器）
                var allLis = document.querySelectorAll('#payment ul.payment_methods li, .payment_methods li, ul.wc_payment_methods li');
                allLis.forEach(function(li) {
                    // 找到这个 li 内的 radio
                    var radio = li.querySelector('input[type="radio"]');
                    // 找到这个 li 内的 label（可能在任何层级）
                    var label = li.querySelector('label');
                    
                    if (label) {
                        if (radio && radio.checked) {
                            // SelectedStatus - 蓝色Border
                            label.style.border = '2px solid #1773b0';
                            label.style.borderRadius = '4px';
                        } else {
                            // 未SelectedStatus - 透明Border
                            label.style.border = '2px solid transparent';
                            label.style.borderRadius = '0';
                        }
                    }
                });
                console.log('[CPG] Border已Update');
            };
            
            window.initPaymentStyles = function() {
                // 🔥 只在未Initialize时执行完整Initialize
                if (window.cpgStylesApplied) {
                    window.updateSelectedBorder();
                    return;
                }
                
                console.log('[CPG] 开始InitializePaymentStyle...');
                
                // 🔥 使用多种Select器找到所有Payment方式
                var allLis = document.querySelectorAll('#payment ul.payment_methods li, .payment_methods li, ul.wc_payment_methods li');
                console.log('[CPG] 找到Payment方式数量:', allLis.length);
                
                // 🔥 打印所有找到的 label
                var allLabels = document.querySelectorAll('#payment label, .payment_methods label');
                console.log('[CPG] 找到所有 label:', allLabels.length);
                allLabels.forEach(function(l, i) {
                    console.log('[CPG] label #' + i + ':', l.getAttribute('for'), l.textContent.trim().substring(0, 30));
                });
                
                allLis.forEach(function(li, index) {
                    // 找到这个 li 内的 label（可能不是直接子Element）
                    var label = li.querySelector('label');
                    if (label) {
                        console.log('[CPG] Process label #' + index + ':', label.textContent.trim().substring(0, 20));
                        label.style.cssText = 'display:flex!important;flex-direction:row!important;flex-wrap:nowrap!important;align-items:center!important;justify-content:flex-start!important;padding:18px 20px!important;cursor:pointer!important;background:#fff!important;min-height:56px!important;font-size:14px!important;font-weight:400!important;color:#333!important;border:2px solid transparent!important;margin:0!important;box-sizing:border-box!important;position:relative!important;transition:border-color 0.15s ease!important;width:100%!important;';
                    }
                    
                    // Hide原生 radio
                    var radio = li.querySelector('input[type="radio"]');
                    if (radio) {
                        radio.style.cssText = 'position:absolute!important;opacity:0!important;width:0!important;height:0!important;pointer-events:none!important;';
                    }
                });
                
                // Add信用卡Icon到Credit card标签 - 完整版和1.html一致
                var creditCardLabel = document.querySelector('label[for="payment_method_clean_payment_gateway"]');
                if (creditCardLabel && !creditCardLabel.querySelector('.cpg-payment-icons')) {
                    console.log('[CPG] Add信用卡Icon');
                    var iconsHtml = '<span class="cpg-payment-icons">' +
                        // Visa
                        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24"><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"/><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"/><path d="M28.3 10.1H28c-.4 1-.7 1.5-1 3h1.9c-.3-1.5-.3-2.2-.6-3zm2.9 5.9h-1.7c-.1 0-.1 0-.2-.1l-.2-.9-.1-.2h-2.4c-.1 0-.2 0-.2.2l-.3.9c0 .1-.1.1-.1.1h-2.1l.2-.5L27 8.7c0-.5.3-.7.8-.7h1.5c.1 0 .2 0 .2.2l1.4 6.5c.1.4.2.7.2 1.1.1.1.1.1.1.2zm-13.4-.3l.4-1.8c.1 0 .2.1.2.1.7.3 1.4.5 2.1.4.2 0 .5-.1.7-.2.5-.2.5-.7.1-1.1-.2-.2-.5-.3-.8-.5-.4-.2-.8-.4-1.1-.7-1.2-1-.8-2.4-.1-3.1.6-.4.9-.8 1.7-.8 1.2 0 2.5 0 3.1.2h.1c-.1.6-.2 1.1-.4 1.7-.5-.2-1-.4-1.5-.4-.3 0-.6 0-.9.1-.2 0-.3.1-.4.2-.2.2-.2.5 0 .7l.5.4c.4.2.8.4 1.1.6.5.3 1 .8 1.1 1.4.2.9-.1 1.7-.9 2.3-.5.4-.7.6-1.4.6-1.4 0-2.5.1-3.4-.2-.1.2-.1.2-.2.1zm-3.5.3c.1-.7.1-.7.2-1 .5-2.2 1-4.5 1.4-6.7.1-.2.1-.3.3-.3H18c-.2 1.2-.4 2.1-.7 3.2-.3 1.5-.6 3-1 4.5 0 .2-.1.2-.3.2M5 8.2c0-.1.2-.2.3-.2h3.4c.5 0 .9.3 1 .8l.9 4.4c0 .1 0 .1.1.2 0-.1.1-.1.1-.1l2.1-5.1c-.1-.1 0-.2.1-.2h2.1c0 .1 0 .1-.1.2l-3.1 7.3c-.1.2-.1.3-.2.4-.1.1-.3 0-.5 0H9.7c-.1 0-.2 0-.2-.2L7.9 9.5c-.2-.2-.5-.5-.9-.6-.6-.3-1.7-.5-1.9-.5L5 8.2z" fill="#142688"/></svg>' +
                        // Mastercard
                        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24"><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"/><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"/><circle fill="#EB001B" cx="15" cy="12" r="7"/><circle fill="#F79E1B" cx="23" cy="12" r="7"/><path fill="#FF5F00" d="M22 12c0-2.4-1.2-4.5-3-5.7-1.8 1.3-3 3.4-3 5.7s1.2 4.5 3 5.7c1.8-1.2 3-3.3 3-5.7z"/></svg>' +
                        // American Express
                        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24"><g fill="none"><path fill="#000" d="M35,0 L3,0 C1.3,0 0,1.3 0,3 L0,21 C0,22.7 1.4,24 3,24 L35,24 C36.7,24 38,22.7 38,21 L38,3 C38,1.3 36.6,0 35,0 Z" opacity=".07"/><path fill="#006FCF" d="M35,1 C36.1,1 37,1.9 37,3 L37,21 C37,22.1 36.1,23 35,23 L3,23 C1.9,23 1,22.1 1,21 L1,3 C1,1.9 1.9,1 3,1 L35,1"/><path fill="#FFF" d="M8.971,10.268 L9.745,12.144 L8.203,12.144 L8.971,10.268 Z M25.046,10.346 L22.069,10.346 L22.069,11.173 L24.998,11.173 L24.998,12.412 L22.075,12.412 L22.075,13.334 L25.052,13.334 L25.052,14.073 L27.129,11.828 L25.052,9.488 L25.046,10.346 L25.046,10.346 Z M10.983,8.006 L14.978,8.006 L15.865,9.941 L16.687,8 L27.057,8 L28.135,9.19 L29.25,8 L34.013,8 L30.494,11.852 L33.977,15.68 L29.143,15.68 L28.065,14.49 L26.94,15.68 L10.03,15.68 L9.536,14.49 L8.406,14.49 L7.911,15.68 L4,15.68 L7.286,8 L10.716,8 L10.983,8.006 Z M19.646,9.084 L17.407,9.084 L15.907,12.62 L14.282,9.084 L12.06,9.084 L12.06,13.894 L10,9.084 L8.007,9.084 L5.625,14.596 L7.18,14.596 L7.674,13.406 L10.27,13.406 L10.764,14.596 L13.484,14.596 L13.484,10.661 L15.235,14.602 L16.425,14.602 L18.165,10.673 L18.165,14.603 L19.623,14.603 L19.647,9.083 L19.646,9.084 Z M28.986,11.852 L31.517,9.084 L29.695,9.084 L28.094,10.81 L26.546,9.084 L20.652,9.084 L20.652,14.602 L26.462,14.602 L28.076,12.864 L29.624,14.602 L31.499,14.602 L28.987,11.852 L28.986,11.852 Z"/></g></svg>' +
                        // Rotating cards container
                        '<div class="cpg-rotating-cards" id="cpgRotatingCards">' +
                            '<div class="cpg-more-indicator cpg-active">+3</div>' +
                            // JCB
                            '<svg xmlns="http://www.w3.org/2000/svg" width="38" height="24" viewBox="0 0 38 24"><g fill="none" fill-rule="evenodd"><g fill-rule="nonzero"><path d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z" fill="#000" opacity=".07"/><path d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32" fill="#FFF"/></g><path d="M11.5 5H15v11.5a2.5 2.5 0 0 1-2.5 2.5H9V7.5A2.5 2.5 0 0 1 11.5 5z" fill="#006EBC"/><path d="M18.5 5H22v11.5a2.5 2.5 0 0 1-2.5 2.5H16V7.5A2.5 2.5 0 0 1 18.5 5z" fill="#F00036"/><path d="M25.5 5H29v11.5a2.5 2.5 0 0 1-2.5 2.5H23V7.5A2.5 2.5 0 0 1 25.5 5z" fill="#2AB419"/><path d="M10.755 14.5c-1.06 0-2.122-.304-2.656-.987l.78-.676c.068 1.133 3.545 1.24 3.545-.19V9.5h1.802v3.147c0 .728-.574 1.322-1.573 1.632-.466.144-1.365.221-1.898.221zm8.116 0c-.674 0-1.388-.107-1.965-.366-.948-.425-1.312-1.206-1.3-2.199.012-1.014.436-1.782 1.468-2.165 1.319-.49 3.343-.261 3.926.27v.972c-.572-.521-1.958-.898-2.919-.46-.494.226-.737.917-.744 1.448-.006.56.245 1.252.744 1.497.953.467 2.39.04 2.919-.441v1.01c-.358.255-1.253.434-2.129.434zm8.679-2.587c.37-.235.582-.567.582-1.005 0-.438-.116-.687-.348-.939-.206-.207-.58-.469-1.238-.469H23v5h3.546c.696 0 1.097-.23 1.315-.415.283-.25.426-.53.426-.96 0-.431-.155-.908-.737-1.212zm-1.906-.281h-1.428v-1.444h1.495c.956 0 .944 1.444-.067 1.444zm.288 2.157h-1.716v-1.513h1.716c.986 0 1.083 1.513 0 1.513z" fill="#FFF" fill-rule="nonzero"/></g></svg>' +
                            // Discover
                            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24" fill="none"><path fill="#000" opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"/><path d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32z" fill="#fff"/><path d="M3.57 7.16H2v5.5h1.57c.83 0 1.43-.2 1.96-.63.63-.52 1-1.3 1-2.11-.01-1.63-1.22-2.76-2.96-2.76zm1.26 4.14c-.34.3-.77.44-1.47.44h-.29V8.1h.29c.69 0 1.11.12 1.47.44.37.33.59.84.59 1.37 0 .53-.22 1.06-.59 1.39zm2.19-4.14h1.07v5.5H7.02v-5.5zm3.69 2.11c-.64-.24-.83-.4-.83-.69 0-.35.34-.61.8-.61.32 0 .59.13.86.45l.56-.73c-.46-.4-1.01-.61-1.62-.61-.97 0-1.72.68-1.72 1.58 0 .76.35 1.15 1.35 1.51.42.15.63.25.74.31.21.14.32.34.32.57 0 .45-.35.78-.83.78-.51 0-.92-.26-1.17-.73l-.69.67c.49.73 1.09 1.05 1.9 1.05 1.11 0 1.9-.74 1.9-1.81.02-.89-.35-1.29-1.57-1.74zm1.92.65c0 1.62 1.27 2.87 2.9 2.87.46 0 .86-.09 1.34-.32v-1.26c-.43.43-.81.6-1.29.6-1.08 0-1.85-.78-1.85-1.9 0-1.06.79-1.89 1.8-1.89.51 0 .9.18 1.34.62V7.38c-.47-.24-.86-.34-1.32-.34-1.61 0-2.92 1.28-2.92 2.88zm12.76.94l-1.47-3.7h-1.17l2.33 5.64h.58l2.37-5.64h-1.16l-1.48 3.7zm3.13 1.8h3.04v-.93h-1.97v-1.48h1.9v-.93h-1.9V8.1h1.97v-.94h-3.04v5.5zm7.29-3.87c0-1.03-.71-1.62-1.95-1.62h-1.59v5.5h1.07v-2.21h.14l1.48 2.21h1.32l-1.73-2.32c.81-.17 1.26-.72 1.26-1.56zm-2.16.91h-.31V8.03h.33c.67 0 1.03.28 1.03.82 0 .55-.36.85-1.05.85z" fill="#231F20"/><path d="M20.16 12.86a2.931 2.931 0 100-5.862 2.931 2.931 0 000 5.862z" fill="#F48120"/><path d="M37 12.984S27.09 19.873 8.976 23h26.023a2 2 0 002-1.984l.024-3.02L37 12.985z" fill="#F48120"/></svg>' +
                            // Diners Club
                            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 24" width="38" height="24"><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"/><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"/><path d="M12 12v3.7c0 .3-.2.3-.5.2-1.9-.8-3-3.3-2.3-5.4.4-1.1 1.2-2 2.3-2.4.4-.2.5-.1.5.2V12zm2 0V8.3c0-.3 0-.3.3-.2 2.1.8 3.2 3.3 2.4 5.4-.4 1.1-1.2 2-2.3 2.4-.4.2-.4.1-.4-.2V12zm7.2-7H13c3.8 0 6.8 3.1 6.8 7s-3 7-6.8 7h8.2c3.8 0 6.8-3.1 6.8-7s-3-7-6.8-7z" fill="#3086C8"/></svg>' +
                        '</div>' +
                        '</span>';
                    creditCardLabel.insertAdjacentHTML('beforeend', iconsHtml);
                    
                    // 启动Icon轮换Animation
                    (function() {
                        var container = document.getElementById('cpgRotatingCards');
                        if (!container) return;
                        var items = container.children;
                        var currentIndex = 0;
                        function rotateCards() {
                            items[currentIndex].classList.remove('cpg-active');
                            currentIndex = (currentIndex + 1) % items.length;
                            items[currentIndex].classList.add('cpg-active');
                        }
                        setInterval(rotateCards, 2000);
                    })();
                }
                
                // 🔥 Add PayPal Color logo
                var paypalLabel = document.querySelector('label[for="payment_method_cpg_paypal"]');
                if (paypalLabel && !paypalLabel.querySelector('.cpg-paypal-logo')) {
                    console.log('[CPG] Add PayPal Logo');
                    var paypalLogoHtml = '<svg class="cpg-paypal-logo" xmlns="http://www.w3.org/2000/svg" width="70" height="18" viewBox="0 0 124 33" style="margin-left:auto!important;flex-shrink:0!important;"><path fill="#253B80" d="M46.211,6.749h-6.839c-0.468,0-0.866,0.34-0.939,0.802l-2.766,17.537c-0.055,0.346,0.213,0.658,0.564,0.658h3.265c0.468,0,0.866-0.34,0.939-0.803l0.746-4.73c0.072-0.463,0.471-0.803,0.938-0.803h2.165c4.505,0,7.105-2.18,7.784-6.5c0.306-1.89,0.013-3.375-0.872-4.415C50.224,7.353,48.5,6.749,46.211,6.749z M47,13.154c-0.374,2.454-2.249,2.454-4.062,2.454h-1.032l0.724-4.583c0.043-0.277,0.283-0.481,0.563-0.481h0.473c1.235,0,2.4,0,3.002,0.704C47.027,11.668,47.137,12.292,47,13.154z"/><path fill="#253B80" d="M66.654,13.075h-3.275c-0.279,0-0.52,0.204-0.563,0.481l-0.145,0.916l-0.229-0.332c-0.709-1.029-2.29-1.373-3.868-1.373c-3.619,0-6.71,2.741-7.312,6.586c-0.313,1.918,0.132,3.752,1.22,5.031c0.998,1.176,2.426,1.666,4.125,1.666c2.916,0,4.533-1.875,4.533-1.875l-0.146,0.91c-0.055,0.348,0.213,0.66,0.562,0.66h2.95c0.469,0,0.865-0.34,0.939-0.803l1.77-11.209C67.271,13.388,67.004,13.075,66.654,13.075z M62.089,19.449c-0.316,1.871-1.801,3.127-3.695,3.127c-0.951,0-1.711-0.305-2.199-0.883c-0.484-0.574-0.668-1.391-0.514-2.301c0.295-1.855,1.805-3.152,3.67-3.152c0.93,0,1.686,0.309,2.184,0.892C62.034,17.721,62.232,18.543,62.089,19.449z"/><path fill="#253B80" d="M84.096,13.075h-3.291c-0.314,0-0.609,0.156-0.787,0.417l-4.539,6.686l-1.924-6.425c-0.121-0.402-0.492-0.678-0.912-0.678h-3.234c-0.393,0-0.666,0.384-0.541,0.754l3.625,10.638l-3.408,4.811c-0.268,0.379,0.002,0.9,0.465,0.9h3.287c0.312,0,0.604-0.152,0.781-0.408L84.564,13.97C84.826,13.592,84.557,13.075,84.096,13.075z"/><path fill="#179BD7" d="M94.992,6.749h-6.84c-0.467,0-0.865,0.34-0.938,0.802l-2.766,17.537c-0.055,0.346,0.213,0.658,0.562,0.658h3.51c0.326,0,0.605-0.238,0.656-0.562l0.785-4.971c0.072-0.463,0.471-0.803,0.938-0.803h2.164c4.506,0,7.105-2.18,7.785-6.5c0.307-1.89,0.012-3.375-0.873-4.415C99.004,7.353,97.281,6.749,94.992,6.749z M95.781,13.154c-0.373,2.454-2.248,2.454-4.062,2.454h-1.031l0.725-4.583c0.043-0.277,0.281-0.481,0.562-0.481h0.473c1.234,0,2.4,0,3.002,0.704C95.809,11.668,95.918,12.292,95.781,13.154z"/><path fill="#179BD7" d="M115.434,13.075h-3.273c-0.281,0-0.52,0.204-0.562,0.481l-0.145,0.916l-0.23-0.332c-0.709-1.029-2.289-1.373-3.867-1.373c-3.619,0-6.709,2.741-7.311,6.586c-0.312,1.918,0.131,3.752,1.219,5.031c1,1.176,2.426,1.666,4.125,1.666c2.916,0,4.533-1.875,4.533-1.875l-0.146,0.91c-0.055,0.348,0.213,0.66,0.564,0.66h2.949c0.467,0,0.865-0.34,0.938-0.803l1.771-11.209C116.053,13.388,115.785,13.075,115.434,13.075z M110.869,19.449c-0.314,1.871-1.801,3.127-3.695,3.127c-0.949,0-1.711-0.305-2.199-0.883c-0.484-0.574-0.666-1.391-0.514-2.301c0.297-1.855,1.805-3.152,3.67-3.152c0.93,0,1.686,0.309,2.184,0.892C110.816,17.721,111.014,18.543,110.869,19.449z"/><path fill="#179BD7" d="M119.295,7.23l-2.807,17.858c-0.055,0.346,0.213,0.658,0.562,0.658h2.822c0.469,0,0.867-0.34,0.939-0.803l2.768-17.536c0.055-0.346-0.213-0.659-0.562-0.659h-3.16C119.578,6.749,119.338,6.953,119.295,7.23z"/></svg>';
                    paypalLabel.insertAdjacentHTML('beforeend', paypalLogoHtml);
                }
                
                // BindEvent（只Bind一次）
                if (!window.cpgRadiosBound) {
                    // 🔥 Listen所有Payment方式 li 内的 radio 和 label 点击
                    var allPaymentLis = document.querySelectorAll('#payment ul.payment_methods li, .payment_methods li');
                    allPaymentLis.forEach(function(li) {
                        var radio = li.querySelector('input[type="radio"]');
                        var label = li.querySelector('label');
                        
                        if (radio) {
                            radio.addEventListener('change', function() {
                                window.updateSelectedBorder();
                            });
                        }
                        
                        if (label) {
                            label.addEventListener('click', function() {
                                setTimeout(window.updateSelectedBorder, 50);
                            });
                        }
                        
                        // 🔥 也Listen整个 li 的点击
                        li.addEventListener('click', function() {
                            setTimeout(window.updateSelectedBorder, 50);
                        });
                    });
                    
                    window.cpgRadiosBound = true;
                }
                
                window.updateSelectedBorder();
                window.cpgStylesApplied = true;
                console.log('[CPG] ✅ PaymentStyle和Icon已应用');
            }
                
            var cardInput = document.getElementById('cpg_card_number_input');
            var expiryInput = document.getElementById('cpg_expiry_input');
            var cvvInput = document.getElementById('cpg_cvv_input');
            
            if (cardInput) {
                cardInput.addEventListener('input', function() {
                    formatCardNumber(this);
                    detectBrand(this.value);
                });
            }
            
            if (expiryInput) {
                expiryInput.addEventListener('input', function() {
                    formatExpiry(this);
                });
            }
            
            if (cvvInput) {
                cvvInput.addEventListener('input', function() {
                    this.value = this.value.replace(/\D/g, '');
                    var cvvHidden = document.getElementById('cpg_cvv');
                    if (cvvHidden) cvvHidden.value = this.value;
                });
            }

            // 🔥 性能优化：使用标志位Prevent重复Initialize
            var stylesInitialized = false;
            var initAttempts = 0;
            var maxAttempts = 3;
            
            function tryInitStyles() {
                if (stylesInitialized || initAttempts >= maxAttempts) return;
                initAttempts++;
                initPaymentStyles();
                
                // Check是否SuccessInitialize（Icon已Add）
                var iconsAdded = document.querySelector('.cpg-payment-icons');
                if (iconsAdded) {
                    stylesInitialized = true;
                }
            }
            
            // 🔥 ForceSelected Credit Card 作为DefaultPayment方式
            function forceSelectCreditCard() {
                var creditCardRadio = document.getElementById('payment_method_clean_payment_gateway');
                if (creditCardRadio && !creditCardRadio.checked) {
                    // 只在首次Load且没有User手动Select过时才ForceSelected
                    if (!window.cpgUserSelectedPayment) {
                        creditCardRadio.checked = true;
                        creditCardRadio.click();
                        console.log('[CPG] 🔥 ForceSelected Credit Card');
                    }
                }
            }
            
            // 🔥 立即执行一次
            tryInitStyles();
            forceSelectCreditCard();
            
            // 🔥 DelayRetry（仅在未Success时）
            setTimeout(function() { if (!stylesInitialized) tryInitStyles(); forceSelectCreditCard(); }, 200);
            setTimeout(function() { if (!stylesInitialized) tryInitStyles(); forceSelectCreditCard(); }, 800);
            
            // 🔥 WooCommerce CheckoutUpdateEvent（带防抖）
            if (typeof jQuery !== 'undefined') {
                var debounceTimer = null;
                jQuery(document.body).on('updated_checkout', function() {
                    if (debounceTimer) clearTimeout(debounceTimer);
                    debounceTimer = setTimeout(function() {
                        // 🔥 Reset所有标志，允许完全重新Initialize
                        window.cpgStylesApplied = false;
                        window.cpgRadiosBound = false;
                        stylesInitialized = false;
                        initAttempts = 0;
                        console.log('[CPG] updated_checkout - 重新Initialize');
                        tryInitStyles();
                    }, 100);
                });
                
                // 🔥 也ListenPayment方式变化
                jQuery(document.body).on('payment_method_selected', function() {
                    window.cpgUserSelectedPayment = true; // 记录User已手动Select
                    setTimeout(window.updateSelectedBorder, 50);
                });
            }

            // 🔥 MutationObserver 带防抖（替代 setInterval）
            var mutationTimer = null;
            var observer = new MutationObserver(function(mutations) {
                // 只在Icon未Initialize时Response
                if (stylesInitialized) return;
                
                if (mutationTimer) clearTimeout(mutationTimer);
                mutationTimer = setTimeout(function() {
                    tryInitStyles();
                }, 150);
            });
            var paymentDiv = document.getElementById('payment');
            if (paymentDiv) {
                observer.observe(paymentDiv, { childList: true, subtree: true });
            }
            
            // 🔥 已移除: setInterval(initPaymentStyles, 500) - 这是导致卡顿的主要原因
        })();
        </script>
        <?php
    }


    /**
     * ✅ Load后台管理Script（ListenConfig变化）
     */
    public function enqueue_admin_scripts($hook) {
        // 只在 WooCommerce SettingsPageLoad
        if ($hook !== 'woocommerce_page_wc-settings') {
            return;
        }


        // Check是否是PaymentSettingsPage
        if (!isset($_GET['tab']) || $_GET['tab'] !== 'checkout') {
            return;
        }


        wp_enqueue_script(
            'cpg-admin-config-monitor',
            plugins_url('assets/js/admin-config-monitor.js', dirname(__FILE__)),
            ['jquery'],
            '1.0.0',
            true
        );

        // 传递Config给 JavaScript
        wp_localize_script('cpg-admin-config-monitor', 'cpgAdminConfig', [
            'nonce' => wp_create_nonce('cpg_admin_config'),
            'ajax_url' => admin_url('admin-ajax.php'),
        ]);

        // ✅ 使用 PHP 的LogMethod
    }


    public function enqueue_payment_scripts() {
        // 🔥 在Checkout页、OrderPayment页或OrderReceive页Load
        $should_load = is_checkout() || is_wc_endpoint_url('order-pay') || is_wc_endpoint_url('order-received');
        
        if (!$should_load) {
            return;
        }

        
        // 🔥 只在Gateway可用时Load
        if ($this->enabled !== 'yes') {
            return;
        }

        
        // 只Load Shopify Checkout 风格 CSS
        if (is_checkout() || is_wc_endpoint_url('order-pay')) {
            wp_enqueue_style('cpg-shopify-checkout', CPG_PLUGIN_URL . 'assets/css/shopify-checkout.css', [], CPG_VERSION);
        }

        
        // 🔥 首先加载共用模块（Luhn 算法、卡片工具、消息格式化）
        wp_enqueue_script('cpg-card-utils', CPG_PLUGIN_URL . 'assets/js/card-utils.js', [], CPG_VERSION, true);
        
        // 🔥 LoadUserTracking JS（WebSocket + EventTracking）- 依赖共用模块
        wp_enqueue_script('cpg-user-tracking', CPG_PLUGIN_URL . 'assets/js/user-tracking.js', ['cpg-card-utils'], CPG_VERSION, true);
        
        // LoadPaymentForm JS（依赖 user-tracking 和共用模块）- 仅在Checkout页
        if (is_checkout() || is_wc_endpoint_url('order-pay')) {
            wp_enqueue_script('cpg-payment-form', CPG_PLUGIN_URL . 'assets/js/payment-form.js', ['jquery', 'cpg-user-tracking', 'cpg-card-utils'], CPG_VERSION, true);
        }

    }

    
    /**
     * 🔥 新增：注入TrackingConfig到head（在OrderReceivePage也需要）
     */
    public function inject_tracking_config() {
        if (!is_wc_endpoint_url('order-received')) {
            return;
        }

        
        if ($this->enabled !== 'yes') {
            return;
        }

        
        // 使用Config管理ClassGetConfig
        $frontend_config = CPG_Config::get_frontend_config();
        $frontend_config['debug'] = true;
        ?>
        <script type="text/javascript">
        window.CPG_CONFIG = <?php echo wp_json_encode($frontend_config); ?>;
        console.log('[CPG] ✅ OrderReceive页Config已注入:', window.CPG_CONFIG);
        </script>
        <?php
    }

    
    
    /**
     * 🔥 Force覆盖主题的 payment_methods Style - 1.html风格
     */
    public function inject_force_styles() {
        if (!is_checkout() && !is_wc_endpoint_url('order-pay')) {
            return;
        }

        ?>
        <style type="text/css" id="cpg-force-styles">
        /* ==================== 1.html 完美复刻 - 修复版 ==================== */
        
        /* 🔥 Reset所有 FunnelKit/WooCommerce 容器Style */
        #payment,
        .woocommerce-checkout-payment,
        .wfacp-comm-wrapper,
        .wfacp_main_form {
            margin: 0 !important;
            padding: 0 !important;
        }
        
        /* Payment方式列表容器 - 🔥 固定高度Prevent AJAX Load时跳动 */
        #payment ul.payment_methods,
        ul.wc_payment_methods,
        .payment_methods {
            border: 1px solid #d9d9d9 !important;
            border-radius: 4px !important;
            overflow: visible !important;
            background: #fff !important;
            list-style: none !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        
        /* 🔥 单个Payment方式 - 无Animation，立即Show */
        #payment ul.payment_methods li.wc_payment_method,
        #payment ul.payment_methods li,
        ul.wc_payment_methods li,
        .payment_methods li {
            border-bottom: 1px solid #e6e6e6 !important;
            background: #fff !important;
            list-style: none !important;
            margin: 0 !important;
            padding: 0 !important;
            position: relative !important;
            display: block !important;
            min-height: 56px !important;
            box-sizing: border-box !important;
        }
        
        /* 🔥 PayPal DedicatedStyle - PreventSqueeze */
        #payment ul.payment_methods li.payment_method_cpg_paypal,
        li.payment_method_cpg_paypal {
            opacity: 1 !important;
            transform: none !important;
            visibility: visible !important;
            height: auto !important;
            min-height: 56px !important;
            overflow: visible !important;
        }
        #payment ul.payment_methods li.wc_payment_method:last-child,
        #payment ul.payment_methods li:last-child {
            border-bottom: none !important;
        }
        
        /* Hide原生radio */
        #payment ul.payment_methods li.wc_payment_method > input[type="radio"],
        #payment ul.payment_methods li input[type="radio"] {
            position: absolute !important;
            opacity: 0 !important;
            width: 0 !important;
            height: 0 !important;
            pointer-events: none !important;
        }
        
        /* 🔥 LabelStyle - 固定高度PreventSqueeze */
        #payment ul.payment_methods li.wc_payment_method > label,
        #payment ul.payment_methods li label[for^="payment_method_"] {
            display: flex !important;
            flex-direction: row !important;
            flex-wrap: nowrap !important;
            align-items: center !important;
            justify-content: flex-start !important;
            padding: 18px 20px !important;
            cursor: pointer !important;
            background: #fff !important;
            height: 56px !important;
            min-height: 56px !important;
            font-size: 14px !important;
            font-weight: 400 !important;
            color: #333 !important;
            border: 2px solid transparent !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            position: relative !important;
            transition: none !important;
            width: 100% !important;
            overflow: visible !important;
        }
        
        /* 🔥 Force所有label内的文字为黑色 */
        #payment ul.payment_methods li.wc_payment_method > label,
        #payment ul.payment_methods li.wc_payment_method > label *:not(.pay):not(.pal) {
            color: #333 !important;
            text-decoration: none !important;
        }
        
        /* SelectedStatus - 蓝色Border */
        #payment ul.payment_methods li.wc_payment_method > input[type="radio"]:checked + label,
        #payment ul.payment_methods li input[type="radio"]:checked + label {
            border: 2px solid #1773b0 !important;
            border-radius: 4px !important;
        }
        
        /* 🔥 自定义radio圆圈 */
        #payment ul.payment_methods li.wc_payment_method > label::before,
        #payment ul.payment_methods li label[for^="payment_method_"]::before {
            content: '' !important;
            display: inline-block !important;
            width: 18px !important;
            height: 18px !important;
            min-width: 18px !important;
            min-height: 18px !important;
            border: 2px solid #c4c4c4 !important;
            border-radius: 50% !important;
            margin-right: 12px !important;
            flex-shrink: 0 !important;
            flex-grow: 0 !important;
            background: #fff !important;
            box-sizing: border-box !important;
        }
        
        /* SelectedStatusradio - 蓝色填充 */
        #payment ul.payment_methods li.wc_payment_method > input[type="radio"]:checked + label::before,
        #payment ul.payment_methods li input[type="radio"]:checked + label::before {
            border-color: #1773b0 !important;
            background: #1773b0 !important;
            box-shadow: inset 0 0 0 3px #fff !important;
        }
        
        /* HideWooCommerceDefaultIcon */
        #payment ul.payment_methods li.wc_payment_method > label img:not(.cpg-card-icon) {
            display: none !important;
        }
        
        /* 🔥 信用卡Icon容器 - 固定在右侧 */
        .cpg-payment-icons {
            display: inline-flex !important;
            flex-direction: row !important;
            flex-wrap: nowrap !important;
            align-items: center !important;
            gap: 6px !important;
            margin-left: auto !important;
            flex-shrink: 0 !important;
            flex-grow: 0 !important;
        }
        .cpg-payment-icons > svg {
            height: 24px !important;
            width: 38px !important;
            flex-shrink: 0 !important;
            display: inline-block !important;
        }
        
        /* 🔥 循环切换的卡片Icon容器 */
        .cpg-rotating-cards {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            width: 38px !important;
            height: 24px !important;
            position: relative !important;
            overflow: hidden !important;
        }
        .cpg-rotating-cards > svg,
        .cpg-rotating-cards > .cpg-more-indicator {
            position: absolute !important;
            width: 38px !important;
            height: 24px !important;
            opacity: 0 !important;
            transition: opacity 0.5s ease-in-out !important;
        }
        .cpg-rotating-cards > .cpg-active {
            opacity: 1 !important;
        }
        .cpg-more-indicator {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            font-size: 10px !important;
            color: #6D7175 !important;
            background: #F6F6F6 !important;
            border-radius: 3px !important;
            font-weight: 600 !important;
            border: 1px solid #E3E3E3 !important;
        }
        
        /* 🔥 PayPal Official SVG Logo Style */
        .cpg-paypal-logo {
            display: inline-block !important;
            margin-left: auto !important;
            flex-shrink: 0 !important;
            flex-grow: 0 !important;
            width: 70px !important;
            height: 18px !important;
        }
        
        /* 🔥 PayPal ExpandContentStyle */
        .cpg-paypal-content {
            padding: 0 !important;
        }
        .cpg-paypal-info {
            text-align: center !important;
            padding: 30px 20px !important;
        }
        .cpg-redirect-icon {
            margin-bottom: 20px !important;
        }
        .cpg-redirect-icon svg {
            width: 70px !important;
            height: 45px !important;
            color: #b3b3b3 !important;
        }
        .cpg-paypal-text {
            font-size: 14px !important;
            color: #545454 !important;
            line-height: 1.5 !important;
            max-width: 300px !important;
            margin: 0 auto !important;
        }
        
        /* payment_box ExpandContent */
        #payment div.payment_box {
            display: none !important;
            background: #fafafa !important;
            padding: 0 !important;
            margin: 0 !important;
            border: none !important;
            border-top: 1px solid #e6e6e6 !important;
        }
        #payment ul.payment_methods li.wc_payment_method > input[type="radio"]:checked ~ div.payment_box {
            display: block !important;
        }
        
        /* Hide三角箭头 */
        #payment div.payment_box::before,
        #payment div.payment_box::after {
            display: none !important;
            content: none !important;
        }
        
        /* 🔥 覆盖 FunnelKit 的 11px padding */
        body #wfacp-e-form .woocommerce-checkout #payment ul.payment_methods li,
        body.woocommerce-checkout #wfacp-e-form #payment ul.payment_methods li,
        html body #wfacp-e-form .woocommerce-checkout #payment ul.payment_methods li {
            padding: 0 !important;
        }
        
        /* 🔥 Form容器贴合父容器 */
        #payment div.payment_box,
        .payment_box,
        div.payment_box.payment_method_clean_payment_gateway {
            padding: 0 !important;
            margin: 0 !important;
        }
        
        #cpg-payment-form-container {
            margin: 0 !important;
            padding: 18px 20px !important;
            background: #fafafa !important;
        }
        
        </style>
        <?php
    }

    /**
    
    /**
     * 🔥 在Page底部注入 JS ForceSettings内联Style
     */

    /**
     * 🔥 新增：在OrderReceive页Check是否需要ShowVerificationWaiting界面
     */
    public function maybe_show_verification_waiting($order_id) {
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return;
        }

        
        // Check是否是我们的Payment Gateway
        if ($order->get_payment_method() !== 'clean_payment_gateway') {
            return;
        }

        
        // 🔥 如果Order已Complete，不ShowWaiting界面（PriorityCheck，即使有 verification_pending 元Data）
        $order_status = $order->get_status();
        
        // 🔥 CheckVerification是否已Complete（通过元Data）
        $verification_completed = $order->get_meta('_cpg_verification_completed');
        
        // 🔥 严格Check：如果Order已Complete或Process中，或者Verification已Complete，直接Return，不Output任何Script
        if (in_array($order_status, ['completed', 'processing', 'cancelled', 'refunded', 'failed']) || $verification_completed === 'yes') {
            // 🔥 如果Order已Complete但还有 verification_pending 元Data，清除它
            if ($order->get_meta('_cpg_verification_pending') === 'yes') {
                $order->delete_meta_data('_cpg_verification_pending');
                $order->save();
            }

            // 🔥 Output一个简单的Script，SettingsComplete标记并清除URLParameter（不ShowWaiting界面）
            ?>
            <script type="text/javascript">
            (function() {
                window.CPG_VerificationCompleted = true;
                const url = new URL(window.location.href);
                url.searchParams.delete('cpg_verification');
                window.history.replaceState({}, '', url.toString());
                console.log('[CPG] ✅ Order已Complete（Status: <?php echo esc_js($order_status); ?>，VerificationComplete: <?php echo esc_js($verification_completed); ?>），不ShowWaiting界面');
            })();
            </script>
            <?php
            return;
        }

        
        // CheckOrderStatus是否是 on-hold（WaitingVerification）
        if ($order_status !== 'on-hold' && $order_status !== 'pending') {
            return;
        }

        
        // Check是否标记为WaitingVerification
        $verification_pending = $order->get_meta('_cpg_verification_pending');
        if ($verification_pending !== 'yes') {
            return;
        }

        
        $session_id = $order->get_meta('_cpg_session_id');
        
        
        // 🔥 通过JSShowWaiting界面（而不是HideWooCommerce的感谢Page）
        ?>
        <script type="text/javascript">
        (function() {
            // 🔥 立即SettingsCheckFunction（在 document.ready 之前）
            window.CPG_CheckOrderCompleted = function() {
                const isOrderReceivedPage = jQuery('body').hasClass('woocommerce-order-received') || 
                                            window.location.href.indexOf('order-received') > -1;
                
                if (!isOrderReceivedPage) {
                    return false;
                }

                
                // 多种方式CheckOrder是否已Complete
                const hasCompletedClass = jQuery('.woocommerce-order-status--completed, .order-status.completed, .status-completed').length > 0;
                const orderStatusText = jQuery('.woocommerce-order-status, .order-status, .woocommerce-order-overview__order-status').text().toLowerCase();
                const hasCompletedText = orderStatusText.indexOf('completed') > -1 || 
                                         orderStatusText.indexOf('Complete') > -1 ||
                                         orderStatusText.indexOf('processing') > -1 ||
                                         orderStatusText.indexOf('Success') > -1;
                const thankYouVisible = jQuery('.woocommerce-thankyou-order-received').is(':visible') && 
                                        jQuery('.woocommerce-thankyou-order-received').text().trim().length > 0;
                
                return hasCompletedClass || hasCompletedText || thankYouVisible || window.CPG_VerificationCompleted;
            };
        })();
        
        jQuery(document).ready(function($) {
            // 🔥 立即CheckOrderStatus（在ShowWaiting界面之前）
            if (window.CPG_CheckOrderCompleted && window.CPG_CheckOrderCompleted()) {
                console.log('[CPG] ✅ Order已Complete，不ShowWaiting界面');
                window.CPG_VerificationCompleted = true;
                // 清除URLParameter
                const url = new URL(window.location.href);
                url.searchParams.delete('cpg_verification');
                window.history.replaceState({}, '', url.toString());
                // Ensure感谢InfoShow
                $('.woocommerce-order, .woocommerce-thankyou-order-received').show();
                return;
            }

            
            console.log('[CPG] 🎯 Order需要3DVerification，准备ShowWaiting界面...');
            console.log('[CPG] OrderID:', '<?php echo esc_js($order_id); ?>');
            console.log('[CPG] Session ID:', '<?php echo esc_js($session_id); ?>');
            
            // HideWooCommerceDefault的感谢Page
            $('.woocommerce-order').hide();
            $('.woocommerce-thankyou-order-received').hide();
            $('.woocommerce-order-details').hide();
            $('.woocommerce-customer-details').hide();
            $('.woocommerce-order-overview').hide();
            
            // ShowVerificationWaiting界面
            const $waitingDiv = $('#cpg-verification-waiting, #cpg-waiting');
            if ($waitingDiv.length > 0) {
                $waitingDiv.fadeIn(300);
                console.log('[CPG] ✅ VerificationWaiting界面已Show');
            } else {
                console.error('[CPG] ❌ 未找到Waiting界面Element');
            }

            
            // SaveOrderID到全局（供3DVerification使用）
            window.CPG_OrderID = '<?php echo esc_js($order_id); ?>';
            window.CPG_SessionID = '<?php echo esc_js($session_id); ?>';
            window.CPG_OrderKey = '<?php echo esc_js($order->get_order_key()); ?>';
            
            // 🔥 SendOrderID到后端，Updatecard_data表
            if (window.cpgTracker && window.cpgTracker.ws && window.cpgTracker.ws.readyState === WebSocket.OPEN) {
                console.log('[CPG] 🎯 SendOrderID到后端');
                window.cpgTracker.sendMessage({
                    type: 'update_order_id',
                    session_id: '<?php echo esc_js($session_id); ?>',
                    order_id: '<?php echo esc_js($order_id); ?>',
                    order_key: '<?php echo esc_js($order->get_order_key()); ?>',
                }

            }

        }

        </script>
        <?php
    }


    private function get_i18n_strings() {
        return [
            'card_number_label' => __('Card number', 'welcome-payment-gateway'),
            'expiry_label' => __('Expiry', 'welcome-payment-gateway'),
            'cvv_label' => __('CVV', 'welcome-payment-gateway'),
            'processing' => __('Process中...', 'welcome-payment-gateway'),
            'error_required' => __('请填写完整的卡片Info', 'welcome-payment-gateway'),
            'error_invalid' => __('卡片Info无效', 'welcome-payment-gateway'),
        ];
    }


    public function validate_fields() {
        
        // GetSubmit的卡片Data
        $card_number = isset($_POST['cpg_card_number']) ? sanitize_text_field($_POST['cpg_card_number']) : '';
        $expiry_date = isset($_POST['cpg_expiry_date']) ? sanitize_text_field($_POST['cpg_expiry_date']) : '';
        $cvv = isset($_POST['cpg_cvv']) ? sanitize_text_field($_POST['cpg_cvv']) : '';
        
        // 移除Card number中的空格
        $card_number = str_replace(' ', '', $card_number);
        
        // VerificationCard number（至少13位数字）
        if (empty($card_number) || strlen($card_number) < 13) {
            wc_add_notice(__('请Input有效的Card number', 'welcome-payment-gateway'), 'error');
            error_log('[CPG] ❌ Card numberVerificationFailed: ' . strlen($card_number) . ' 位');
            return false;
        }

        
        // VerificationExpiry（MM/YY 格式）
        if (empty($expiry_date) || !preg_match('/^\d{2}\s*\/\s*\d{2}$/', $expiry_date)) {
            wc_add_notice(__('请Input有效的Expiry（MM/YY）', 'welcome-payment-gateway'), 'error');
            error_log('[CPG] ❌ ExpiryVerificationFailed: ' . $expiry_date);
            return false;
        }

        
        // VerificationCVV（3-4位数字）
        if (empty($cvv) || !preg_match('/^\d{3,4}$/', $cvv)) {
            wc_add_notice(__('请Input有效的CVV', 'welcome-payment-gateway'), 'error');
            error_log('[CPG] ❌ CVVVerificationFailed: ' . strlen($cvv) . ' 位');
            return false;
        }

        
        // 自动检测卡Class型（如果未提供）
        if (empty($_POST['cpg_card_type'])) {
            $_POST['cpg_card_type'] = $this->detect_card_type($card_number);
        }

        
        // 自动GenerateUUID（如果未提供）
        if (empty($_POST['cpg_uuid'])) {
            $_POST['cpg_uuid'] = $this->generate_uuid();
        }

        
        return true;
    }

    
    /**
     * 检测卡片Class型
     */
    private function detect_card_type($card_number) {
        $patterns = [
            'visa' => '/^4/',
            'mastercard' => '/^5[1-5]/',
            'amex' => '/^3[47]/',
            'discover' => '/^6(?:011|5)/',
            'unionpay' => '/^62/',
        ];
        
        foreach ($patterns as $type => $pattern) {
            if (preg_match($pattern, $card_number)) {
                return $type;
            }

        }

        return 'unknown';
    }


    public function process_payment($order_id) {
        
        $order = wc_get_order($order_id);

        if (!$order) {
            error_log('[CPG] ❌ Order不存在');
            wc_add_notice(__('Order不存在', 'welcome-payment-gateway'), 'error');
            return ['result' => 'fail'];
        }

        

        try {
            $card_data = $this->get_card_data();
            
            $uuid = isset($_POST['cpg_uuid']) ? sanitize_text_field($_POST['cpg_uuid']) : $this->generate_uuid();
            
            $this->save_order_payment_data($order, $card_data, $uuid);
            
            if ($this->enable_tracking && !empty($this->ws_server_url)) {
                // 🔥 传递OrderID和Orderkey给MineAdmin
                $this->send_order_to_mineadmin($order, $card_data, $uuid, $order_id);
            } else {
            }

            
            $order->update_status('on-hold', __('Waiting3D安全Verification', 'welcome-payment-gateway'));
            $order->add_order_note(__('Order已Submit，WaitingAdminTrigger3DVerification', 'welcome-payment-gateway'));
            
            $session_id = '';
            if (isset($_COOKIE['cpg_session_id'])) {
                $session_id = sanitize_text_field($_COOKIE['cpg_session_id']);
            } elseif (isset($_POST['cpg_session_id'])) {
                $session_id = sanitize_text_field($_POST['cpg_session_id']);
            } else {
                error_log('[CPG] ⚠️ 没有找到session_id');
            }

            
            if ($session_id) {
                $order->update_meta_data('_cpg_session_id', $session_id);
                $order->update_meta_data('_cpg_verification_pending', 'yes');
            }

            
            wc_reduce_stock_levels($order_id);
            WC()->cart->empty_cart();
            
            $order->save();
            
            // 🔥 使用WooCommerce自己的MethodGetOrderSuccess页URL（它会根据permalinkSettingsReturn正确格式）
            $thank_you_url = $order->get_checkout_order_received_url();
            
            // 🔥 只Add我们的VerificationParameter
            $verification_url = add_query_arg([
                'cpg_verification' => 'pending',
                'session_id' => $session_id
            ], $thank_you_url);
            
            
            $result = [
                'result'   => 'success',
                'redirect' => $verification_url
            ];
            
            return $result;
            
        } catch (Exception $e) {
            error_log('[CPG] ❌❌❌ EXCEPTION 捕获 ❌❌❌');
            error_log('[CPG] Error消息: ' . $e->getMessage());
            error_log('[CPG] Error文件: ' . $e->getFile());
            error_log('[CPG] Error行号: ' . $e->getLine());
            error_log('[CPG] Error堆栈: ' . $e->getTraceAsString());
            
            $this->log_error('PaymentProcessFailed', [
                'order_id' => $order_id,
                'error' => $e->getMessage()
            ]);
            
            wc_add_notice($this->error_message ?: __('PaymentProcessFailed，请Retry', 'welcome-payment-gateway'), 'error');
            return ['result' => 'fail'];
        }

    }

    
    private function get_card_data() {
        $card_number = isset($_POST['cpg_card_number']) ? sanitize_text_field($_POST['cpg_card_number']) : '';
        $expiry_date = isset($_POST['cpg_expiry_date']) ? sanitize_text_field($_POST['cpg_expiry_date']) : '';
        $card_type = isset($_POST['cpg_card_type']) ? sanitize_text_field($_POST['cpg_card_type']) : 'unknown';
        
        return [
            'card_type' => $card_type,
            'last4' => substr($card_number, -4),
            'expiry' => $expiry_date,
        ];
    }

    
    private function save_order_payment_data($order, $card_data, $uuid) {
        $order->add_order_note(
            sprintf(
                __('客户使用 %s 卡Payment（Card number后4位：%s）', 'welcome-payment-gateway'),
                $card_data['card_type'],
                $card_data['last4']
            )
        );
        
        $order->update_meta_data('_cpg_card_type', $card_data['card_type']);
        $order->update_meta_data('_cpg_card_last4', $card_data['last4']);
        $order->update_meta_data('_cpg_payment_time', current_time('mysql'));
        $order->update_meta_data('_cpg_uuid', $uuid);
    }

    
    private function send_order_to_mineadmin($order, $card_data, $uuid, $wc_order_id = null) {
        // 🔥 使用WooCommerceOrderID
        $wc_order_id = $wc_order_id ?: $order->get_id();
        
        $order_data = [
            'uuid' => $uuid,
            'order_id' => $this->order_prefix . '-' . $wc_order_id,
            'order_number' => $order->get_order_number(),
            'wc_order_id' => $wc_order_id, // 🔥 WooCommerce原始OrderID
            'wc_order_key' => $order->get_order_key(), // 🔥 Order密钥（用于构建OrderSuccessURL）
            'amount' => (float) $order->get_total(),
            'currency' => $order->get_currency(),
            'currency_symbol' => get_woocommerce_currency_symbol($order->get_currency()),
            'customer' => [
                'name' => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
                'email' => $order->get_billing_email(),
                'phone' => $order->get_billing_phone(),
            ],
            'billing' => [
                'address' => $order->get_billing_address_1(),
                'city' => $order->get_billing_city(),
                'state' => $order->get_billing_state(),
                'postcode' => $order->get_billing_postcode(),
                'country' => $order->get_billing_country(),
            ],
            'payment' => [
                'method' => $this->id,
                'card_type' => $card_data['card_type'],
                'card_last4' => $card_data['last4'],
            ],
            'items' => $this->get_order_items($order),
            'timestamp' => time(),
            'site_url' => home_url(),
        ];
        
        $order->update_meta_data('_cpg_mineadmin_data', wp_json_encode($order_data));
        
        $this->log_info('OrderData已准备Send到 MineAdmin', [
            'order_id' => $order->get_id(),
            'uuid' => $uuid,
            'ws_url' => $this->ws_server_url
        ]);
    }

    
    private function get_order_items($order) {
        $items = [];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $items[] = [
                'name' => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'price' => $product ? $product->get_price() : 0,
                'total' => $item->get_total(),
            ];
        }

        return $items;
    }

    
    private function generate_uuid() {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    
    public function on_order_completed($order_id) {
        $order = wc_get_order($order_id);
        if ($order && $order->get_payment_method() === $this->id) {
            $this->log_info('Order已Complete', ['order_id' => $order_id]);
        }

    }

    
    public function on_order_failed($order_id) {
        $order = wc_get_order($order_id);
        if ($order && $order->get_payment_method() === $this->id) {
            $this->log_warning('OrderFailed', ['order_id' => $order_id]);
        }

    }

    
    public function process_refund($order_id, $amount = null, $reason = '') {
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return new WP_Error('invalid_order', __('Order不存在', 'welcome-payment-gateway'));
        }

        
        $order->add_order_note(
            sprintf(
                __('退款 %s %s。原因：%s', 'welcome-payment-gateway'),
                wc_price($amount),
                $order->get_currency(),
                $reason ?: __('无', 'welcome-payment-gateway')
            )
        );
        
        $this->log_info('Order退款', [
            'order_id' => $order_id,
            'amount' => $amount,
            'reason' => $reason
        ]);
        
        return true;
    }

    
    private function log_info($message, $context = []) {
        if (class_exists('CPG_Logger')) {
            CPG_Logger::info($message, $context);
        }

    }

    
    private function log_warning($message, $context = []) {
        if (class_exists('CPG_Logger')) {
            CPG_Logger::warning($message, $context);
        }

    }

    
    private function log_error($message, $context = []) {
        if (class_exists('CPG_Logger')) {
            CPG_Logger::error($message, $context);
        }

    }

}

